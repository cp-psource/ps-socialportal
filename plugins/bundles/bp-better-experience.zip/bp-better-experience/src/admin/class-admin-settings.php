<?php
/**
 * Admin Settings Pages Helper.
 *
 * @package    BP_Better_Experience
 * @subpackage Admin
 * @copyright  Copyright (c) 2018, WMS N@W
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Better_Experience\Admin;

use \Press_Themes\PT_Settings\Page;

// Exit if file accessed directly over web.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Admin_Settings
 */
class Admin_Settings {

	/**
	 * Admin Menu slug
	 *
	 * @var string
	 */
	private $menu_slug;

	/**
	 * Used to keep a reference of the Page, It will be used in rendering the view.
	 *
	 * @var \Press_Themes\PT_Settings\Page
	 */
	private $page;

	/**
	 * Boot settings
	 */
	public static function boot() {
		$self = new self();

		$self->setup();
	}

	/**
	 * Setup settings
	 */
	public function setup() {
		$this->menu_slug = 'bp-better-experience-settings';

		add_action( 'admin_init', array( $this, 'init' ) );
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
	}

	/**
	 * Show/render the setting page
	 */
	public function render() {
		$this->page->render();
	}

	/**
	 * Is it the setting page?
	 *
	 * @return bool
	 */
	private function needs_loading() {
		global $pagenow;

		// We need to load on options.php otherwise settings won't be reistered.
		if ( 'options.php' === $pagenow ) {
			return true;
		}

		if ( isset( $_GET['page'] ) && $_GET['page'] === $this->menu_slug ) {
			return true;
		}

		return false;
	}

	/**
	 * Initialize the admin settings panel and fields
	 */
	public function init() {

		if ( ! $this->needs_loading() ) {
			return;
		}

		$page = new Page( 'bp_better_experience_settings' );

		// General settings tab.
		$general = $page->add_panel( 'general', _x( 'Allgemeines', 'Admin settings panel title', 'bp-better-experience' ) );
		$this->add_registration_panel( $page );
		$this->add_restrictions_panel( $page );
		do_action( 'bp_better_experience_admin_settings_general', $general );

		do_action( 'bp_better_experience_admin_settings_page', $page );

		$this->page = $page;

		// allow enabling options.
		$page->init();
	}

	/**
	 * Add Menu
	 */
	public function add_menu() {

		add_options_page(
			_x( 'BuddyPress Bessere Erfahrung', 'Admin settings page title', 'bp-better-experience' ),
			_x( 'BuddyPress Bessere Erfahrung', 'Admin settings menu label', 'bp-better-experience' ),
			'manage_options',
			$this->menu_slug,
			array( $this, 'render' )
		);
	}

	/**
	 * Add Registration panel.
	 *
	 * @param Page $page page object.
	 */
	private function add_registration_panel( $page ) {
		$panel   = $page->add_panel( 'registration', _x( 'Registrierung', 'Admin settings panel title', 'bp-better-experience' ) );
		$section = $panel->add_section( 'registration-general', __( 'Allgemeines', 'bp-better-experience' ) );
		$section->add_fields(
			array(
				array(
					'name'    => 'registration-disable-confirm-password',
					'label'   => __( 'Passwortbestätigung deaktivieren?', 'bp-better-experience' ),
					'type'    => 'radio',
					'options' => array(
						0 => __( 'Nein', 'bp-better-experience' ),
						1 => __( 'Ja', 'bp-better-experience' ),
					),
					'default' => 1,
				),
				array(
					'name'    => 'registration-disable-full-name',
					'label'   => __( 'Benutzername auch für Anzeigenamen verwenden?', 'bp-better-experience' ),
					'type'    => 'radio',
					'options' => array(
						0 => __( 'Nein', 'bp-better-experience' ),
						1 => __( 'Ja', 'bp-better-experience' ),
					),
					'default' => 1,
				),
			)
		);
	}

	/**
	 * Add Registration panel.
	 *
	 * @param Page $page page object.
	 */
	private function add_restrictions_panel( $page ) {
		$panel   = $page->add_panel( 'restrictions', _x( 'Einschränkungen & Weiterleitungen', 'Admin settings panel title', 'bp-better-experience' ) );
		$section = $panel->add_section( 'restrictions-general', __( 'Allgemeines', 'bp-better-experience' ) );

		$roles = $this->get_roles_all();
		$section->add_fields(
			array(
				array(
					'name'    => 'restrict-dashboard-access',
					'label'   => __( 'Dashboard-Zugriff einschränken?', 'bp-better-experience' ),
					'type'    => 'radio',
					'options' => array(
						0 => __( 'Nein', 'bp-better-experience' ),
						1 => __( 'Ja', 'bp-better-experience' ),
					),
					'default' => 0,
				),
				array(
					'name'    => 'dashboard-allowed-roles',
					'label'   => __( 'Zulässige Rollen?', 'bp-better-experience' ),
					'type'    => 'multicheck',
					'options' => $roles,
					'default' => array( 'all' => 'all' ),
					'desc'    => __( 'Wenn Du eingeschränkten Zugriff hast, können Benutzer mit diesen Rollen auf das Dashboard zugreifen. "Administratoren" sind immer erlaubt.', 'bp-better-experience' ),
				),

				array(
					'name'    => 'dashboard-restricted-redirect-url',
					'label'   => __( 'Weiterleiten auf?', 'bp-better-experience' ),
					'type'    => 'text',
					'default' => '[user-profile-url]',
					'desc'    => __( "Du kannst einen beliebigen Link verwenden oder [user-profile-url] für die Profil-URL des aktuellen Benutzers und [home-url] für die Home-URL der Seite verwenden.", 'bp-better-experience' ),
				),
			)
		);
	}

	/**
	 * Get all roles.
	 *
	 * @return array
	 */
	private function get_roles_all() {

		$all = wp_roles()->roles;

		$roles = array( 'all' => __( 'Jeder', 'bp-better-experience' ) );
		foreach ( $all as $role => $role_obj ) {
			$roles[ $role ] = $role_obj['name'];
		}

		return $roles;
	}
}
