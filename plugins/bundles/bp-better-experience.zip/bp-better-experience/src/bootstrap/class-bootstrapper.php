<?php
/**
 * Bootstrapper. Initializes the plugin.
 *
 * @package    BP_Better_Experience
 * @subpackage Bootstrap
 * @copyright  Copyright (c) 2018, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Better_Experience\Bootstrap;

use BP_Better_Experience\Modules\Avatar\BPBEXP_Avatar_Loader;
use BP_Better_Experience\Modules\Cover\BPBEXP_Cover_Loader;
use BP_Better_Experience\Admin\Admin_Settings;
use BP_Better_Experience\Modules\Registration\Disable_Confirm_Password;
use BP_Better_Experience\Modules\Registration\Disable_Full_Name;
use BP_Better_Experience\Modules\Restrictions\Restrict_Admin_Access;
use BP_Better_Experience\Modules\Shortcodes\BuddyPress\BP_Shortcodes;
use BP_Better_Experience\Modules\Shortcodes\Post_Shortcodes;

// No direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 0 );
}

/**
 * Bootstrapper.
 */
class Bootstrapper {

	/**
	 * Setup the bootstrapper.
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Bind hooks
	 */
	private function setup() {
		add_action( 'bp_loaded', array( $this, 'load' ) );
		add_action( 'bp_init', array( $this, 'load_translations' ) );
		add_action( 'bp_init', array( $this, 'bootstrap' ), 11 );

		add_action( 'plugins_loaded', array( $this, 'load_admin' ), 9995 ); // pt settings 1.0.4.
	}

	/**
	 * Load core functions/template tags.
	 * These are non auto loadable constructs.
	 */
	public function load() {
		$path = bp_better_experience()->path;

		$files = array(
			'src/core/bpbexp-functions.php',
		);

		foreach ( $files as $file ) {
			require_once $path . $file;
		}
	}

	/**
	 * Load translations.
	 */
	public function load_translations() {
		load_plugin_textdomain( 'bp-better-experience', false, basename( dirname( bp_better_experience()->path ) ) . '/languages' );
	}

	/**
	 * Boot class
	 */
	public function bootstrap() {
		Assets_Loader::boot();
		BPBEXP_Avatar_Loader::boot();
		BPBEXP_Cover_Loader::boot();
		Disable_Confirm_Password::boot();
		Disable_Full_Name::boot();
		BP_Shortcodes::boot();
		Post_Shortcodes::boot();
		Restrict_Admin_Access::boot();
	}

	/**
	 * Load pt-settings framework
	 */
	public function load_admin() {

		if ( function_exists( 'buddypress' ) && is_admin() && ! defined( 'DOING_AJAX' ) ) {
			require_once bp_better_experience()->path . 'src/admin/pt-settings/pt-settings-loader.php';
			Admin_Settings::boot();
		}
	}
}
