<?php
/**
 * Assets Loader
 *
 * @package    BP_Better_Experience
 * @subpackage Bootstrap
 * @copyright  Copyright (c) 2018, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Better_Experience\Bootstrap;

use BP_Better_Experience\Traits\BPBEXP_Bootable;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 0 );
}

/**
 * Assets Loader.
 */
class Assets_Loader {

	use BPBEXP_Bootable;

	/**
	 * Data to be send as localized js.
	 *
	 * @var array
	 */
	private $data = array();

	/**
	 * Setup
	 */
	public function setup() {
		add_action( 'bp_enqueue_scripts', array( $this, 'load_assets' ) );
	}

	/**
	 * Load plugin assets
	 */
	public function load_assets() {
		$this->register();
		$this->enqueue();
	}

	/**
	 * Register assets.
	 */
	public function register() {
		$this->register_vendors();
		$this->register_core();
	}

	/**
	 * Load assets.
	 */
	public function enqueue() {
		wp_enqueue_style( 'bp_better_experience_css' );
		wp_enqueue_script( 'bp_better_experience_js' );

		wp_localize_script( 'bp_better_experience_js', 'BP_Better_Experience', $this->data );
	}

	/**
	 * Register vendor scripts.
	 */
	private function register_vendors() {
		do_action( 'bp_better_experience_register_vendors_assets' );
	}

	/**
	 * Register core assets.
	 */
	private function register_core() {
		$bpbexp  = bp_better_experience();
		$url     = $bpbexp->url;
		$version = $bpbexp->version;

		do_action( 'bp_better_experience_register_core_assets' );

		wp_register_style(
			'bp_better_experience_css',
			$url . 'assets/css/bp-better-experience.css',
			apply_filters( 'bp_better_experience_css_dependencies', false ),
			$version
		);

		$suffix = '.min';

		wp_register_script(
			'bp_better_experience_js',
			$url . "assets/js/bp-better-experience$suffix.js",
			apply_filters( 'bp_better_experience_js_dependencies', array( 'jquery' ) ),
			$version,
			true
		);

		$this->data = apply_filters( 'bp_better_experience_localize_args', array() );
	}
}
