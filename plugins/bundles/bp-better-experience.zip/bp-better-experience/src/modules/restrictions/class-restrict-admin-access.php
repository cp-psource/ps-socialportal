<?php
/**
 * Restrict user access to dashboard.
 *
 * @package    BP_Better_Experience
 * @subpackage Restrictions
 * @copyright  Copyright (c) 2020, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Better_Experience\Modules\Restrictions;

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Restrict access to admin.
 */
class Restrict_Admin_Access {

	/**
	 * Boot.
	 */
	public static function boot() {
		$self = new self();
		$self->setup();

		return $self;
	}

	/**
	 * Setup.
	 */
	private function setup() {
		if ( ! bpbexp_get_option( 'restrict-dashboard-access' ) ) {
			return;
		}

		add_action( 'admin_init', array( $this, 'restrict' ) );
		// should we hook to 'admin_page_access_denied' too?
	}


	/**
	 * Restrict access.
	 */
	public function restrict() {

		// do not prevent ajax requests.
		if ( wp_doing_ajax() || ! is_user_logged_in() || is_super_admin() ) {
			return;
		}

		$allowed_roles = bpbexp_get_option( 'dashboard-allowed-roles', array() );

		// always allow administrator. should we?
		$allowed_roles = array_merge( $allowed_roles, array( 'administrator' ) );

		$user = wp_get_current_user();
		// allow.
		if ( $user->roles && array_intersect( $user->roles, $allowed_roles ) ) {
			return;
		}

		$dashboard_redirect_url = $this->parse_url( bpbexp_get_option( 'dashboard-restricted-redirect-url', '[user-profile-url]' ) );
		if ( empty( $dashboard_redirect_url ) ) {
			$dashboard_redirect_url = site_url( '/' );
		}

		// should we use safe_redirect instead?
		wp_redirect( $dashboard_redirect_url );
		exit( 0 );
	}

	/**
	 * Parse url.
	 *
	 * @param $string
	 *
	 * @return string
	 */
	private function parse_url( $string ) {
		if ( empty( $string ) ) {
			return $string;
		}

		return str_replace(
			array(
				'[user-profile-url]',
				'[home-url]',
			),
			array(
				untrailingslashit( bp_loggedin_user_domain() ),
				site_url( '/' ),
			),
			$string
		);
	}
}
