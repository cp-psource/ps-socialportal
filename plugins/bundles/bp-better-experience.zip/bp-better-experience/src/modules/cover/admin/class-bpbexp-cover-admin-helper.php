<?php
/**
 * Avatar loader
 *
 * @package    BP_Better_Experience
 * @subpackage Modules\Cover\Admin
 * @copyright  Copyright (c) 2020, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Better_Experience\Modules\Cover\Admin;

use BP_Better_Experience\Traits\BPBEXP_Bootable;
use Press_Themes\PT_Settings\Panel;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class BPBEXP_Cover_Admin_Helper
 */
class BPBEXP_Cover_Admin_Helper {

	use BPBEXP_Bootable;

	/**
	 * Setup class.
	 */
	private function setup() {
		add_action( 'bp_better_experience_admin_settings_general', array( $this, 'add_settings' ) );
	}

	/**
	 * Register avatar settings
	 *
	 * @param Panel $general General panel.
	 */
	public function add_settings( $general ) {

		$cover_section = $general->add_section( 'bpbexp_cover', __( 'Cover Einstellungen', 'bp-better-experience' ) );

		$fields = array(
			array(
				'name'    => 'enable_cover',
				'label'   => _x( 'Aktiviere das Hochladen des gleichen Covers für Benutzer und Gruppen', 'Admin settings', 'bp-better-experience' ),
				'type'    => 'radio',
				'options' => array(
					1 => _x( 'Ja', 'Admin settings', 'bp-better-experience' ),
					0 => _x( 'Nein', 'Admin settings', 'bp-better-experience' ),
				),
				'default' => 1,
			),
		);

		$cover_section->add_fields( $fields );
	}
}