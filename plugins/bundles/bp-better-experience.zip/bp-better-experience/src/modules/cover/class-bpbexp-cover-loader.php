<?php
/**
 * Cover loader
 *
 * @package    BP_Better_Experience
 * @subpackage Modules\Cover
 * @copyright  Copyright (c) 2020, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Better_Experience\Modules\Cover;

use BP_Better_Experience\Modules\Cover\Admin\BPBEXP_Cover_Admin_Helper;
use BP_Better_Experience\Traits\BPBEXP_Bootable;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class BPBEXP_Cover_Loader
 */
class BPBEXP_Cover_Loader {

	use BPBEXP_Bootable;

	/**
	 * Setup class.
	 */
	private function setup() {
		BPBEXP_Cover_Admin_Helper::boot();

		if ( bpbexp_get_option( 'enable_cover', 1 ) ) {
			BPBEXP_Cover_Helper::boot();
		}
	}
}