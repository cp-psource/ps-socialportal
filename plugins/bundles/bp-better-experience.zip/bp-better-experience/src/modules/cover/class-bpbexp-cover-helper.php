<?php
/**
 * Cover Helper class
 *
 * @package    BP_Better_Experience
 * @subpackage Modules\Cover
 * @copyright  Copyright (c) 2020, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Better_Experience\Modules\Cover;

use BP_Better_Experience\Traits\BPBEXP_Bootable;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class BPBEXP_Cover_Helper
 */
class BPBEXP_Cover_Helper {

    use BPBEXP_Bootable;

	/**
	 * Setup class
	 */
	private function setup() {

		if ( ! $this->user_can_change_cover() ) {
			return;
		}

		add_action( 'bp_better_experience_register_vendors_assets', array( $this, 'register_vendors_assets' ) );
		add_action( 'bp_better_experience_register_core_assets', array( $this, 'register_core_assets' ) );

		add_filter( 'bp_better_experience_css_dependencies', array( $this, 'modify_css_dependencies' ) );
		add_filter( 'bp_better_experience_js_dependencies', array( $this, 'modify_js_dependencies' ) );
		add_filter( 'bp_better_experience_localize_args', array( $this, 'modify_localize_args' ) );

		add_action( 'wp_footer', array( $this, 'add_footer_content' ) );
	}

	/**
	 * Register vendors
	 */
	public function register_vendors_assets() {
		$url = bp_better_experience()->url;

		wp_register_style(
			'magnific-css',
			$url . 'assets/vendors/magnific/magnific-popup.css',
			array(),
			'1.0.0'
		);

		wp_register_script(
			'magnific-js',
			$url . 'assets/vendors/magnific/jquery.magnific-popup.min.js',
			array( 'jquery' ),
			'1.0.0',
			true
		);

		wp_register_style(
			'jquery-upload-file-css',
			$url . 'assets/vendors/jquery-upload-file/uploadfile.css',
			array(),
			'4.0.11'
		);

		wp_register_script(
			'jquery-upload-file-js',
			$url . 'assets/vendors/jquery-upload-file/jquery.uploadfile.js',
			array( 'jquery' ),
			'4.0.11',
			true
		);
	}

	/**
	 * Register core assets
	 */
	public function register_core_assets() {
		$bpbexp = bp_better_experience();

		wp_register_style(
			'bpbexp_cover_css',
			$bpbexp->url . 'src/modules/cover/assets/css/bpbexp-cover.css',
			array( 'magnific-css', 'jquery-upload-file-css' ),
			$bpbexp->version
		);
		$suffix = '.min';
		wp_register_script(
			'bpbexp_cover_js',
			$bpbexp->url . "src/modules/cover/assets/js/bpbexp-cover$suffix.js",
			array( 'jquery', 'magnific-js', 'jquery-upload-file-js' ),
			$bpbexp->version,
			true
		);
	}

	/**
	 * Modify css dependencies
	 *
	 * @param false|array $dependencies Dependencies.
	 *
	 * @return array
	 */
	public function modify_css_dependencies( $dependencies ) {
		$css_dependencies = array( 'bpbexp_cover_css' );

		if ( empty( $dependencies ) ) {
			return $css_dependencies;
		}

		return array_merge( $css_dependencies, (array) $dependencies );
	}

	/**
	 * Modify js dependencies
	 *
	 * @param array $dependencies Dependencies.
	 *
	 * @return array
	 */
	public function modify_js_dependencies( $dependencies ) {
		$js_dependencies = array( 'bpbexp_cover_js' );

		if ( empty( $dependencies ) ) {
			return $js_dependencies;
		}

		return array_merge( $js_dependencies, (array) $dependencies );
	}

	/**
	 * Modify localize args
	 *
	 * @param array $localize_args Localize args.
	 *
	 * @return array
	 */
	public function modify_localize_args( $localize_args ) {

		if ( ! isset( $localize_args['upload_nonce'] ) ) {
			$localize_args['upload_nonce'] = wp_create_nonce( 'bp-uploader' );
		}

		$object  = 'user';
		$item_id = bp_displayed_user_id();

		if ( bp_is_group() ) {
			$object  = 'group';
			$item_id = bp_get_current_group_id();
		}

		if ( ! isset( $localize_args['cover_params'] ) ) {
			$localize_args['cover_params'] = array(
				'object'     => $object,
				'item_id'    => $item_id,
				'upload_str' => __( 'Cover wechseln', 'bp-better-experience' ),
			);
		}

		return $localize_args;
	}

	/**
	 * Add footer content
	 */
	public function add_footer_content() {

		?>
		<div class="bpbexp-cover-edit" style="display: none;">
			<p id="bpbexp-cover-message"></p>
			<div id="bpbexp-cover-uploder"><?php esc_html_e( 'Hochladen', 'bp-better-experience' ); ?></div>
		</div>
		<?php
	}

	/**
	 * Check if user can change cover image.
	 *
	 * @return bool
	 */
	private function user_can_change_cover() {

		if ( ! is_user_logged_in() ) {
			return false;
		}

		$can_change = false;

		if ( is_super_admin() ) {
			$can_change = true;
		} elseif ( bp_is_user() && bp_is_my_profile() ) {
			$can_change = true;
		} elseif ( bp_is_group() && groups_is_user_admin( get_current_user_id(), bp_get_current_group_id() ) ) {
			$can_change = true;
		}

		return $can_change;
	}
}
