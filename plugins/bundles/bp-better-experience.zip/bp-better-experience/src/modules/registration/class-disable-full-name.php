<?php
/**
 * Set username as display name
 *
 *
 * @package    BP_Better_Experience
 * @subpackage Modules/Registration
 * @copyright  Copyright (c) 2020, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Better_Experience\Modules\Registration;

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Full name disabler(uses username for display name).
 */
class Disable_Full_Name {

	/**
	 * Boot.
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
		return $self;
	}

	/**
	 * Setup hooks.
	 */
	private function setup() {

		if ( ! bpbexp_get_option( 'registration-disable-full-name' ) ) {
			return;
		}

		// Add one or more action handler callback.
		// Goal is to keep the code related to single functionality encapsulated.
		add_action( 'bp_signup_pre_validate', array( $this, 'handle' ) );
		add_filter( 'bp_get_form_field_attributes', array( $this, 'disable_required_attributes' ), 10, 2 );
		add_action( 'wp_head', array( $this, 'add_css' ) );
	}

	/**
	 * Before validation, update full name with username.
	 */
	public function handle() {

		if ( ! function_exists( 'bp_xprofile_fullname_field_id' ) ) {
			return;
		}

		if ( isset( $_POST['signup_username'] ) ) {
			$_POST[ 'field_' . bp_xprofile_fullname_field_id() ] = sanitize_user( $_POST['signup_username'] );
		}
	}

	/**
	 * Disable client side required attribute in input field to avoid failing of form submission.
	 * All modern browsers will not submit if a field is marked as required and does not have the value.
	 *
	 * @param array  $atts input field attributes.
	 * @param string $field_name field name.
	 *
	 * @return array
	 */
	public function disable_required_attributes( $atts, $field_name ) {

		global $field;
		$fullname_field_id = bp_xprofile_fullname_field_id();

		if ( $field && $fullname_field_id !== $field->id ) {
			return $atts;
		}

		foreach ( $atts as $key => $value ) {
			if ( 'required' === $value ) {
				unset( $atts[ $key ] );
				break;
			}
		}
		return $atts;
	}


	/**
	 * Hide full name field.
	 */
	public function add_css() {
		if ( ! bp_is_register_page() || ! function_exists( 'bp_xprofile_fullname_field_id' ) ) {
			return;
		}

		?>
		<style type="text/css">
			.editfield.field_<?php echo bp_xprofile_fullname_field_id();?> {
				display: none;
			}
		</style>
		<?php
	}
}
