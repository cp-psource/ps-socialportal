<?php
/**
 * Disable Confirm Password
 *
 * Disables confirm password on registration page.
 *
 * @package    BP_Better_Experience
 * @subpackage Modules/Registration
 * @copyright  Copyright (c) 2020, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Better_Experience\Modules\Registration;

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Confirm password disabler.
 */
class Disable_Confirm_Password {

	/**
	 * Boot.
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
		return $self;
	}

	/**
	 * Setup hooks.
	 */
	private function setup() {

		if ( ! bpbexp_get_option( 'registration-disable-confirm-password' ) ) {
			return;
		}

		// Add one or more action handler callback.
		// Goal is to keep the code related to single functionality encapsulated.
		add_action( 'bp_signup_pre_validate', array( $this, 'handle' ) );
		add_action( 'wp_head', array( $this, 'add_css' ) );
	}

	/**
	 * Before validation, update confirm pass with signup pass.
	 */
	public function handle() {

		if ( isset( $_POST['signup_password'] ) ) {
			$_POST['signup_password_confirm'] = $_POST['signup_password'];
		}
	}

	/**
	 * Hide confirm password input.
	 */
	public function add_css() {
		if ( ! bp_is_register_page() ) {
			return;
		}
		?>
		<style type="text/css">
			.editfield-confirm-passowrd {
				display: none;
			}
		</style>
		<?php
	}
}
