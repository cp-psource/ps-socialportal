<?php
/**
 * Avatar loader
 *
 * @package    BP_Better_Experience
 * @subpackage Modules\Avatar
 * @copyright  Copyright (c) 2020, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Better_Experience\Modules\Avatar\Admin;

use BP_Better_Experience\Traits\BPBEXP_Bootable;
use Press_Themes\PT_Settings\Panel;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class BPBEXP_Avatar_Loader
 */
class BPBEXP_Avatar_Admin_Helper {

	use BPBEXP_Bootable;

	/**
	 * Setup class.
	 */
	private function setup() {
		add_action( 'bp_better_experience_admin_settings_general', array( $this, 'add_settings' ) );
	}

	/**
	 * Register avatar settings
	 *
	 * @param Panel $general General panel.
	 */
	public function add_settings( $general ) {

		$avatar_section = $general->add_section( 'bpbexp_avatar', __( 'Avatar-Einstellungen', 'bp-better-experience' ) );

		$fields = array(
			array(
				'name'    => 'enable_avatar',
				'label'   => _x( 'Aktiviere das Hochladen des gleichen Seiten-Avatars für Benutzer und Gruppen', 'Admin settings', 'bp-better-experience' ),
				'type'    => 'radio',
				'options' => array(
					1 => _x( 'Ja', 'Admin settings', 'bp-better-experience' ),
					0 => _x( 'Nein', 'Admin settings', 'bp-better-experience' ),
				),
				'default' => 1,
			),
		);

		$avatar_section->add_fields( $fields );
	}
}