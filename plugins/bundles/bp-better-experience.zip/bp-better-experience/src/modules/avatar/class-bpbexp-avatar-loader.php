<?php
/**
 * Avatar loader
 *
 * @package    BP_Better_Experience
 * @subpackage Modules\Avatar
 * @copyright  Copyright (c) 2020, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Better_Experience\Modules\Avatar;

use BP_Better_Experience\Modules\Avatar\Admin\BPBEXP_Avatar_Admin_Helper;
use BP_Better_Experience\Traits\BPBEXP_Bootable;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class BPBEXP_Avatar_Loader
 */
class BPBEXP_Avatar_Loader {

	use BPBEXP_Bootable;

	/**
	 * Setup class.
	 */
	private function setup() {
		BPBEXP_Avatar_Admin_Helper::boot();

		if ( bpbexp_get_option( 'enable_avatar', 1 ) ) {
			BPBEXP_Avatar_Helper::boot();
		}
	}
}