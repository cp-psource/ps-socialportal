<?php
/**
 * Avatar Helper class
 *
 * @package    BP_Better_Experience
 * @subpackage Modules\Avatar
 * @copyright  Copyright (c) 2020, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Better_Experience\Modules\Avatar;

use BP_Better_Experience\Traits\BPBEXP_Bootable;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class BPBEXP_Avatar_Helper
 */
class BPBEXP_Avatar_Helper {

	use BPBEXP_Bootable;

	/**
	 * Setup class
	 */
	private function setup() {

		if ( ! $this->user_can_change_avatar() ) {
			return;
		}

		add_action( 'bp_better_experience_register_vendors_assets', array( $this, 'register_vendors_assets' ) );
		add_action( 'bp_better_experience_register_core_assets', array( $this, 'register_core_assets' ) );

		add_filter( 'bp_better_experience_css_dependencies', array( $this, 'modify_css_dependencies' ) );
		add_filter( 'bp_better_experience_js_dependencies', array( $this, 'modify_js_dependencies' ) );
		add_filter( 'bp_better_experience_localize_args', array( $this, 'modify_localize_args' ) );

		add_action( 'wp_footer', array( $this, 'add_footer_content' ) );
	}

	/**
	 * Register vendors
	 */
	public function register_vendors_assets() {
		$url = bp_better_experience()->url;

		wp_register_style(
			'magnific-css',
			$url . 'assets/vendors/magnific/magnific-popup.css',
			array(),
			'1.0.0'
		);

		wp_register_script(
			'magnific-js',
			$url . 'assets/vendors/magnific/jquery.magnific-popup.min.js',
			array( 'jquery' ),
			'1.0.0',
			true
		);

		wp_register_style(
			'jquery-upload-file-css',
			$url . 'assets/vendors/jquery-upload-file/uploadfile.css',
			array(),
			'4.0.11'
		);

		wp_register_script(
			'jquery-upload-file-js',
			$url . 'assets/vendors/jquery-upload-file/jquery.uploadfile.js',
			array( 'jquery' ),
			'4.0.11',
			true
		);

		wp_register_style(
			'cropperjs-css',
			$url . 'assets/vendors/cropperjs/cropper.css',
			array(),
			'1.3.4'
		);

		wp_register_script(
			'cropperjs',
			$url . 'assets/vendors/cropperjs/cropper.min.js',
			array( 'jquery' ),
			'1.3.4',
			true
		);

		wp_register_script(
			'jquery-cropper',
			$url . 'assets/vendors/jquery-cropper/jquery-cropper.min.js',
			array( 'jquery', 'cropperjs' ),
			'1.0.0',
			true
		);
	}

	/**
	 * Register core assets
	 */
	public function register_core_assets() {
		$bpbexp = bp_better_experience();

		wp_register_style(
			'bpbexp_avatar_css',
			$bpbexp->url . 'src/modules/avatar/assets/css/bpbexp-avatar.css',
			array( 'magnific-css', 'jquery-upload-file-css', 'cropperjs-css' ),
			$bpbexp->version
		);

		$suffix = '.min';

		wp_register_script(
			'bpbexp_avatar_js',
			$bpbexp->url . "src/modules/avatar/assets/js/bpbexp-avatar$suffix.js",
			array( 'jquery', 'magnific-js', 'jquery-upload-file-js', 'cropperjs', 'jquery-cropper' ),
			$bpbexp->version,
			true
		);

	}

	/**
	 * Modify css dependencies
	 *
	 * @param false|array $dependencies Dependencies.
	 *
	 * @return array
	 */
	public function modify_css_dependencies( $dependencies ) {
		$avatar_dependencies = array( 'bpbexp_avatar_css' );

		if ( empty( $dependencies ) ) {
			return $avatar_dependencies;
		}

		return array_merge( $avatar_dependencies, (array) $dependencies );
	}

	/**
	 * Modify js dependencies
	 *
	 * @param false|array $dependencies Dependencies.
	 *
	 * @return array
	 */
	public function modify_js_dependencies( $dependencies ) {
		$avatar_dependencies = array( 'bpbexp_avatar_js' );

		if ( empty( $dependencies ) ) {
			return $avatar_dependencies;
		}

		return array_merge( $avatar_dependencies, (array) $dependencies );
	}

	/**
	 * Modify localize args
	 *
	 * @param array $localize_args Localize args.
	 *
	 * @return array
	 */
	public function modify_localize_args( $localize_args ) {

		if ( ! isset( $localize_args['upload_nonce'] ) ) {
			$localize_args['upload_nonce'] = wp_create_nonce( 'bp-uploader' );
		}

		if ( ! isset( $localize_args['crop_nonce'] ) ) {
			$localize_args['crop_nonce'] = wp_create_nonce( 'bp_avatar_cropstore' );
		}

		$object  = 'user';
		$item_id = bp_displayed_user_id();

		if ( bp_is_group() ) {
			$object  = 'group';
			$item_id = bp_get_current_group_id();
		}

		if ( ! isset( $localize_args['avatar_params'] ) ) {
			$localize_args['avatar_params'] = array(
				'object'     => $object,
				'item_id'    => $item_id,
				'upload_str' => __( 'Avatar ändern', 'bp-better-experience' ),
			);
		}

		return $localize_args;
	}

	/**
	 * Add footer content
	 */
	public function add_footer_content() {

		?>
		<div class="bpbexp-avatar-edit" style="display: none;">
			<p id="bpbexp-avatar-message"></p>
			<div id="bpbexp-avatar-uploader">
				<?php esc_html_e( 'Upload', 'bp-better-experience' ); ?>
			</div>
			<div id="bpbexp-avatar-cropper" style="display: none;">
				<div id="bpbexp-avatar-croppable-photo-container" class="bpbexp-avatar-croppable-photo-container"></div>
				<button class="bpbexp-avatar-btn bpbexp-avatar-btn-sm button" id="bpbexp-avatar-crop-button">
					<?php esc_html_e( 'Anwenden', 'bp-better-experience' ); ?>
				</button>
			</div>
		</div>
		<?php
	}

	/**
	 * Check if user can change avatar image.
	 *
	 * @return bool
	 */
	private function user_can_change_avatar() {

		if ( ! is_user_logged_in() ) {
			return false;
		}

		// By default BuddyPress allows user to change avatar.
		$can_change = false;

		if ( is_super_admin() ) {
		    $can_change = true;
        } elseif ( bp_is_user() && bp_is_my_profile() ) {
			$can_change = true;
		} elseif ( bp_is_group() && groups_is_user_admin( get_current_user_id(), bp_get_current_group_id() ) ) {
			$can_change = true;
		}

		return $can_change;
	}
}
