<?php
/**
 * Core functions file
 *
 * @package BP_Better_Experience
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get setting
 *
 * @param string $setting Setting name.
 * @param mixed  $default Setting default value.
 *
 * @return mixed
 */
function bpbexp_get_option( $setting = '', $default = null ) {
	$settings = get_option( 'bp_better_experience_settings', array() );

	if ( isset( $settings[ $setting ] ) ) {
		return $settings[ $setting ];
	}

	return $default;
}