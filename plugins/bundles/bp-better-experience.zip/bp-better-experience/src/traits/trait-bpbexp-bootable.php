<?php
/**
 * Bootable trait
 *
 * @package    BP_Better_Experience
 * @subpackage Traits
 * @copyright  Copyright (c) 2020, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Better_Experience\Traits;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Trait BPBEXP_Bootable
 */
trait BPBEXP_Bootable {

	/**
	 * Boot class.
	 */
	public static function boot() {
		$self = new self();

		$self->setup();
	}
}