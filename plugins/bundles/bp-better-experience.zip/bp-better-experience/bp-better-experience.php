<?php
/**
 * Plugin Name: BuddyPress Bessere Erfahrung
 * Version: 1.0.2
 * Plugin URI: https://n3rds.work/piestingtal_source/ps-socialportal-theme/
 * Description: Dies ist ein Addon für BuddyPress. Es verbessert die Benutzererfahrung der Webseite mit BuddyPress.
 * Author: WMS N@W
 * Author URI: https://n3rds.work
 * Requires PHP: 5.3
 * License:      GPL2
 * License URI:  https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:  bp-better-experience
 * Domain Path:  /languages
 *
 * @package bp-better-experience
 **/

use BP_Better_Experience\Bootstrap\Autoloader;
use BP_Better_Experience\Bootstrap\Bootstrapper;

// No direct access over web.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BP_Better_Experience
 *
 * @property-read $path     string Absolute path to the plugin directory.
 * @property-read $url      string Absolute url to the plugin directory.
 * @property-read $basename string Plugin base name.
 * @property-read $version  string Plugin version.
 */
class BP_Better_Experience {

	/**
	 * Plugin Version.
	 *
	 * @var string
	 */
	private $version = '1.0.2';

	/**
	 * Class instance
	 *
	 * @var BP_Better_Experience
	 */
	private static $instance = null;

	/**
	 * Plugin absolute directory path
	 *
	 * @var string
	 */
	private $path;

	/**
	 * Plugin absolute directory url
	 *
	 * @var string
	 */
	private $url;

	/**
	 * Plugin Basename.
	 *
	 * @var string
	 */
	private $basename;

	/**
	 * Protected properties. These properties are inaccessible via magic method.
	 *
	 * @var array
	 */
	private $protected_properties = array( 'instance' );

	/**
	 * BP_Better_Experience constructor.
	 */
	private function __construct() {
		$this->bootstrap();
	}

	/**
	 * Get Singleton Instance
	 *
	 * @return BP_Better_Experience
	 */
	public static function get_instance() {

		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Bootstrap the core.
	 */
	private function bootstrap() {
		$this->path     = plugin_dir_path( __FILE__ );
		$this->url      = plugin_dir_url( __FILE__ );
		$this->basename = plugin_basename( __FILE__ );

		// Load autoloader.
		require_once $this->path . 'src/bootstrap/class-autoloader.php';

		$autoloader = new Autoloader( 'BP_Better_Experience\\', __DIR__ . '/src/' );

		spl_autoload_register( $autoloader );

		register_activation_hook( __FILE__, array( $this, 'on_activation' ) );
		register_deactivation_hook( __FILE__, array( $this, 'on_deactivation' ) );

		// Drop tables on uninstall.
		// register_uninstall_hook( __FILE__, array( 'Schema', 'drop' ) );.

		Bootstrapper::boot();
	}

	/**
	 * On activation create table
	 */
	public function on_activation(){

	}

	/**
	 * On deactivation. Do cleanup if needed.
	 */
	public function on_deactivation() {

	}

	/**
	 * Magic method for accessing property as readonly(It's a lie, references can be updated).
	 *
	 * @param string $name property name.
	 *
	 * @return mixed|null
	 */
	public function __get( $name ) {

		if ( ! in_array( $name, $this->protected_properties, true ) && property_exists( $this, $name ) ) {
			return $this->{$name};
		}

		return null;
	}
}

/**
 * Helper to access singleton instance
 *
 * @return BP_Better_Experience
 */
function bp_better_experience() {
	return BP_Better_Experience::get_instance();
}

bp_better_experience();
