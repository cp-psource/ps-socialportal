<?php
/**
 * Panels.
 *
 * @package    BP Ajax Registration
 * @copyright  Copyright(c) 2018, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.1
 */

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

?>
<div id="bpajaxr-panels-container" class="bpajaxr-panels-container">
    <div id="bpajaxr-panels" class="bpajaxr-panels">

        <?php if ( bpajaxr_get_option( 'enable_login' ) ) : ?>
			<?php bpajaxr_load_template( 'panel-login.php' ); ?>
		<?php endif; ?>

		<?php if ( bp_get_signup_allowed() && bpajaxr_get_option( 'enable_registration' ) ) : ?>
			<?php bpajaxr_load_template( 'panel-registration.php' ); ?>
		<?php endif; ?>

        <?php if ( bpajaxr_get_option( 'enable_forget_password' ) ) : ?>
			<?php bpajaxr_load_template( 'panel-forget-password.php' ); ?>
		<?php endif; ?>

    </div>
</div>
