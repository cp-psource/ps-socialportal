<?php
/**
 * Registration panel.
 *
 * @package    BP Ajax Registration
 * @copyright  Copyright (c) 2018, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.1
 */

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

if ( ! isset( buddypress()->signup->step ) ) {
	buddypress()->signup->step = 'request-details';
}
?>
<div class="bpajaxr-panel bpajaxr-panel-registration bpajaxr-panel-visible" data-bpajaxr-panel="registration">
    <div class="bpajaxr-panel-inner">
        <div class="bpajaxr-panel-title bpajaxr-registration-panel-title">
            <span><?php _e( 'Benutzerkonto erstellen!', 'bp-ajax-registration' ) ?></span>
        </div>
		<?php bpajaxr_helper()->render_feedback(); ?>
		<?php do_action( 'template_notices' ) ?>

        <form action="" name="signup_form" id="register_form" class="" method="post" enctype="multipart/form-data">

			<?php if ( 'request-details' == bp_get_current_signup_step() ) : ?>
				<?php do_action( 'bp_before_account_details_fields' ) ?>

                <div class="register-section" id="basic-details-section">
					<?php /***** Basic Account Details ******/ ?>

                    <h4><?php _e( 'Account Details', 'bp-ajax-registration' ) ?></h4>
                    <div class="bpajaxr-form-group bpajaxr-form-group-username">
                        <label for="signup_username"><?php _e( 'Nutzername', 'bp-ajax-registration' ) ?><?php _e( '(benötigt)', 'bp-ajax-registration' ) ?></label>
						<?php do_action( 'bp_signup_username_errors' ) ?>
                        <input type="text" name="signup_username" id="signup_username"
                               value="<?php bp_signup_username_value() ?>"/>
                    </div>

                    <div class="bpajaxr-form-group bpajaxr-form-group-email">
                        <label for="signup_email"><?php _e( 'Email Addresse', 'bp-ajax-registration' ) ?><?php _e( '(benötigt)', 'bp-ajax-registration' ) ?></label>
						<?php do_action( 'bp_signup_email_errors' ) ?>
                        <input type="text" name="signup_email" id="signup_email"
                               value="<?php bp_signup_email_value() ?>"/>
                    </div>
                    <div class="bpajaxr-form-group bpajaxr-form-group-password">
                        <label for="signup_password"><?php _e( 'Wähle ein Passwort', 'bp-ajax-registration' ) ?><?php _e( '(benötigt)', 'bp-ajax-registration' ) ?></label>
						<?php do_action( 'bp_signup_password_errors' ) ?>
                        <input type="password" name="signup_password" id="signup_password" value=""/>
                    </div>
                    <div class="bpajaxr-form-group bpajaxr-form-group-confirm-password">
                        <label for="signup_password_confirm"><?php _e( 'Passwort bestätigen', 'bp-ajax-registration' ) ?><?php _e( '(benötigt)', 'bp-ajax-registration' ) ?></label>
						<?php do_action( 'bp_signup_password_confirm_errors' ) ?>
                        <input type="password" name="signup_password_confirm" id="signup_password_confirm" value=""/>
                    </div>
                </div><!-- #basic-details-section -->

				<?php do_action( 'bp_after_account_details_fields' ) ?>
				<?php /***** Extra Profile Details ******/ ?>

				<?php if ( bp_is_active( 'xprofile' ) ) : ?>

					<?php do_action( 'bp_before_signup_profile_fields' ) ?>

                    <div class="register-section" id="profile-details-section">

						<?php /* Use the profile field loop to render input fields for the 'base' profile field group */ ?>
						<?php if ( bp_is_active( 'xprofile' ) ) :
							if ( bp_has_profile( apply_filters( 'bpajaxr_xprofile_args', 'profile_group_id=1&hide_empty_fields=0&hide_empty_groups=0' ) ) ) :
								while ( bp_profile_groups() ) : bp_the_profile_group();
									?>

									<?php while ( bp_profile_fields() ) : bp_the_profile_field(); ?>

                                        <div class="editfield">

											<?php
											$field_type = bp_xprofile_create_field_type( bp_get_the_profile_field_type() );
											$field_type->edit_field_html();
											?>

											<?php do_action( 'bp_custom_profile_edit_fields' ) ?>
											<?php do_action( 'bp_custom_profile_edit_fields_pre_visibility' ) ?>

                                        </div>

									<?php endwhile; ?>
									<?php $fields_ids[] = bp_get_the_profile_group_field_ids();//COLLECT FIELD IDS?>

								<?php endwhile; endif; endif; ?>
                        <input type="hidden" name="signup_profile_field_ids" id="signup_profile_field_ids"
                               value="<?php echo implode( ",", $fields_ids ); ?>"/>

                    </div><!-- #profile-details-section ends here -->

					<?php do_action( 'bp_after_signup_profile_fields' ) ?>

				<?php endif; ?>

				<?php if ( bp_get_blog_signup_allowed() ) : ?>
					<?php do_action( 'bp_before_blog_details_fields' ) ?>
					<?php /***** Blog Creation Details ******/ ?>

                    <div class="register-section" id="blog-details-section">
                        <h4><?php _e( 'Benötigst Du einen Blog?', 'bp-ajax-registration' ) ?></h4>
                        <p>
                            <input type="checkbox" name="signup_with_blog" class="signup_with_blog" id="signup_with_blog" value="1"<?php if ( (int) bp_get_signup_with_blog_value() ) : ?> checked="checked"<?php endif; ?> /> <?php _e( 'Ja, ich möchte eine neue Seite erstellen', 'bp-ajax-registration' ) ?>
                        </p>

                        <div id="blog-details" <?php if ( (int) bp_get_signup_with_blog_value() ) : ?>class="bpajaxr-visible"<?php else :?> class="bpajaxr-invisible" <?php endif; ?>>

                            <label for="signup_blog_url"><?php _e( 'Blog URL', 'bp-ajax-registration' ) ?><?php _e( '(benötigt)', 'bp-ajax-registration' ) ?></label>
							<?php do_action( 'bp_signup_blog_url_errors' ) ?>

							<?php if ( is_subdomain_install() ) : ?>
                                http:// <input type="text" name="signup_blog_url" id="signup_blog_url"
                                               value="<?php bp_signup_blog_url_value() ?>"/> .<?php echo preg_replace( '|^https?://(?:www\.)|', '', network_site_url() ) ?>
							<?php else : ?>
								<?php echo network_site_url('/') ?> <input type="text" name="signup_blog_url" id="signup_blog_url" value="<?php bp_signup_blog_url_value() ?>"/>
							<?php endif; ?>

                            <label for="signup_blog_title"><?php _e( 'Seitentitel', 'bp-ajax-registration' ) ?><?php _e( '(required)', 'bp-ajax-registration' ) ?></label>
							<?php do_action( 'bp_signup_blog_title_errors' ) ?>
                            <input type="text" name="signup_blog_title" id="signup_blog_title"
                                   value="<?php bp_signup_blog_title_value() ?>"/>

                            <span class="label"><?php _e( 'Ich möchte, dass meine Webseite in Suchmaschinen und in öffentlichen Listen in diesem Netzwerk angezeigt wird.', 'bp-ajax-registration' ) ?>
                                :</span>
							<?php do_action( 'bp_signup_blog_privacy_errors' ) ?>

                            <label>
                                <input type="radio" name="signup_blog_privacy" id="signup_blog_privacy_public"
                                       value="public"<?php if ( 'public' == bp_get_signup_blog_privacy_value() || ! bp_get_signup_blog_privacy_value() ) : ?> checked="checked"<?php endif; ?> /> <?php _e( 'Ja', 'bp-ajax-registration' ) ?>
                            </label>
                            <label>
                                <input type="radio" name="signup_blog_privacy" id="signup_blog_privacy_private"
                                       value="private"<?php if ( 'private' == bp_get_signup_blog_privacy_value() ) : ?> checked="checked"<?php endif; ?> /> <?php _e( 'Nein', 'bp-ajax-registration' ) ?>
                            </label>

                        </div>

                    </div><!-- #blog-details-section -->

					<?php do_action( 'bp_after_blog_details_fields' ) ?>

				<?php endif; ?>

				<?php do_action( 'bp_before_registration_submit_buttons' ) ?>

                <div class="bpajaxr-form-group">
                    <input type="submit" name="signup_submit" id="signup_submit"
                           value="<?php _e( 'Registrieren', 'bp-ajax-registration' ) ?>"/>
                </div>

				<?php do_action( 'bp_after_registration_submit_buttons' ) ?>
                <!-- we are not using wp_nonce_field() to avoid duplicate id error -->
				<input type="hidden" name="_wpnonce" value="<?php echo wp_create_nonce( 'bp_new_signup' ) ?>" />

			<?php endif; // request-details signup step ?>

            <input name="action" type="hidden" value="bpajaxr_action_register"/>
        </form>

		<?php if ( 'completed-confirmation' == bp_get_current_signup_step() ) : ?>
            <div class="bpajaxr-registration-confirmation">
                <h2><?php _e( 'Anmeldung abgeschlossen!', 'bp-ajax-registration' ) ?></h2>

				<?php do_action( 'template_notices' ) ?>
				<?php do_action( 'bp_before_registration_confirmed' ) ?>
				<?php if ( bp_account_was_activated() ) : ?>

                    <h3><?php _e( 'Willkommen an Bord!', 'bp-ajax-registration' ) ?></h3>

                    <p> <?php _e( 'Vielen Dank, dass Du Dir die Zeit genommen hast, Dich zu registrieren. Wir hoffen, Du wirst unsere Community genießen!', 'bp-ajax-registration' ); ?></p>

				<?php else : // completed-confirmation signup step ?>
					<?php if ( bp_registration_needs_activation() ) : ?>
                        <p><?php _e( 'Du hast Dein Konto erfolgreich erstellt! Um diese Webseite nutzen zu können, musst Du Dein Konto über die E-Mail aktivieren, die wir gerade an Deine Adresse gesendet haben.', 'bp-ajax-registration' ) ?></p>
					<?php else : ?>
                        <p><?php _e( 'Du hast Dein Konto erfolgreich erstellt! Bitte melde Dich mit dem soeben erstellten Benutzernamen und Passwort an.', 'bp-ajax-registration' ) ?></p>
					<?php endif; ?>

					<?php do_action( 'bp_after_registration_confirmed' ) ?>
				<?php endif; ?>
            </div>
		<?php endif; // completed-confirmation signup step ?>

		<?php do_action( 'bp_custom_signup_steps' ) ?>
        <div class="bpajaxr-loader">
            <img src="<?php echo bpajaxr_helper()->url; ?>assets/css/loading.gif" alt="'loader"/>
        </div>
        <div class="bpajaxr-panel-nav">
			<?php if ( bpajaxr_get_option( 'enable_login' ) ): ?>
                <p><?php _e( 'Schon ein Konto? <a href="#" class="bpajaxr-login-link">Jetzt einloggen</a>', 'bp-ajax-registration' );?></p>
			<?php endif; ?>
        </div>
    </div><!-- end of panel inner -->
</div><!-- end of panel -->
