<?php
/**
 * Login Template
 *
 * @package    BP Ajax Registration
 * @copyright  Copyright (c) 2018, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.1
 */
// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;


$request = bpajaxr_helper()->request;
?>
<div class="bpajaxr-panel bpajaxr-panel-login" data-bpajaxr-panel="login">
	<div class="bpajaxr-panel-inner">

        <div class="bpajaxr-panel-title bpajaxr-login-panel-title">
            <span><?php _e( 'Einloggen', 'bp-ajax-registration' ) ?></span>
        </div>
		<?php bpajaxr_helper()->render_feedback();?>
        <form method="post" class="bpajaxr-form bpajaxr-login-form bpajaxr-login-form-default" action="" autocomplete="false">

            <div class="bpajaxr-form-group">
                <label class="bpajaxr-form-label" for="bpajaxr-user-login"><?php _ex( 'Benutzername oder E-mail Adresse', 'login form label', 'bp-ajax-registration' ); ?></label>
				<?php if( $request->errors->has('log' ) ):?>
                    <div class="bpajaxr-form-field-error">
						<?php echo wp_kses_data( $request->errors->first('log' ) );?>
                    </div>
				<?php endif;?>
                <input class="bpajaxr-form-input bpajaxr-input-user-login" type="text" name="log" value="<?php echo esc_attr( $request->old( 'log' ) ); ?>" id="bpajaxr-user-login" />
            </div>

            <div class="bpajaxr-form-group">
                <label class="bpajaxr-form-label" for="bpajaxr-user-pass"><?php _ex( 'Passwort', 'login form label', 'bp-ajax-registration' ); ?></label>
				<?php if( $request->errors->has('pwd' ) ):?>
                    <div class="bpajaxr-form-field-error">
						<?php echo wp_kses_data( $request->errors->first('pwd' ) );?>
                    </div>
				<?php endif;?>
                <input class="bpajaxr-form-input bpajaxr-input-user-password" type="password" name="pwd" value="" id="bpajaxr-user-pass"/>
            </div>

            <div class="bpajaxr-form-group">
                <label class="bpajaxr-form-checkbox" for="bpajaxr-user-rememberme">
                    <input type="checkbox" id="bpajaxr-user-rememberme"  name="rememberme"  value="forever" <?php checked( 'forever',  $request->old( 'rememberme', 'forever' ) ); ?> />
                    <i class="bpajaxr-form-icon"></i><?php echo esc_html_x( 'An mich erinnern', 'login form label', 'bp-ajax-registration' ); ?>
                </label>
            </div>

            <?php do_action( 'login_form');?>

            <div class="bpajaxr-form-group">
                <button class="bpajaxr-btn bpajaxr-btn-primary bpajax-login-submit"  type="submit"> <?php echo esc_html_x( 'Einloggen', 'Login form submit button', 'bp-ajax-registration' );?></button>
                <input type="hidden" name="testcookie" value="1" />
                <input type="hidden" name="action" value="bpajaxr_action_login" />
                <input type="hidden" name="_wpnonce" value="<?php echo wp_create_nonce( 'bpajaxr_login' ) ?>" />
            </div>

        </form>
        <div class="bpajaxr-loader">
            <img src="<?php echo bpajaxr_helper()->url;?>assets/css/loading.gif" alt="'loader" />
        </div>
        <div class="bpajaxr-panel-nav">
            <p>
                <?php $sep = false;?>
	            <?php if ( bp_get_signup_allowed() && bpajaxr_get_option( 'enable_registration' ) ) : ?>
                    <?php $sep = true; ?>
                    <?php _e( 'Konto benötigt? <a href="#" class="bpajaxr-signup-link">Jetzt registrieren', 'bp-ajax-registration' );?></a>
                <?php endif;?>
	            <?php if ( bpajaxr_get_option( 'enable_forget_password' ) ) : ?>
                    <?php if( $sep ) : ?>| <?php endif;?>
                    <?php _e( 'Passwort vergessen? <a href="#" class="bpajaxr-forget-password-link">Jetzt zurücksetzen</a>', 'bp-ajax-registration' );?>
                <?php endif;?>
            </p>
        </div>
    </div><!-- end of panel inner -->
</div> <!-- end of panel -->
