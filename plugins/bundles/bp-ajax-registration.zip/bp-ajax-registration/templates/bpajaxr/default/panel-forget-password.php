<?php
/**
 * Forget Password Template.
 *
 * @package    BP Ajax Registration
 * @copyright  Copyright (c) 2018, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.1
 */
// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;


$redirect_to = '';
$user_login  = '';
$request     = bpajaxr_helper()->request;
?>
<div class="bpajaxr-panel bpajaxr-panel-forget-password" data-bpajaxr-panel="forget-password">
    <div class="bpajaxr-panel-inner">
        <div class="bpajaxr-panel-title bpajaxr-forget-password-panel-title">
            <span><?php _e( 'Passwort vergessen', 'bp-ajax-registration' ) ?></span>
        </div>
	    <?php bpajaxr_helper()->render_feedback();?>
        <form  action="" method="post" class="bpajaxr-form bpajaxr-login-form bpajaxr-login-form-default">

            <div class="bpajaxr-form-group">
                <label class="bpajaxr-form-label" for="bpajaxr-forgot-user-login"><?php _e( 'Benutzername oder E-Mail Adresse', 'bp-ajax-registration' ); ?></label>
                <input type="text" name="user_login" id="bpajaxr-forgot-user-login" class="input" value="<?php echo esc_attr( $request->get( 'user_login' ) ); ?>" />
            </div>

			<?php
			/**
			 * Fires inside the lostpassword form tags, before the hidden fields.
			 *
			 */
			do_action( 'lostpassword_form' ); ?>

            <div class="bpajaxr-form-group">
                <input type="hidden" name="redirect_to" value="<?php echo esc_attr( $redirect_to ); ?>"/>
                <button class="bpajaxr-btn bpajaxr-btn-primary bpajax-forget-password-submit" type="submit"><?php esc_attr_e( 'Erhalte ein neues Passwort', 'bp-ajax-registration' ); ?></button>
                <input type="hidden" name="action" value="bpajaxr_action_retrieve_password"/>
                <input type="hidden" name="_wpnonce" value="<?php echo wp_create_nonce( 'bpajaxr_forget_password' ) ?>" />
            </div>
        </form>
        <div class="bpajaxr-loader">
            <img src="<?php echo bpajaxr_helper()->url;?>assets/css/loading.gif" alt="'loader" />
        </div>
        <div class="bpajaxr-panel-nav">
	        <?php if ( bpajaxr_get_option( 'enable_login' ) ) : ?>
            <p><?php _e( 'Erinnerst du dich an das Passwort? <a href="#" class="bpajaxr-login-link">Jetzt einloggen</a>', 'bp-ajax-registration' );?></p>
            <?php endif;?>
        </div>
    </div><!-- end of panel inner -->
</div> <!-- end of panel -->

