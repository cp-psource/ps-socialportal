<?php
/**
 * Admin Settings Pages Helper.
 *
 * @package    BuddyPress Moderation Tools
 * @subpackage Admin
 * @copyright  Copyright (c) 2018, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

// Do not allow direct access over web.
use Press_Themes\PT_Settings\Page;

defined( 'ABSPATH' ) || exit;

/**
 * Class Admin_Settings
 */
class BPAjaxr_Admin_Settings {

	/**
	 * Used to keep a reference of the Page, It will be used in rendering the view.
	 *
	 * @var \Press_Themes\PT_Settings\Page
	 */
	private $page;

	/**
	 * Show/render the setting page
	 */
	public function render() {
		$this->page->render();
	}

	/**
	 * Initialize the admin settings panel and fields
	 */
	public function init() {

		$this->page = new Page( 'bpajaxr-settings', __( 'BuddyPress Ajax Registrierung', 'bp-ajax-registration' ) );

		$panel   = $this->page->add_panel( 'basic', __( 'Allgemeines', 'bp-ajax-registration' ) );
		$section = $panel->add_section( 'modal-options', __( 'Modale Optionen', 'bp-ajax-registration' ) );

		$defaults = bpajaxr_get_default_options();

		$section->add_fields( array(

			array(
				'name'    => 'enable_registration',
				'label'   => __( 'Registrierung aktivieren?', 'bp-ajax-registration' ),
				'desc'    => __( 'Möchtest Du die Ajax-Registrierung verwenden?', 'bp-ajax-registration' ),
				'type'    => 'radio',
				'default' => $defaults['enable_registration'],
				'options' => array(
					1 => __( 'Ja', 'bp-ajax-registration' ),
					0 => __( 'Nein', 'bp-ajax-registration' ),
				),
			),
			array(
				'name'    => 'enable_login',
				'label'   => __( 'Login aktivieren?', 'bp-ajax-registration' ),
				'desc'    => __( 'Möchtest Du das Ajax-Login verwenden?', 'bp-ajax-registration' ),
				'type'    => 'radio',
				'default' => $defaults['enable_login'],
				'options' => array(
					1 => __( 'Ja', 'bp-ajax-registration' ),
					0 => __( 'Nein', 'bp-ajax-registration' ),
				),
			),
			array(
				'name'    => 'enable_forget_password',
				'label'   => __( '"Passwort vergessen" Aktivieren?', 'bp-ajax-registration' ),
				'desc'    => __( 'Möchtest Du das Passwort vergessen im Modal aktivieren?', 'bp-ajax-registration' ),
				'type'    => 'radio',
				'default' => $defaults['enable_forget_password'],
				'options' => array(
					1 => __( 'Ja', 'bp-ajax-registration' ),
					0 => __( 'Nein', 'bp-ajax-registration' ),
				),
			),

		) );

		$section_appearance = $panel->add_section( 'modal-appearance', __( 'Aussehen', 'bp-ajax-registration' ) );

		$section_appearance->add_field( array(
			'name'    => 'theme_style',
			'id'      => 'theme_style',
			'label'   => __( 'Stil', 'bp-ajax-registration' ),
			'type'    => 'select',
			'default' => $defaults['theme_style'],
			'options' => array(
				'default' => __( 'Standard', 'bp-ajax-registration' ),
			),

		) );

		$this->add_registration_panel( $this->page );
		$this->add_login_panel( $this->page );
		$this->add_forget_password_panel( $this->page );

		do_action( 'bpajaxr_admin_settings_page', $this->page );

		// allow enabling options.
		$this->page->init();
	}

	/**
	 * Add registration panel.
	 *
	 * @param Page $page page.
	 */
	private function add_registration_panel( $page ) {

		$defaults = bpajaxr_get_default_options();

		$panel   = $page->add_panel( 'registration', __( 'Registrierung', 'bp-ajax-registration' ) );
		$section = $panel->add_section( 'registration-general', __( 'Allgemeines', 'bp-ajax-registration' ) );

		$section->add_field( array(
			'name'    => 'registration_link_selector',
			'label'   => __( 'Link Selektor', 'bp-ajax-registration' ),
			'desc'    => __( 'Aktiviert das modale Öffnen, wenn Du auf diese Links klickst.', 'bp-ajax-registration' ),
			'type'    => 'textarea',
			'default' => $defaults['registration_link_selector'],
		) );
		$section->add_field( array(
			'name'    => 'enable_auto_activation',
			'label'   => __( 'Automatische Aktivierung bei Registrierung', 'bp-ajax-registration' ),
			'desc'    => __( 'Möchtest Du, dass das Benutzerkonto automatisch aktiviert wird? Es deaktiviert die E-Mail-Überprüfung.', 'bp-ajax-registration' ),
			'type'    => 'radio',
			'default' => $defaults['enable_auto_activation'],
			'options' => array(
				1 => __( 'Ja', 'bp-ajax-registration' ),
				0 => __( 'Nein', 'bp-ajax-registration' ),
			),
		) );

		$section->add_field( array(
			'name'    => 'enable_auto_login',
			'label'   => __( 'Benutzer nach Registrierung anmelden?', 'bp-ajax-registration' ),
			'desc'    => __( 'Wenn die automatische Aktivierung aktiviert ist, werden Benutzer automatisch eingeloggt.', 'bp-ajax-registration' ),
			'type'    => 'radio',
			'default' => $defaults['enable_auto_login'],
			'options' => array(
				1 => __( 'Ja', 'bp-ajax-registration' ),
				0 => __( 'Nein', 'bp-ajax-registration' ),
			),
		) );

		$section->add_field( array(
			'name'    => 'registration_success_action',
			'label'   => __( 'Aktion nach erfolgreicher Registrierung?', 'bp-ajax-registration' ),
			'desc'    => __( 'Was sollen wir tun, wenn die Registrierung erfolgreich ist?.', 'bp-ajax-registration' ),
			'type'    => 'select',
			'default' => $defaults['registration_success_action'],
			'options' => array(
				'update'   => __( 'Registrierungsantwort anzeigen.', 'bp-ajax-registration' ),
				'reload'   => __( 'Aktuelle Seite neu laden', 'bp-ajax-registration' ),
				'redirect' => __( 'Auf eine andere Seite umleiten', 'bp-ajax-registration' ),
			),
		) );
		$section->add_field( array(
			'name'    => 'registration_redirect_url',
			'label'   => __( 'Nach der Registrierung weiterleiten an?', 'bp-ajax-registration' ),
			'desc'    => __( 'Wird verwendet, wenn die Aktion auf Umleiten eingestellt ist. Verfügbare Token sind [site.url], [network.url], [user.url], [user.login], [user.nicename] und [user.id].', 'bp-ajax-registration' ),
			'type'    => 'text',
			'default' => $defaults['registration_redirect_url'],
		) );
	}

	/**
	 * Add registration panel.
	 *
	 * @param Page $page page.
	 */
	private function add_login_panel( $page ) {

		$defaults = bpajaxr_get_default_options();

		$panel   = $page->add_panel( 'login', __( 'Einloggen', 'bp-ajax-registration' ) );
		$section = $panel->add_section( 'login-general', __( 'Allgemeines', 'bp-ajax-registration' ) );

		$section->add_field( array(
			'name'    => 'login_link_selector',
			'label'   => __( 'Link Selektor', 'bp-ajax-registration' ),
			'desc'    => __( 'Aktiviert das modale Öffnen, wenn Du auf diese Links klickst.', 'bp-ajax-registration' ),
			'type'    => 'textarea',
			'default' => $defaults['login_link_selector'],
		) );

		$section->add_field( array(
			'name'    => 'login_success_action',
			'label'   => __( 'Aktion nach erfolgreicher Anmeldung?', 'bp-ajax-registration' ),
			'desc'    => __( 'Was sollen wir tun, wenn die Anmeldung erfolgreich ist?.', 'bp-ajax-registration' ),
			'type'    => 'select',
			'default' => $defaults['login_success_action'],
			'options' => array(
				'reload'   => __( 'Aktuelle Seite neu laden', 'bp-ajax-registration' ),
				'redirect' => __( 'Auf eine andere Seite umleiten', 'bp-ajax-registration' ),
			),
		) );

		$section->add_field( array(
			'name'    => 'login_redirect_url',
			'label'   => __( 'Nach dem Anmelden weiterleiten zu?', 'bp-ajax-registration' ),
			'desc'    => __( 'Wird verwendet, wenn die Aktion auf Umleiten eingestellt ist. Verfügbare Token sind [site.url], [network.url], [user.url], [user.login], [user.nicename] und [user.id].', 'bp-ajax-registration' ),
			'type'    => 'text',
			'default' => $defaults['login_redirect_url'],
		) );
	}


	/**
	 * Add registration panel.
	 *
	 * @param Page $page page.
	 */
	private function add_forget_password_panel( $page ) {

		$defaults = bpajaxr_get_default_options();

		$panel   = $page->add_panel( 'forget_password', __( 'Passwort vergessen', 'bp-ajax-registration' ) );
		$section = $panel->add_section( 'forget_password_general', __( 'Allgemeines', 'bp-ajax-registration' ) );

		$section->add_field( array(
			'name'    => 'forget_password_link_selector',
			'label'   => __( 'Link Selektor', 'bp-ajax-registration' ),
			'desc'    => __( 'Aktiviert das modale Öffnen, wenn Du auf diese Links klickst.', 'bp-ajax-registration' ),
			'type'    => 'textarea',
			'default' => $defaults['forget_password_link_selector'],
		) );

		$section->add_field( array(
			'name'    => 'forget_password_success_action',
			'label'   => __( 'Aktion nach dem Senden einer E-Mail zum Zurücksetzen des Passworts?', 'bp-ajax-registration' ),
			'desc'    => __( 'Was sollen wir tun, nachdem wir die E-Mail zum Zurücksetzen des Passworts gesendet haben?.', 'bp-ajax-registration' ),
			'type'    => 'select',
			'default' => $defaults['forget_password_success_action'],
			'options' => array(
				'show_login' => __( 'Login-Panel anzeigen?', 'bp-ajax-registration' ),
				'reload'     => __( 'Aktuelle Seite neu laden', 'bp-ajax-registration' ),
				'redirect'   => __( 'Auf eine andere Seite umleiten', 'bp-ajax-registration' ),
			),
		) );

		$section->add_field( array(
			'name'    => 'forget_password_redirect_url',
			'label'   => __( 'Weiterleiten an?', 'bp-ajax-registration' ),
			'desc'    => __( 'Wird verwendet, wenn die Aktion auf Umleiten eingestellt ist. Verfügbare Token sind [site.url] und [network.url].', 'bp-ajax-registration' ),
			'type'    => 'text',
			'default' => $defaults['forget_password_redirect_url'],
		) );
	}
}
