<?php
/**
 * Admin Loader.
 *
 * @package    BuddyPress Moderation Tools
 * @subpackage Admin
 * @copyright  Copyright (c) 2018, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.1
 */


// Exit if file access directly over web.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Admin_Loader
 */
class BPAjaxr_Admin_Loader {

	/**
	 * Slug for settings page.
	 *
	 * @var string
	 */
	private $settings_slug = 'bpajaxr-settings';

	/**
	 * Settings class object
	 *
	 * @var BPAjaxr_Admin_Settings
	 */

	private $settings = null;

	/**
	 * Page slug.
	 *
	 * @var string
	 */
	private $page_slug = 'bpajaxr-settings';

	/**
	 * Option name.
	 *
	 * @var string
	 */
	private $option_name = 'bpajaxr_settings';

	/**
	 * BPMTS_Admin_Loader constructor.
	 */
	public function __construct() {
	}

	/**
	 * Boot this loader.
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Setup callbacks on necessary admin hooks
	 */
	public function setup() {

		if ( is_multisite() && bpajaxr_helper()->is_network_active() ) {

			add_action( 'network_admin_menu', array( $this, 'register_network_menu' ) );
			// Wp setting api does not save in site meta, we will sync.
			add_action( 'pre_update_option_' . $this->option_name, array( $this, 'sync_options' ), 10, 2 );
		} else {
			add_action( 'admin_menu', array( $this, 'register_menu' ) );
		}

		add_action( 'admin_init', array( $this, 'init' ) );
		add_filter( 'plugin_action_links_' . bpajaxr_helper()->basename, array( $this, 'plugin_action_links' ) );
	}

	/**
	 * Register new menu item with subpage
	 */
	public function register_network_menu() {
		add_submenu_page('settings.php',
			__( 'BP Ajax Registrierung', 'bp-ajax-registration' ),
			__( 'BP Ajax Registrierung', 'bp-ajax-registration' ),
			'manage_options', // Change to make sure admin only.
			$this->page_slug,
			array( $this, 'render' )
		);
	}

	/**
	 * Register new menu item with subpage
	 */
	public function register_menu() {

		add_options_page( __( 'BP Ajax Registrierung', 'bp-ajax-registration' ), __( 'BP Ajax Registrierung', 'bp-ajax-registration' ), 'manage_options', $this->page_slug, array(
			$this,
			'render',
		) );
	}

	/**
	 * Initialize settings
	 */
	public function init() {

		if ( $this->is_options_page() || $this->is_settings_page() ) {
			$this->settings = new BPAjaxr_Admin_Settings();
			$this->settings->init();
		}
	}

	/**
	 * Add links to plugin entry in plugin list.
	 *
	 * @param array $actions actions.
	 *
	 * @return array
	 */
	public function plugin_action_links( $actions ) {
		if ( is_super_admin() ) {
			$actions['view-bpajaxr-settings'] = sprintf( '<a href="%1$s" title="%2$s">%3$s</a>', admin_url( 'admin.php?page=bpajaxr-settings' ), __( 'Einstellungen', 'buddypress-moderation-tools' ), __( 'Einstellungen', 'bp-ajax-registration' ) );
		}

		$actions['view-bpajaxr-docs'] = sprintf( '<a href="%1$s" title="%2$s" target="_blank">%2$s</a>', 'https://n3rds.work/wiki/piestingtal-source-wiki/bp-ajax-registrierung/', __( 'Dokumentation', 'bp-ajax-registration' ) );

		return $actions;
	}

	/**
	 * Render.
	 */
	public function render() {
		if ( ! $this->settings ) {
			$this->settings = new BPAjaxr_Admin_Settings();
		}
		$this->settings->render();
	}

	/**
	 * Sync option to the site meta.
	 *
	 * @param mixed $value value of the meta.
	 * @param mixed $old_value old value.
	 *
	 * @return mixed
	 */
	public function sync_options( $value, $old_value ) {
		update_site_option( $this->option_name, $value );
		return $value;
	}


	/**
	 * Is the admin settings page for us?
	 *
	 * @return bool
	 */
	private function is_settings_page() {

		if ( isset( $_GET['page'] ) && $this->settings_slug === $_GET['page'] ) {
			return true;
		}

		return false;
	}

	/**
	 * Is it the options.php page that saves settings?
	 *
	 * @return bool
	 */
	private function is_options_page() {
		global $pagenow;

		// We need to load on options.php otherwise settings won't be registered.
		if ( 'options.php' === $pagenow ) {
			return true;
		}

		return false;
	}
}
