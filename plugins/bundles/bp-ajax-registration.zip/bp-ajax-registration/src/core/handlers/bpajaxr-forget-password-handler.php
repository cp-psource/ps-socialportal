<?php
/**
 * Forget Password Controller.
 *
 * @package    BP Ajax Registration
 * @copyright  Copyright (c) 2018, Brajesh Singh
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     Brajesh Singh
 * @since      1.0.0
 */

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Forget Password request handler.
 */
class BPAjaxr_Forget_Password_Controller {

	/**
	 * Handler request.
	 *
	 * @param BPAjaxr_Request $request object.
	 *
	 * @return bool
	 */
	public function process( BPAjaxr_Request $request ) {

		if ( ! $this->validate( $request ) ) {
			return false;
		}

		$errors = $this->retrieve_password( $request->get( 'user_login' ) );

		if ( is_wp_error( $errors ) ) {
			bpajaxr_helper()->add_feedback( join( ',', $errors->get_error_messages() ), 'notice' );

			return false;
		} else {
			bpajaxr_helper()->add_feedback( __( 'Please check your mail for the instructions.', 'bp-ajax-registration' ), 'success' );
			return true;
		}
	}

	/**
	 * Validate Request.
	 *
	 * @param BPAjaxr_Request $request request object.
	 *
	 * @return bool
	 */
	private function validate( $request ) {
		$user_login = trim( $request->get( 'user_login' ) );
		$validated  = true;
		if ( empty( $user_login ) ) {
			$request->add_error( 'user_login', __( 'Please provide a username or email.', 'bp-ajax-registration' ) );
			$validated = false;
		}

		return $validated;
	}

	/**
	 * Handles sending password retrieval email to user.
	 *
	 * @param string $user_login user login or email.
	 *
	 * @return bool|\WP_Error True: when finish. WP_Error on error
	 */
	private function retrieve_password( $user_login ) {

		$errors = new \WP_Error();
		if ( strpos( $user_login, '@' ) ) {
			$user_data = get_user_by( 'email', trim( wp_unslash( $user_login ) ) );
			if ( empty( $user_data ) ) {
				$errors->add( 'invalid_email', __( 'There is no user registered with that email address.', 'bp-ajax-registration' ) );
			}
		} else {
			$login     = trim( $user_login );
			$user_data = get_user_by( 'login', $login );
		}

		/**
		 * Fires before errors are returned from a password reset request.
		 *
		 * @param \WP_Error $errors A WP_Error object containing any errors generated
		 *                         by using invalid credentials.
		 */
		do_action( 'lostpassword_post', $errors );

		if ( $errors->get_error_code() ) {
			return $errors;
		}

		if ( ! $user_data ) {
			$errors->add( 'invalidcombo', __( 'Invalid username or email.', 'bp-ajax-registration' ) );
			return $errors;
		}

		$this->mail( $user_data );
		return true;
	}

	/**
	 * Send mail to the user.
	 *
	 * @param \WP_User $user_data user object.
	 *
	 * @return string|\WP_Error
	 */
	private function mail( $user_data ) {
		// Redefining user_login ensures we return the right case in the email.
		$user_login = $user_data->user_login;
		$user_email = $user_data->user_email;
		$key = get_password_reset_key( $user_data );

		if ( is_wp_error( $key ) ) {
			return $key;
		}

		if ( is_multisite() ) {
			$site_name = get_network()->site_name;
		} else {
			/**
			 * The blogname option is escaped with esc_html on the way into the database
			 * in sanitize_option we want to reverse this for the plain text arena of emails.
			 */
			$site_name = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );
		}

		$url = add_query_arg( array( 'action'=>'rp', 'key'   => $key, 'login' => rawurlencode( $user_login ) ), network_site_url("wp-login.php") );

		$message = __( 'Someone has requested a password reset for the following account:' ) . "\r\n\r\n";
		/* translators: %s: site name */
		$message .= sprintf( __( 'Site Name: %s'), $site_name ) . "\r\n\r\n";
		/* translators: %s: user login */
		$message .= sprintf( __( 'Username: %s'), $user_login ) . "\r\n\r\n";
		$message .= __( 'If this was a mistake, just ignore this email and nothing will happen.' ) . "\r\n\r\n";
		$message .= __( 'To reset your password, visit the following address:' ) . "\r\n\r\n";
		$message .= '<' . $url . ">\r\n";

		/* translators: Password reset email subject. %s: Site name */
		$title = sprintf( __( '[%s] Password Reset' ), $site_name );

		/**
		 * Filters the subject of the password reset email.
		 *
		 * @since 2.8.0
		 * @since 4.4.0 Added the `$user_login` and `$user_data` parameters.
		 *
		 * @param string  $title      Default email title.
		 * @param string  $user_login The username for the user.
		 * @param WP_User $user_data  WP_User object.
		 */
		$title = apply_filters( 'retrieve_password_title', $title, $user_login, $user_data );

		/**
		 * Filters the message body of the password reset mail.
		 *
		 * If the filtered message is empty, the password reset email will not be sent.
		 *
		 * @since 2.8.0
		 * @since 4.1.0 Added `$user_login` and `$user_data` parameters.
		 *
		 * @param string  $message    Default mail message.
		 * @param string  $key        The activation key.
		 * @param string  $user_login The username for the user.
		 * @param WP_User $user_data  WP_User object.
		 */
		$message = apply_filters( 'retrieve_password_message', $message, $key, $user_login, $user_data );

		if ( $message && ! wp_mail( $user_email, wp_specialchars_decode( $title ), $message ) ) {
			wp_die( __( 'The email could not be sent.' ) . "<br />\n" . __( 'Possible reason: your host may have disabled the mail() function.' ) );
		}
	}
}
