<?php
/**
 * Login Controller
 *
 * @package    BP Ajax Registration
 * @copyright  Copyright (c) 2018, Brajesh Singh
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     Brajesh Singh
 * @since      1.0.0
 */

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Login Controller.
 */
class BPAjaxr_Login_Controller {

	/**
	 * Process login request.
	 *
	 * @param BPAjaxr_Request $request request object.
	 *
	 * @return bool
	 */
	public function process( BPAjaxr_Request $request ) {

		if ( ! $this->validate( $request ) ) {
			return false;
		}

		// if we are here, all is well.
		return $this->login( $request );
	}

	/**
	 * Validate the input.
	 *
	 * @param BPAjaxr_Request $request request object.
	 *
	 * @return bool
	 */
	private function validate( BPAjaxr_Request $request ) {
		$has_error = false;

		if ( ! $request->get( 'log' ) ) {
			$request->add_error( 'log', __( 'Username is required.', 'bp-ajax-registration' ) );
			$has_error = true;
		}

		if ( ! $request->get( 'pwd' ) ) {
			$request->add_error( 'pwd', __( 'Password is required.', 'bp-ajax-registration' ) );
			$has_error = true;
		}

		if ( $has_error ) {
			$request->flash_except( 'pwd' );
		}

		return ! $has_error;
	}

	/**
	 * Process login request.
	 *
	 * @param BPAjaxr_Request $request request object.
	 *
	 * @return false
	 */
	private function login( BPAjaxr_Request $request ) {
		// set test cookie.
		//$this->set_test_cookie();

		// Now let us do our thing.
		$reauth = $request->get( 'reauth' ) ? true : false;

		if ( $request->get( 'redirect_to' ) ) {
			$redirect_to = $request->get( 'redirect_to' );
		} else {
			$redirect_to = admin_url();
		}

		$secure_cookie   = '';

		$user = wp_signon( array(), $secure_cookie );

		$error = $this->test_cookie_support();

		$helper = bpajaxr_helper();

		if ( $error ) {
			$request->flash_except( 'pwd' );
			$helper->add_feedback( $error->get_error_message(), 'error' );
			return false;
		}

		$requested_redirect_to = '';

		// Clear any stale cookies.
		if ( $reauth ) {
			wp_clear_auth_cookie();
		}

		$redirect_to = apply_filters( 'login_redirect', $redirect_to, $requested_redirect_to, $user );

		if ( is_wp_error( $user ) ) {
			$errors = apply_filters( 'wp_login_errors', $user, $redirect_to );
			$request->flash_except( 'pwd' );

			$helper->add_feedback( $this->get_error_messages( $errors ), 'error' );
			wp_clear_auth_cookie();
			return false;
		}

		if ( $user && $user->ID ) {
			wp_set_current_user( $user->ID );
		}
		return true;
	}

	/**
	 * Get prepared error messages.
	 *
	 * @param WP_Error $error error object.
	 *
	 * @return array
	 */
	private function get_error_messages( $error ) {
		$messages     = $error->get_error_messages();
		$new_messages = array();
		foreach ( $messages as $key => $message ) {
			$new_messages[ $key ] = str_replace( '<a ', '<a class="bpajaxr-forget-password-link" ', $message );
		}

		return $new_messages;
	}
	/**
	 * Set test Cookie(Based on wp-login.php).
	 */
	private function set_test_cookie() {
		// Set a cookie now to see if they are supported by the browser.
		$secure = ( 'https' === wp_parse_url( wp_login_url(), PHP_URL_SCHEME ) );
		setcookie( TEST_COOKIE, 'WP Cookie check', 0, COOKIEPATH, COOKIE_DOMAIN, $secure );
		if ( SITECOOKIEPATH != COOKIEPATH ) {
			setcookie( TEST_COOKIE, 'WP Cookie check', 0, SITECOOKIEPATH, COOKIE_DOMAIN, $secure );
		}
	}

	/**
	 * Check if cookie is supported in the browser(Based on wp-login.php).
	 *
	 * @return null|\WP_Error
	 */
	private function test_cookie_support() {
		$error = null;
		if ( empty( $_COOKIE[ LOGGED_IN_COOKIE ] ) ) {
			if ( headers_sent() ) {
				/* translators: 1: Browser cookie documentation URL, 2: Support forums URL */
				$error = new \WP_Error( 'test_cookie', sprintf( __( '<strong>ERROR</strong>: Cookies are blocked due to unexpected output. For help, please see <a href="%1$s">this documentation</a> or try the <a href="%2$s">support forums</a>.', 'bp-ajax-registration' ),
					__( 'https://codex.wordpress.org/Cookies' ), __( 'https://bp-ajax-registration.io/support/' ) ) );
			} elseif ( isset( $_POST['testcookie'] ) && empty( $_COOKIE[ TEST_COOKIE ] ) ) {
				// If cookies are disabled we can't log in even with a valid user+pass
				/* translators: 1: Browser cookie documentation URL */
				$error = new \WP_Error( 'test_cookie', sprintf( __( '<strong>ERROR</strong>: Cookies are blocked or not supported by your browser. You must <a href="%s">enable cookies</a> to use WordPress.', 'bp-ajax-registration' ),
					__( 'https://codex.wordpress.org/Cookies', 'bp-ajax-registration' ) ) );
			}
		}

		return $error;
	}
}
