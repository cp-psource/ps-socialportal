<?php
/**
 * Login Controller
 *
 * @package    BP Ajax Registration
 * @copyright  Copyright (c) 2018, Brajesh Singh
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     Brajesh Singh
 * @since      1.0.0
 */

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Login Controller.
 */
class BPAjaxr_Registration_Controller {

	/**
	 * Created user id.
	 *
	 * @var int
	 */
	private $user_id = 0;

	/**
	 * Validator.
	 *
	 * @var BPAjaxr_Registration_Validator
	 */
	private $validator = null;

	/**
	 * Activation helper.
	 *
	 * @var BPAjaxr_Account_Activator
	 */
	private $activator = null;

	/**
	 * Process login request.
	 *
	 * @param BPAjaxr_Request $request request object.
	 *
	 * @return bool|array
	 */
	public function process( BPAjaxr_Request $request ) {

		$this->setup();
		$this->validator = new BPAjaxr_Registration_Validator();
		$this->activator = new BPAjaxr_Account_Activator();

		// if we are here, all is well.
		return $this->register( $request );
	}

	/**
	 * Registration handler.
	 *
	 * @param BPAjaxr_Request $request request object.
	 *
	 * @return array|bool
	 */
	public function register( $request ) {

		if ( ! defined( 'DOING_AJAX' ) ) {
			define( 'DOING_AJAX', true );
		}

		$bp = buddypress();

		if ( ! isset( $bp->signup ) ) {
			$bp->signup = new stdClass();
		}

		$bp->signup->step = 'request-details';

		if ( ! bp_get_signup_allowed() ) {
			$bp->signup->step = 'registration-disabled';

			return false;
		}

		// If the signup page is submitted, validate and save
		// Check the nonce.
		check_admin_referer( 'bp_new_signup' );

		$this->validator->validate_account_details();
		$this->validator->validate_xprofile_fields();

		$blog_details = $this->validator->validate_blog_details();
		do_action( 'bp_signup_validate' );


		if ( ! empty( $bp->signup->errors ) ) {
			$this->attach_errors();

			return false;
		}

		$this->save_details( $blog_details );


		$response = array(
			'redirect'     => '',
			'redirect_url' => '',
			'update_panel' => 'registration',
			//'visible_panel' => 'registration',
		);

		$redirect_url = '';
		global $pagenow;
		if ( 'wp-login.php' === $pagenow ) {
			// $redirect_url = site_url( '/' );
		}

		$redirect     = bpajaxr_get_option( 'registration_success_action' ) === 'redirect' ? 1 : 0;
		$redirect_url = $redirect ? bpajaxr_get_parsed_url( bpajaxr_get_option( 'registration_redirect_url' ), $this->user_id ) : '';

		if ( 'update' === bpajaxr_get_option( 'registration_success_action' ) ) {
			$response['redirect'] = 0;// $redirect;
		} else {
			$response['redirect'] = 1;// $redirect;
		}

		$response['redirect_url'] = apply_filters( 'bpajaxr_registration_redirect_url', $redirect_url, $this->user_id );

		// if ( bp_account_was_activated() ) {
		//	}

		return $response;
	}

	/**
	 * Attach errors to the UI.
	 */
	private function attach_errors() {
		$bp = buddypress();
		if ( ! empty( $bp->signup->errors['profile_issue'] ) ) {
			bp_core_add_message( $bp->signup->errors['profile_issue'], 'error' );
		}

		foreach ( (array) $bp->signup->errors as $fieldname => $error_message ) {
			add_action( 'bp_' . $fieldname . '_errors', function () use ( $error_message ) {
				echo apply_filters( 'bp_members_signup_error_message', '<div class="bpajaxr-field-error">' . $error_message . '</div>' );

			} );
		}
	}

	/**
	 * Save Details.
	 *
	 * @param array $blog_details blog details on multisite.
	 */
	private function save_details( $blog_details ) {
		$bp = buddypress();

		$bp->signup->step = 'save-details';

		// No errors! Let's register those details.
		$active_signup = ! empty( $bp->site_options['registration'] ) ? $bp->site_options['registration'] : '';

		if ( 'none' !== $active_signup ) {

			// Let's compact any profile field info into usermeta.
			$profile_field_ids = isset( $_POST['signup_profile_field_ids'] ) ? explode( ',', $_POST['signup_profile_field_ids'] ) : array();

			// Loop through the posted fields formatting any datebox values then add to usermeta.
			foreach ( (array) $profile_field_ids as $field_id ) {
				if ( ! isset( $_POST[ 'field_' . $field_id ] ) ) {

					if ( isset( $_POST[ 'field_' . $field_id . '_day' ] ) ) {
						$_POST[ 'field_' . $field_id ] = date( 'Y-m-d H:i:s', strtotime( $_POST[ 'field_' . $field_id . '_day' ] . $_POST[ 'field_' . $field_id . '_month' ] . $_POST[ 'field_' . $field_id . '_year' ] ) );
					}
				}

				if ( ! empty( $_POST[ 'field_' . $field_id ] ) ) {
					$usermeta[ 'field_' . $field_id ] = $_POST[ 'field_' . $field_id ];
				}
			}

			// Store the profile field ID's in usermeta.
			$usermeta['profile_field_ids'] = isset( $_POST['signup_profile_field_ids'] ) ? $_POST['signup_profile_field_ids']: array();

			// Hash and store the password.
			$usermeta['password'] = wp_hash_password( $_POST['signup_password'] );

			// If the user decided to create a blog, save those details to usermeta.
			if ( 'blog' == $active_signup || 'all' == $active_signup ) {
				$usermeta['public'] = ( isset( $_POST['signup_blog_privacy'] ) && 'public' == $_POST['signup_blog_privacy'] ) ? true : false;
			}

			$usermeta = apply_filters( 'bp_signup_usermeta', $usermeta );

			$bp->signup->step = 'completed-confirmation';// move up.

			// Finally, sign up the user and/or blog.
			if ( isset( $_POST['signup_with_blog'] ) && is_multisite() ) {
				bp_core_signup_blog( $blog_details['domain'], $blog_details['path'], $blog_details['blog_title'], $_POST['signup_username'], $_POST['signup_email'], $usermeta );
			} else {
				bp_core_signup_user( $_POST['signup_username'], $_POST['signup_password'], $_POST['signup_email'], $usermeta );
			}
		}

		do_action( 'bp_complete_signup' );
	}

	/**
	 * Setup hooks.
	 */
	private function setup() {
		// Is auto activation enabled ?
		if ( $this->is_auto_activation_mode() ) {
			// remove buddypress notifications.
			//add_action( 'bp_loaded', array( $this, 'remove_bp_filters' ), 100 );
			$this->remove_bp_filters();
			// activate the account instantly.
			add_action( 'bp_core_signup_user', array( $this, 'activate' ), 10, 5 );
			add_filter( 'wpmu_signup_user_notification', array( $this, 'activate_user_for_wpms' ), 10, 4 );
			add_filter( 'wpmu_signup_blog_notification', array( $this, 'activate_on_blog_signup' ), 100, 7 );
			// disable the hooks that normally controls various emails.
			$this->disable_hooks();
		}
	}

	/**
	 * Make the User logged in
	 *
	 * @param int    $user_id numeric user id.
	 * @param string $user_password password.
	 *
	 * @return null
	 */
	public function login( $user_id, $user_password ) {

		bp_core_add_message( __( 'Your account is now active!', 'bp-ajax-registration' ) );

		$bp = buddypress();

		$bp->activation_complete = true;

		if ( is_multisite() && ( $default_role = get_option( 'default_role', 'subscriber' ) ) ) {
			// in case of multisite the auto login only works if the user is member of current blog.
			add_user_to_blog( get_current_blog_id(), $user_id, $default_role );
		}

		$this->user_id = $user_id;

		if ( ! bpajaxr_get_option( 'enable_auto_login' ) ) {
			return;
		}

		$ud = get_userdata( $user_id );
		// if the user is not valid.
		if ( ! $ud ) {
			bp_core_add_message( __( 'There was a problem logging you in. Please login with your password!', 'bp-ajax-registration' ) );

			return;
		}

		$force_email_login = class_exists( 'Force_Email_Auth' );

		// add compat with force login plugin.
		if ( $force_email_login ) {
			$creds = array(
				'user_login'    => $ud->user_email,
				'user_password' => $user_password,
			);
		} else {
			$creds = array(
				'user_login'    => $ud->user_login,
				'user_password' => $user_password,
			);
		}

		$user = wp_signon( $creds );

		if ( ! is_wp_error( $user ) ) {
			// if the signup was success full.redirect to the membership page.
			$this->user_id = $user->ID;

			return $user->ID;
		}
	}

	/**
	 * Activate a User account For Standard WordPress( Not Multisite )
	 * It is used when a user does not signup for a blog(in case of multisite) and all cases in normal WordPress
	 * used
	 *
	 * @param int    $user_id user id.
	 * @param string $user_login user login name.
	 * @param string $user_password pass.
	 * @param string $user_email email.
	 * @param array  $usermeta meta data.
	 *
	 * @return null
	 */
	public function activate( $user_id, $user_login, $user_password, $user_email, $usermeta ) {
		$this->activator->activate( $user_id, $user_login, $user_password, $user_email, $usermeta );

		return $this->login( $user_id, $user_password );
	}

	/**
	 * Activates User account on Multi site based on the given key
	 */
	public function ms_activate_account( $key ) {

		$ud = $this->activator->activate_ms( $key );

		if ( ! $ud ) {
			return;
		}

		$this->login( $ud->ID, $_POST['signup_password'] );
	}

	// this is just a copy of bp_core_active_user, I wanted some control over it, so kept it as a member function.
	public function activate_user_for_wpms( $user, $user_email, $key, $meta ) {
		$this->ms_activate_account( $key );
	}


	public function activate_on_blog_signup( $domain, $path, $title, $user, $user_email, $key, $meta ) {

		if ( ! defined( 'DOING_AJAX' ) ) {
			return $domain;
		}

		$this->ms_activate_account( $key );
	}

	/**
	 * Disable hooks.
	 */
	private function disable_hooks() {

		// stop notifications.
		// 5 args,no need to send the clear text password when blog is activated.
		add_filter( 'bp_core_signup_send_activation_key', '__return_false', 110 );
		// Prevent the notification On new Account registration
		// Stop User signup Mu notification.
		// array($this, 'activate_user_for_wpms'), 10, 4);.
		add_filter( 'wpmu_signup_user_notification', '__return_false', 110 );
		// stop activation email for account with blog.
		// array($this, 'activate_on_blog_signup'), 10, 7);.
		add_filter( 'wpmu_signup_blog_notification', '__return_false', 100 );

		// on account activation.
		// 5 args,no need to send the clear text password when blog is activated.
		add_filter( 'wpmu_welcome_notification', '__return_false', 110 );
		// 5 args,no need to send the clear text password when blog is activated.
		add_filter( 'wpmu_welcome_user_notification', '__return_false', 110 );
	}

	/**
	 * Remove the BuddyPress attached filters for various notifications
	 */
	public function remove_bp_filters() {

		if ( has_filter( 'wpmu_signup_user_notification', 'bp_core_activation_signup_user_notification' ) ) {
			remove_filter( 'wpmu_signup_user_notification', 'bp_core_activation_signup_user_notification', 1 ); //remove bp user notification for activating account
		}

		if ( has_filter( 'wpmu_signup_blog_notification', 'bp_core_activation_signup_blog_notification' ) ) { //remove bp blog notification
			remove_filter( 'wpmu_signup_blog_notification', 'bp_core_activation_signup_blog_notification', 1 ); //remove bp blog notification
		}

		if ( has_filter( 'wpmu_signup_user_notification', 'bp_core_activation_signup_user_notification' ) ) {
			remove_filter( 'wpmu_signup_user_notification', 'bp_core_activation_signup_user_notification', 1 );
		}
	}

	/**
	 * Is auto activation mode enabled.
	 *
	 * @return bool
	 */
	private function is_auto_activation_mode() {
		return apply_filters( 'bpajaxr_is_auto_activation_mode', bpajaxr_get_option( 'enable_auto_activation' ) );
	}
}
