<?php

/**
 * Reset Password Controller
 *
 * @package    BP Ajax Registration
 * @copyright  Copyright (c) 2018, Brajesh Singh
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     Brajesh Singh
 * @since      1.0.0
 */

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Password reset Controller.
 */
class BPAjaxr_Reset_Password_Controller {

	/**
	 * Process request.
	 *
	 * @param BPAjaxr_Request $request Request object.
	 *
	 * @return bool
	 */
	public function process( BPAjaxr_Request $request ) {

		list( $rp_path ) = explode( '?', wp_unslash( $_SERVER['REQUEST_URI'] ) );

		// user has clicked our link.
		// set cookie and redirect to this page again.
		if ( $request->get( 'key' ) ) {
			$this->set_cookies( $request, $rp_path );
			$request->flash_except( 'pass1', 'pass2' );
			return false;
		}

		// if we are here, most probably, we want to allow user to reset password.
		$user = $this->get_user( $request );

		if ( ! $user || is_wp_error( $user ) ) {
			$this->expire_cookie( $rp_path );

			if ( ! $user ) {
				bpajaxr_helper()->add_feedback( __( 'There was an issue, Please try again later.', 'bp-ajax-registration' ), 'error' );
			} else {
				bpajaxr_helper()->add_feedback( $user->get_error_message(), 'error' );
			}
		}

		$errors = new \WP_Error();

		if ( $request->get('pass1') && $request->get('pass1') != $request->get('pass2') ) {
			$errors->add( 'password_reset_mismatch', __( 'The passwords do not match.', 'bp-ajax-registration' ) );
		}

		/**
		 * Fires before the password reset procedure is validated.
		 *
		 * @param object           $errors WP Error object.
		 * @param WP_User|WP_Error $user   WP_User object if the login and reset key match. WP_Error object otherwise.
		 */
		do_action( 'validate_password_reset', $errors, $user );

		if ( ( ! $errors->get_error_code() ) && $request->get( 'pass1' ) ) {
			reset_password( $user, $request->get( 'pass1' ) );
			$this->expire_cookie( $rp_path );
			bpajaxr_helper()->add_feedback( __( 'Your password has been reset.', 'bp-ajax-registration' ), 'general' );
			return false;
		} else {
			bpajaxr_helper()->add_feedback( $errors->get_error_message(), 'error' );
		}
	}

	/**
	 * Get the user details.
	 *
	 * @param BPAjaxr_Request $request request object.
	 *
	 * @return bool|WP_Error|WP_User
	 */
	private function get_user( BPAjaxr_Request $request ) {
		$rp_cookie = $this->get_cookie_name();
		// if we are here, we are about to reset the password.
		if ( isset( $_COOKIE[ $rp_cookie ] ) && 0 < strpos( $_COOKIE[ $rp_cookie ], ':' ) ) {
			list( $rp_login, $rp_key ) = explode( ':', wp_unslash( $_COOKIE[ $rp_cookie ] ), 2 );
			$user = check_password_reset_key( $rp_key, $rp_login );
			if ( $request->get( 'pass1' ) && ! hash_equals( $rp_key, $request->get( 'rp_key' ) ) ) {
				$user = false;
			}
		} else {
			$user = false;
		}

		return $user;
	}

	/**
	 * Set cookies for reset password.
	 *
	 * @param BPAjaxr_Request $request request object.
	 * @param string          $rp_path url path.
	 */
	private function set_cookies( BPAjaxr_Request $request, $rp_path ) {
		$rp_cookie = $this->get_cookie_name();
		$value = sprintf( '%s:%s', wp_unslash( $request->get( 'login' ) ), wp_unslash( $request->get( 'key' ) ) );
		setcookie( $rp_cookie, $value, 0, $rp_path, COOKIE_DOMAIN, is_ssl(), true );
	}

	/**
	 * Expire cookie.
	 *
	 * @param string $rp_path url path.
	 */
	private function expire_cookie( $rp_path ) {
		$rp_cookie = $this->get_cookie_name();
		setcookie( $rp_cookie, ' ', time() - YEAR_IN_SECONDS, $rp_path, COOKIE_DOMAIN, is_ssl(), true );
	}

	/**
	 * Get cookie name for reset password.
	 *
	 * @return string
	 */
	private function get_cookie_name() {
		return  'wp-resetpass-' . COOKIEHASH;
	}
}
