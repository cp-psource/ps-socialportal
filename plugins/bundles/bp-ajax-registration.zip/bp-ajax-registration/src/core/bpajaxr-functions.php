<?php
/**
 * Functions
 *
 * @package    BP Ajax Registration
 * @copyright  Copyright (c) 2018, Brajesh Singh
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     Brajesh Singh
 * @since      1.0.0
 */

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Load template.
 *
 * @param string $template template name relative to the style.
 */
function bpajaxr_load_template( $template ) {

	$located = bpajaxr_locate_template( $template );
	if ( $located ) {
		require $located;
	}
}

/**
 * Locate the template file. Returns the absolute path of file.
 *
 * @param string $template template name relative to the style.
 *
 * @return string
 */
function bpajaxr_locate_template( $template ) {
	$fallback_path = bpajaxr_helper()->path . 'templates';
	$theme         = bpajaxr_get_current_theme();

	$located = locate_template( array( "{$theme}/{$template}" ), false, false );
	if ( ! $located ) {
		$located = "{$fallback_path}/{$theme}/{$template}";
	}

	if ( is_readable( $located ) ) {
		return $located;
	}

	return false;
}

/**
 * Get currently active theme.
 *
 * @return string
 */
function bpajaxr_get_current_theme() {
	return 'bpajaxr/' . bpajaxr_get_current_style();
}

/**
 * Get the current selected style.
 *
 * @return string|null
 */
function bpajaxr_get_current_style() {
	return bpajaxr_get_option( 'theme_style', 'default' );
}

/**
 * Get an option.
 *
 * @param string $option_name option name.
 * @param mixed $default default value.
 *
 * @return mixed|null
 */
function bpajaxr_get_option( $option_name, $default = null ) {

	if ( is_multisite() && bpajaxr_helper()->is_network_active() ) {
		$options = get_site_option( 'bpajaxr-settings', bpajaxr_get_default_options() );
	} else {
		$options = get_option( 'bpajaxr-settings', bpajaxr_get_default_options() );
	}

	return isset( $options[ $option_name ] ) ? $options[ $option_name ] : $default;
}

/**
 * Get default options.
 *
 * @return array
 */
function bpajaxr_get_default_options() {
	return array(
		'enable_registration'    => 1,
		'enable_login'           => 1,
		'enable_forget_password' => 1,
		'theme_style'            => 'default',

		'registration_link_selector'      => '.bpajaxr-signup-link, .bp-signup a, .bp-register-nav a, #login-text a, a.bp-ajaxr, #wp-admin-bar-bp-register a, .bp-login-widget-register-link a, a.vbpregister, a.register-btn, a.register',
		'enable_auto_activation'      => 1,
		'enable_auto_login'           => 1,
		'registration_redirect_url'   => '',
		'registration_success_action' => 'reload',

		'login_link_selector'  => '.bpajaxr-login-link, #wp-admin-bar-bp-login a',
		'login_redirect_url'   => '',
		'login_success_action' => 'reload',

		'forget_password_link_selector'  => '.bpajaxr-forget-password-link',
		'forget_password_success_action' => 'show_login',
		'forget_password_redirect_url'   => '',

	);
}


/**
 * Get the parsed dynamic url.
 *
 * @param string $url url.
 * @param int $user_id user id.
 *
 * @return string
 */
function bpajaxr_get_parsed_url( $url, $user_id = 0 ) {

	if ( empty( $url ) ) {
		return $url;
	}

	$tokens = array(
		'[site.url]'    => home_url( '/' ),
		'[network.url]' => network_home_url( '/' ),
	);

	$user = null;
	if ( $user_id ) {
		$user = get_user_by( 'id', $user_id );
	} elseif ( is_user_logged_in() ) {
		$user = wp_get_current_user();
	}

	if ( $user ) {
		$tokens['[user.url]']      = bp_core_get_user_domain( $user->ID );
		$tokens['[user.login]']    = $user->user_login;
		$tokens['[user.nicename]'] = $user->user_nicename;
		$tokens['[user.id]']       = $user->ID;
	}

	$find    = array_keys( $tokens );
	$replace = array_values( $tokens );

	return str_replace( $find, $replace, trim( $url ) );
}

/**
 * Locate an asset from the template or fallback to plugin.
 *
 * @param string $asset_file path.
 *
 * @return string
 */
function bpajaxr_locate_assets( $asset_file ) {

	$style = bpajaxr_get_current_style();

	$theme_dir = 'bpajaxr/' . $style;

	if ( is_readable( get_stylesheet_directory() . '/' . $theme_dir . '/' . $asset_file ) ) {
		return get_stylesheet_directory_uri() . '/' . $theme_dir . '/' . $asset_file;
	} elseif ( is_readable( get_template_directory() . '/' . $theme_dir . '/' . $asset_file ) ) {
		return get_template_directory_uri() . '/' . $theme_dir . '/' . $asset_file;
	} else {

		return bpajaxr_helper()->url . 'templates/' . $theme_dir . '/' . $asset_file;
	}
}


/**
 * Prepare selectors by removing new line.
 *
 * @param string $selectors selectors.
 *
 * @return string
 */
function bpajaxr_prepare_selectors( $selectors = '' ) {
	return $selectors;
}

/**
 * Placeholder to attach for loading other plugins.
 *
 * @param bool $loaded is loaded.
 *
 * @return bool
 */
function bpajaxr_is_form_loaded( $loaded = false ) {
	if ( ! is_user_logged_in() ) {
		$loaded = true;
	}

	return $loaded;
}