<?php
/**
 * Registration Validator
 *
 * @package    BP Ajax Registration
 * @copyright  Copyright (c) 2018, Brajesh Singh
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     Brajesh Singh
 * @since      1.0.0
 */

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Account Validator
 */
class BPAjaxr_Registration_Validator {

	/**
	 * Validate account details.
	 */
	public function validate_account_details() {
		$bp = buddypress();
		// Check the base account details for problems.
		$account_details = bp_core_validate_user_signup( $_POST['signup_username'], $_POST['signup_email'] );

		// If there are errors with account details, set them for display.
		if ( ! empty( $account_details['errors']->errors['user_name'] ) ) {
			$bp->signup->errors['signup_username'] = $account_details['errors']->errors['user_name'][0];
		}

		if ( ! empty( $account_details['errors']->errors['user_email'] ) ) {
			$bp->signup->errors['signup_email'] = $account_details['errors']->errors['user_email'][0];
		}

		// Check that both password fields are filled in.
		if ( empty( $_POST['signup_password'] ) || empty( $_POST['signup_password_confirm'] ) ) {
			$bp->signup->errors['signup_password'] = __( 'Please make sure you enter your password twice', 'bp-ajax-registration' );
		}

		// Check that the passwords match.
		if ( ( ! empty( $_POST['signup_password'] ) && ! empty( $_POST['signup_password_confirm'] ) ) && $_POST['signup_password'] != $_POST['signup_password_confirm'] ) {
			$bp->signup->errors['signup_password'] = __( 'The passwords you entered do not match.', 'bp-ajax-registration' );
		}

		$bp->signup->username = $_POST['signup_username'];
		$bp->signup->email    = $_POST['signup_email'];

	}

	/**
	 * Validate xprofile fields.
	 */
	public function validate_xprofile_fields() {
		$bp = buddypress();
		// Now we've checked account details, we can check profile information.
		if ( bp_is_active( 'xprofile' ) ) {

			// Make sure hidden field is passed and populated.
			if ( isset( $_POST['signup_profile_field_ids'] ) && ! empty( $_POST['signup_profile_field_ids'] ) ) {

				// Let's compact any profile field info into an array.
				$profile_field_ids = explode( ',', $_POST['signup_profile_field_ids'] );

				// Loop through the posted fields formatting any datebox values then validate the field.
				foreach ( (array) $profile_field_ids as $field_id ) {
					if ( ! isset( $_POST[ 'field_' . $field_id ] ) ) {
						if ( isset( $_POST[ 'field_' . $field_id . '_day' ] ) ) {
							$_POST[ 'field_' . $field_id ] = date( 'Y-m-d H:i:s', strtotime( $_POST[ 'field_' . $field_id . '_day' ] . $_POST[ 'field_' . $field_id . '_month' ] . $_POST[ 'field_' . $field_id . '_year' ] ) );
						}
					}

					// Create errors for required fields without values.
					if ( xprofile_check_is_required_field( $field_id ) && empty( $_POST[ 'field_' . $field_id ] ) ) {
						$bp->signup->errors[ 'field_' . $field_id ] = __( 'This is a required field', 'bp-ajax-registration' );
					}
				}

				// This situation doesn't naturally occur so bounce to website root.
			} else {
			}
		}
	}

	/**
	 * Validate blog details.
	 *
	 * @return array
	 */
	public function validate_blog_details() {
		$bp           = buddypress();
		$blog_details = array();
		// Finally, let's check the blog details, if the user wants a blog and blog creation is enabled.
		if ( ! empty( $_POST['signup_with_blog'] ) ) {
			$active_signup = $bp->site_options['registration'];

			if ( 'blog' == $active_signup || 'all' == $active_signup ) {
				$blog_details = bp_core_validate_blog_signup( $_POST['signup_blog_url'], $_POST['signup_blog_title'] );

				// If there are errors with blog details, set them for display.
				if ( ! empty( $blog_details['errors']->errors['blogname'] ) ) {
					$bp->signup->errors['signup_blog_url'] = $blog_details['errors']->errors['blogname'][0];
				}

				if ( ! empty( $blog_details['errors']->errors['blog_title'] ) ) {
					$bp->signup->errors['signup_blog_title'] = $blog_details['errors']->errors['blog_title'][0];
				}
			}
		}

		return $blog_details;

	}
}
