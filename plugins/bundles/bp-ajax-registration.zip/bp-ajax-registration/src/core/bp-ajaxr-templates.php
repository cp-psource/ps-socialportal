<?php

// recaptcha support.
add_filter( 'bp_recaptcha_load', 'bpajaxr_is_form_loaded' );


function bpajaxr_inject_loaders() {
	$url = bpajaxr_helper()->url;
	echo "<div class='bp-ajaxr-loader' style='display:none;'><img src='{$url}_inc/loading.gif' /></div>";
}
add_action( 'bp_after_registration_submit_buttons', 'bpajaxr_inject_loaders' );


/**
 * Disable the default recaptch and enable it for the ajax form
 */
function bp_ajaxr_disable_default_recaptcha() {

	if ( has_action( 'bp_before_registration_submit_buttons', 'bp_recaptcha_add_code' ) ) {
		remove_action( 'bp_before_registration_submit_buttons', 'bp_recaptcha_add_code' );
		add_action( 'bp_before_registration_submit_buttons', 'bpajaxr_inject_captcha' );
	}
}

function bp_ajaxr_enable_default_recaptcha() {
	if ( function_exists( 'bp_recaptcha_add_code' ) ) {
		add_action( 'bp_before_registration_submit_buttons', 'bp_recaptcha_add_code' );
		remove_action( 'bp_before_registration_submit_buttons', 'bpajaxr_inject_captcha' );
	}
}

//inject captach validator

function bpajaxr_inject_captcha() {

	if ( ! function_exists( 'bp_recaptcha_add_code' ) ) {
		return;
	}

	$bp = buddypress();

	$html = '<div class="register-section" id="security-section">';
	$html .= '<div class="editfield">';
	$html .= '<label>CAPTCHA code</label>';

	if ( ! empty( $bp->signup->errors['recaptcha_response_field'] ) ) {
		$html .= '<div class="error">';
		$html .= $bp->signup->errors['recaptcha_response_field'];
		$html .= '</div>';
	}

	$html .= '<div id="bp_ajaxr_ajax_form_validator"></div>';
	$html .= '</div>';
	$html .= '</div>';
	echo $html;

	$public_key = get_option( 'bpcapt_public' );
	$theme      = get_option( 'bpcapt_theme' );
	?>
	<script type="text/javascript">
		var _bpajaxr_recaptcha_config = {
			sitekey: "<?php echo $public_key;?>",
			theme: "<?php echo $theme;?>"
		};
	</script>
	<?php
}
