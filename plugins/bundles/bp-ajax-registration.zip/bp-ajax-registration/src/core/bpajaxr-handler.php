<?php
/**
 * Ajax Handler.
 *
 * @package    BP Ajax Registration
 * @copyright  Copyright (c) 2018, Brajesh Singh
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     Brajesh Singh
 * @since      1.0.0
 */

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Class BPAjaxr_Handler
 */
class BPAjaxr_Handler {

	/**
	 * Boot routine.
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Setup hooks.
	 */
	private function setup() {

		add_action( 'wp_ajax_nopriv_bpajaxr_action_login', array( $this, 'login' ) );
		add_action( 'wp_ajax_nopriv_bpajaxr_action_register', array( $this, 'register' ) );

		add_action( 'wp_ajax_nopriv_bpajaxr_action_retrieve_password', array( $this, 'retrieve_password' ) );
		add_action( 'wp_ajax_bpajaxr_action_reset_password', array( $this, 'reset_password' ) );

		add_action( 'wp_ajax_bpajaxr_reload_all_panels', array( $this, 'reload_all_panels' ) );
		add_action( 'wp_ajax_bpajaxr_reload_panel', array( $this, 'reload_panel' ) );
	}

	/**
	 * Handle Login
	 */
	public function login() {

		$request = bpajaxr_helper()->request;
		$request->rebuild( $_POST, 'POST' );


		if ( ! wp_verify_nonce( $request->get( '_wpnonce' ), 'bpajaxr_login' ) ) {
			bpajaxr_helper()->add_feedback( __( 'Invalid request.', 'bp-ajax-registration' ), 'error' );

			$contents = $this->get_template_content( 'panel-login.php' );
			wp_send_json_error( array(
				'contents'     => $contents,
				'redirect'     => '',
				'update_panel' => 'login',
			) );
		}

		$controller = new BPAjaxr_Login_Controller();

		if ( ! $controller->process( $request ) ) {
			$contents = $this->get_template_content( 'panel-login.php' );
			wp_send_json_error( array(
				'contents'     => $contents,
				'redirect'     => '',
				'update_panel' => 'login',
			) );
		}

		$redirect     = bpajaxr_get_option( 'login_success_action' );
		$redirect_url = 'redirect' === $redirect ? bpajaxr_get_parsed_url( bpajaxr_get_option( 'login_redirect_url' ) ) : '';

		$contents = $this->get_template_content( 'panel-login.php' );
		wp_send_json_success( array(
			'message'      => __( 'Login successful.', 'bp-ajax-registration' ),
			'redirect'     => 1,
			'redirect_url' => apply_filters( 'bpajaxr_login_redirect_url', $redirect_url, wp_get_current_user() ),
			'contents'     => $contents,
		) );
	}

	/**
	 * Register.
	 */
	public function register() {
		add_filter( 'bp_xprofile_is_richtext_enabled_for_field', '__return_false' );
		$request = bpajaxr_helper()->request;
		$request->rebuild( $_POST, 'POST' );

		if ( ! wp_verify_nonce( $request->get( '_wpnonce' ), 'bp_new_signup' ) ) {
			bpajaxr_helper()->add_feedback( __( 'Invalid request.', 'bp-ajax-registration' ), 'error' );

			$contents = $this->get_template_content( 'panel-registration.php' );

			wp_send_json_error( array(
				'contents'     => $contents,
				'update_panel' => 'registration',
				'redirect'     => '',
			) );
		}

		$controller = new BPAjaxr_Registration_Controller();
		$response   = $controller->process( $request );

		$contents = $this->get_template_content( 'panel-registration.php' );
		if ( ! $response ) {
			wp_send_json_error( array(
				'contents'     => $contents,
				'update_panel' => 'registration',
				'redirect'     => '',
			) );
		}

		$response['contents'] = $contents;
		wp_send_json_success( $response );
	}

	/**
	 * Retrieve Password. Send mail to reset password.
	 */
	public function retrieve_password() {
		$request = bpajaxr_helper()->request;
		$request->rebuild( $_POST, 'POST' );

		if ( ! wp_verify_nonce( $request->get( '_wpnonce' ), 'bpajaxr_forget_password' ) ) {
			bpajaxr_helper()->add_feedback( __( 'Invalid request.', 'bp-ajax-registration' ), 'error' );

			$contents = $this->get_template_content( 'panel-forget-password.php' );
			wp_send_json_error( array(
				'contents'     => $contents,
				'redirect'     => '',
				'update_panel' => 'forget-password',
			) );
		}

		$controller = new BPAjaxr_Forget_Password_Controller();

		if ( ! $controller->process( $request ) ) {
			$contents = $this->get_template_content( 'panel-forget-password.php' );
			wp_send_json_error( array(
				'contents'     => $contents,
				'redirect'     => '',
				'update_panel' => 'forget-password',
			) );
		}

		$redirect      = bpajaxr_get_option( 'forget_password_success_action' );
		$update_panel  = '';
		$visible_panel = '';
		$redirect_url  = '';

		if ( 'show_login' === $redirect ) {
			$update_panel  = 'login';
			$visible_panel = 'login';
			$redirect      = 0;
		} elseif ( 'redirect' === $redirect ) {
			$redirect     = 1;
			$redirect_url = bpajaxr_get_parsed_url( bpajaxr_get_option( 'forget_password_redirect_url' ) );
		} else {
			$redirect     = 1;
			$redirect_url = '';
		}

		wp_send_json_success( array(
			'message'       => __( 'Please check your email.', 'bp-ajax-registration' ),
			'redirect'      => $redirect,
			'redirect_url'  => apply_filters( 'bpajaxr_retrieve_password_redirect_url', $redirect_url ),
			'contents'      => $this->get_template_content( 'panel-login.php' ),
			'update_panel'  => $update_panel,
			'visible_panel' => $visible_panel,
		) );
	}

	/**
	 * Reset password.
	 */
	public function reset_password() {
	}

	/**
	 * Reload contents for all panel.
	 */
	public function reload_all_panels() {
		// verify nonce?
		wp_send_json_success( $this->get_template_content( 'panels.php' ) );
	}


	/**
	 * Reload contents for a given panel.
	 */
	public function reload_panel() {
		// verify nonce?
		$panel = isset( $_POST['panel_name'] ) ? trim( $_POST['panel_name'] ) : '';

		if ( empty( $panel ) ) {
			wp_send_json_error( __( 'Please provide panel name.', 'bp-ajax-registration' ) );
		}

		$template = "panel-{$panel}.php";
		$located  = bpajaxr_locate_template( $template );

		if ( ! $located ) {
			wp_send_json_error( __( 'Please provide a valid panel name.', 'bp-ajax-registration' ) );
		}
		wp_send_json_success( $this->get_template_content( 'panels.php' ) );
	}

	/**
	 * Get the template's content.
	 *
	 * @param string $template_name template file name.
	 *
	 * @return string
	 */
	private function get_template_content( $template_name ) {
		ob_start();
		bpajaxr_load_template( $template_name );

		return ob_get_clean();
	}
}
