<?php
/**
 * Link Filters.
 *
 * @package    BuddyPress Ajax Registration
 * @copyright  Copyright (c) 2018, Brajesh Singh
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     Brajesh Singh
 * @since      1.0.0
 */

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Class BPAjaxr_Filters
 */
class BPAjaxr_Filters {

	/**
	 * Boot routine.
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Setup filters.
	 */
	private function setup() {
		// Filter register link in wp_register().
		add_filter( 'register', array( $this, 'filter_wp_register' ) );
		add_filter( 'loginout', array( $this, 'filter_loginout' ) );

		// add support for username availability checker.
		add_filter( 'buddydev_username_availability_checker_load_assets', 'bpajaxr_is_form_loaded' );

		// make sure that the conditional profile field is enabled on all page.
		add_filter( 'bp_is_conditional_profile_field_active', 'bpajaxr_is_form_loaded' );
	}

	/**
	 * Filter link and add 'bpajaxr-signup-link' class.
	 *
	 * @param string $link link.
	 *
	 * @return string
	 */
	public function filter_wp_register( $link ) {
		return str_replace( '<a ', '<a class="bpajaxr-signup-link" ', $link );
	}

	/**
	 * Filter link and add 'bpajaxr-login-link' class to login link.
	 *
	 * @param string $link link.
	 *
	 * @return string
	 */
	public function filter_loginout( $link ) {
		return is_user_logged_in() ? $link : str_replace( '<a ', '<a class="bpajaxr-login-link" ', $link );
	}
}

BPAjaxr_Filters::boot();
