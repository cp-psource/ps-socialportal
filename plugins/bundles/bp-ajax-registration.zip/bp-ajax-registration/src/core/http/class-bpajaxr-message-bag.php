<?php
/**
 * Message Bag, contains one or more messages.
 *
 * Based on Laravel's Message Bag.
 *
 * @package    BP Ajax Registration
 * @copyright  Copyright (c) 2018, Brajesh Singh
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     Brajesh Singh
 * @since      1.0.0
 */

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Message Bag.
 */
class BPAjaxr_Message_Bag implements  Countable, JsonSerializable {

	/**
	 * All messages.
	 *
	 * @var array
	 */
	protected $messages = array();

	/**
	 * Create a new instance.
	 *
	 * @param  array $messages messages.
	 */
	public function __construct( $messages = array() ) {
		foreach ( $messages as $key => $value ) {
			$this->messages[ $key ] = is_array( $value ) ? $value : (array) $value;
		}
	}

	/**
	 * Add a message to the bag.
	 *
	 * @param  string $key key.
	 * @param  string $message message.
	 *
	 * @return $this
	 */
	public function add( $key, $message ) {
		if ( $this->is_unique( $key, $message ) ) {
			$this->messages[ $key ][] = $message;
		}

		return $this;
	}

	/**
	 * Add an array of messages or import messages from WP_Error.
	 *
	 * @param array | \WP_Error $messages array of messages or Wp Error.
	 */
	public function add_messages( $messages ) {
		if ( empty( $messages ) ) {
			return;
		}

		if ( is_wp_error( $messages ) ) {
			$this->add_messages_from_wp_error( $messages );
		} else {
			$this->add_messages_from_array( $messages );
		}
	}

	/**
	 * Get all of the messages from the bag for a given key.
	 *
	 * @param  string $key key.
	 *
	 * @return array
	 */
	public function get( $key ) {
		// If the message exists in the container, we will transform it and return
		// the message. Otherwise, we'll check if the key is implicit & collect
		// all the messages that match a given key and output it as an array.
		if ( array_key_exists( $key, $this->messages ) ) {
			return $this->transform( $this->messages[ $key ], $key );
		}

		if ( strpos( $key, '*' ) !== false ) {
			return $this->get_messages_for_wildcard_key( $key );
		}

		return array();
	}

	/**
	 * Get the first message from the bag for a given key.
	 *
	 * @param  string $key key.
	 *
	 * @return string
	 */
	public function first( $key = null ) {
		$messages = is_null( $key ) ? $this->all() : $this->get( $key );

		$first_message = current( $messages );

		return is_array( $first_message ) ? current( $first_message ) : $first_message;
	}

	/**
	 * Get all of the messages for every key in the bag.
	 *
	 * @return array
	 */
	public function all() {

		$all = array();

		foreach ( $this->messages as $key => $messages ) {
			$all = array_merge( $all, $this->transform( $messages, $key ) );
		}

		return $all;
	}

	/**
	 * Get all of the unique messages for every key in the bag.
	 *
	 * @return array
	 */
	public function unique() {
		return array_unique( $this->all() );
	}

	/**
	 * Delete a key from the message bag.
	 *
	 * @param string $key key name.
	 *
	 * @return self
	 */
	public function delete( $key ) {
		unset( $this->messages[ $key ] );
		return $this;
	}

	/**
	 * Get the raw messages in the container.
	 *
	 * @return array
	 */
	public function get_messages() {
		return $this->messages;
	}

	/**
	 * Get all keys.
	 *
	 * @return array
	 */
	public function keys() {
		return array_keys( $this->messages );
	}

	/**
	 * Determine if the message bag has any messages.
	 *
	 * @return bool
	 */
	public function any() {
		return $this->count() > 0;
	}

	/**
	 * Determine if messages exist for all of the given keys.
	 *
	 * @param  array|string $key key or keys.
	 *
	 * @return bool
	 */
	public function has( $key = null ) {
		if ( is_null( $key ) ) {
			return $this->any();
		}

		$keys = is_array( $key ) ? $key : func_get_args();

		foreach ( $keys as $key ) {
			if ( ! $this->first( $key ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Determine if messages exist for any of the given keys.
	 *
	 * @param  array|string $keys keys.
	 *
	 * @return bool
	 */
	public function has_any( $keys = array() ) {
		$keys = is_array( $keys ) ? $keys : func_get_args();

		foreach ( $keys as $key ) {
			if ( $this->has( $key ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check if we have any message.
	 *
	 * @return bool
	 */
	public function is_empty() {
		return ! $this->any();
	}

	/**
	 * Merge a new array of messages into the bag.
	 *
	 * @param self $message_bag other message bag.
	 *
	 * @return self
	 */
	public function merge( self $message_bag ) {
		$messages       = $message_bag->messages;
		$this->messages = array_merge_recursive( $this->messages, $messages );

		return $this;
	}

	/**
	 * Clear the message bag. remove all data.
	 *
	 * @return self
	 */
	public function clear() {
		$this->messages = array();
		return $this;
	}

	/**
	 * Get the number of messages in the container.
	 *
	 * @return int
	 */
	public function count() {
		return count( $this->messages, COUNT_RECURSIVE ) - count( $this->messages );
	}

	/**
	 * Convert the object into something JSON serializable.
	 *
	 * @return array
	 */
	public function jsonSerialize() {
		return $this->to_array();
	}

	/**
	 * Get the instance as an array.
	 *
	 * @return array
	 */
	public function to_array() {
		return $this->messages;
	}

	/**
	 * Convert the object to its JSON representation.
	 *
	 * @param  int $options options.
	 *
	 * @return string
	 */
	public function to_json( $options = 0 ) {
		return wp_json_encode( $this->jsonSerialize(), $options );
	}

	/**
	 * Convert the message bag to its string representation.
	 *
	 * @return string
	 */
	public function __toString() {
		return $this->to_json();
	}

	/**
	 * Get the messages for a wildcard key.
	 *
	 * @param  string $key key.
	 *
	 * @return array
	 */
	protected function get_messages_for_wildcard_key( $key ) {
		$found_messages = array();

		foreach ( $this->messages as $message_key => $value ) {
			if ( self::is( $key, $message_key ) ) {
				$found_messages[] = $this->transform( $value, $message_key );
			}
		}

		return $found_messages;
	}

	/**
	 * Determine if a key and message combination already exists.
	 *
	 * @param  string $key key.
	 * @param  string $message message.
	 *
	 * @return bool
	 */
	protected function is_unique( $key, $message ) {
		$messages = (array) $this->messages;

		return ! isset( $messages[ $key ] ) || ! in_array( $message, $messages[ $key ] );
	}

	/**
	 * Format an array of messages(currently does not do any extra processing).
	 *
	 * @param  array  $messages messages.
	 * @param  string $message_key key.
	 *
	 * @return array
	 */
	protected function transform( $messages, $message_key ) {
		$transformed_strings = array();

		foreach ( $messages as $message ) {
			$transformed_strings[] = $message; // in future, we may want to allow modification here.
		}

		return $transformed_strings;
	}

	/**
	 * Add WP_Error to our messages collection.
	 *
	 * @param \WP_Error $error error object.
	 */
	private function add_messages_from_wp_error( \WP_Error $error ) {
		foreach ( $error->get_error_codes() as $code ) {
			$messages = $error->get_error_messages( $code );
			foreach ( $messages as $message ) {
				$this->add( $code, $message );
			}
		}
	}

	/**
	 * Add errors from array to our request error.
	 *
	 * @param array $messages messages array.
	 */
	private function add_messages_from_array( $messages ) {
		foreach ( $messages as $code => $error ) {
			$this->add( $code, $error );
		}
	}

	/**
	 * Determine if a given string matches a given pattern.
	 *
	 * @param  string|array $pattern pattern.
	 * @param  string       $value value to match.
	 *
	 * @return bool
	 */
	private static function is( $pattern, $value ) {
		$patterns = is_array( $pattern ) ? $pattern : (array) $pattern;

		if ( empty( $patterns ) ) {
			return false;
		}

		foreach ( $patterns as $pattern ) {
			// If the given value is an exact match we can of course return true right
			// from the beginning. Otherwise, we will translate asterisks and do an
			// actual pattern match against the two strings to see if they match.
			if ( $pattern == $value ) {
				return true;
			}

			$pattern = preg_quote( $pattern, '#' );

			// Asterisks are translated into zero-or-more regular expression wildcards
			// to make it convenient to check if the strings starts with the given
			// pattern such as "library/*", making any string check convenient.
			$pattern = str_replace( '\*', '.*', $pattern );

			if ( preg_match( '#^' . $pattern . '\z#u', $value ) === 1 ) {
				return true;
			}
		}

		return false;
	}
}
