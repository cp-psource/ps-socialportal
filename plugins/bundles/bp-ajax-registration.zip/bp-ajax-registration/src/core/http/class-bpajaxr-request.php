<?php
/**
 * Http Request Representation
 *
 * @package    BP Ajax Registration
 * @copyright  Copyright (c) 2018, Brajesh Singh
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     Brajesh Singh
 * @since      1.0.0
 */

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Request
 *
 * @property-read array                 $previous last request input data.
 * @property-read array                 $input input array.
 * @property-read string                $method http method name(lowercase).
 * @property-read BPAjaxr_Message_Bag   $errors validation error messages if any.
 */
class BPAjaxr_Request {

	/**
	 * Old input.
	 *
	 * @var array
	 */
	public $previous = array();

	/**
	 * Array of input elements.
	 *
	 * @var array
	 */
	private $input = array();

	/**
	 * Request Type (post,get etc)
	 *
	 * @var string
	 */
	private $method = '';

	/**
	 * Template shared data.
	 *
	 * The data elements will be extracted and shared with the template.
	 *
	 * @var array
	 */
	private $data = array();

	/**
	 * Error bag.
	 *
	 * @var BPAjaxr_Message_Bag
	 */
	private $errors = null;

	/**
	 * Guarded properties.
	 *
	 * @var array
	 */
	private $guarded = array( 'guarded' );

	/**
	 * Request constructor.
	 *
	 * @param array  $input input elements.
	 * @param string $method request method(get,post).
	 */
	public function __construct( $input = array(), $method = '' ) {
		$this->input  = $input;
		$this->method = $method;

		$this->setup();
	}

	/**
	 * Get a property.
	 *
	 * @param string $name property name.
	 *
	 * @return null|mixed
	 */
	public function __get( $name ) {

		if ( in_array( $name, $this->guarded, true ) || ! property_exists( $this, $name ) ) {
			return null; // or should we throw some exception.
		}

		return $this->{$name};
	}

	/**
	 * Setup/init request.
	 */
	public function setup() {
		if ( ! $this->method ) {
			$this->method = strtolower( $_SERVER['REQUEST_METHOD'] );
		}
		$this->previous = array();
		$this->errors   = new BPAjaxr_Message_Bag();
	}

	/**
	 * Rebuild request.
	 *
	 * @param array  $data input data.
	 * @param string $method request method.
	 * @param array  $prev input from previous request.
	 *
	 * @return BPAjaxr_Request
	 */
	public function rebuild( $data, $method = '', $prev = array() ) {
		$this->input   = $data;

		if ( $method ) {
			$this->method = $method;
		}

		if ( $prev && is_array( $prev ) ) {
			$this->previous = $prev;
		}
		return $this;
	}

	/**
	 * Check if we have the key(or all keys if an array is specified) in the input.
	 *
	 * @param string|array $keys key(s) to check.
	 *
	 * @return bool
	 */
	public function has( $keys ) {

		if ( empty( $this->input ) ) {
			return false;
		}

		$has = true;// assume true.

		$keys = is_array( $keys ) ? $keys : (array) $keys;
		// if multiple keys are given, all keys must be present.
		foreach ( $keys as $key ) {
			if ( ! isset( $this->input[ $key ] ) ) {
				$has = false;
				break;
			}
		}

		return $has;
	}

	/**
	 * Alias of has()
	 *
	 * @see self::has()
	 *
	 * @param string|array $key keys.
	 *
	 * @return bool
	 */
	public function exists( $key ) {
		return $this->has( $key );
	}

	/**
	 * Check if any of the given key exists in the request.
	 *
	 * @param array $keys keys.
	 *
	 * @return bool
	 */
	public function any( $keys ) {
		$has = false;

		if ( empty( $this->input ) ) {
			return $has;
		}

		foreach ( $keys as $key ) {
			if ( isset( $this->input[ $key ] ) ) {
				$has = true;
				break;
			}
		}

		return $has;
	}

	/**
	 * Alias of BPAjaxr_Request::input()
	 *
	 * @see self::input()
	 *
	 * @param string $key key name.
	 *
	 * @return mixed|null
	 */
	public function get( $key ) {
		return $this->input( $key );
	}

	/**
	 * Get an input from the request.
	 *
	 * @param string $name input name.
	 * @param mixed  $default default value if input not present.
	 *
	 * @return mixed|null
	 */
	public function input( $name, $default = null ) {
		return isset( $this->input[ $name ] ) ? $this->input[ $name ] : $default;
	}

	/**
	 * Get all values in the request.
	 *
	 * @return array
	 */
	public function all() {
		return $this->input;
	}

	/**
	 * Get only the specified args.
	 *
	 * @param array|string $keys , ... array of keys or multiple keys.
	 *  Example: only('name', 'age') or only(['name', 'age']).
	 *
	 * @return array
	 */
	public function only( $keys ) {
		$keys = func_get_arg( 0 );
		$keys = is_array( $keys ) ? $keys : func_get_args();
		$data = array();

		foreach ( $keys as $key ) {
			$data[ $key ] = $this->input( $key );
		}

		return $data;
	}

	/**
	 * Get every value except for the keys..
	 *
	 * @param array|string $keys , ... array of keys or multiple keys.
	 *  Example: except('name', 'age') or except(['name', 'age']).
	 *
	 * @return array
	 */
	public function except( $keys ) {
		$keys = func_get_arg( 0 );
		$keys = is_array( $keys ) ? $keys : func_get_args();
		// copy data.
		$data = array_merge( array(), $this->input );

		foreach ( $keys as $key ) {
			unset( $data[ $key ] );
		}

		return $data;
	}

	/**
	 * Get old data.
	 *
	 * @param string     $key key.
	 * @param mixed|null $default default value.
	 *
	 * @return mixed|string
	 */
	public function old( $key, $default = null ) {
		$value = null;
		if ( ! empty( $this->input ) ) {
			$value = $this->input( $key, $default );
		} elseif ( $this->previous ) {
			$value = isset( $this->previous[ $key ] ) ? $this->previous[ $key ] : $default;
		}

		return $value;
	}

	/**
	 * Flash the selected input to session.
	 *
	 * @param string|array $keys keys to flash.
	 */
	public function flash_only( $keys ) {
		$keys  = is_array( $keys ) ? $keys : func_get_args();
		$items = array();

		foreach ( $keys as $key ) {
			$items[ $key ] = $this->input[ $key ];
		}

		$this->input = $items;// override.
	}

	/**
	 * Flash except these keys.
	 *
	 * @param string|array $excluded_keys excluded keys.
	 */
	public function flash_except( $excluded_keys ) {
		$keys = is_array( $excluded_keys ) ? $excluded_keys : func_get_args();

		foreach ( $keys as $key ) {
			unset( $this->input[ $key ] );
		}
	}

	/**
	 * Clear Request.
	 */
	public function clear() {
		$this->data = array();
	}

	/**
	 * Make the data available in template.
	 *
	 * @param string|mixed|array $data an array of 2 elements.
	 *
	 * @return self
	 */
	public function with( $data ) {
		$data = is_array( $data ) ? $data : $this->create_pair( func_get_args() );

		if ( $data ) {
			$this->data = array_merge( $this->data, $data );
		}
		return $this;
	}

	/**
	 * Add error to the request object.
	 *
	 * @param string $code code.
	 * @param string $message message.
	 */
	public function add_error( $code, $message ) {
		$this->errors->add( $code, $message );
	}

	/**
	 * Add an array of errors or WP_Error object.
	 *
	 * @param array|\WP_Error $errors array or WP_Error.
	 */
	public function add_errors( $errors ) {
		$this->errors->add_messages( $errors );
	}

	/**
	 * Create a pair as array key value.
	 *
	 * @param array $data data array(expects 2 elements).
	 *
	 * @return array
	 */
	protected function create_pair( $data ) {
		if ( empty( $data ) || 2 !== count( $data ) ) {
			return array();
		}

		return array( $data[0] => $data[1] );
	}
}
