<?php
/**
 * Assets Loader
 *
 * @package    BuddyPress Ajax Registration
 * @subpackage Bootstrap
 * @copyright  Copyright (c) 2018, Brajesh Singh
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     Brajesh Singh
 * @since      1.0.0
 */

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Assets Loader.
 */
class BPAjaxr_Assets_Loader {

	/**
	 * Boot it.
	 */
	public static function boot() {
		$self = new self();
		add_action( 'wp_footer', array( $self, 'load_form' ), 9 );
		add_action( 'login_footer', array( $self, 'load_form' ), 9 );

		add_action( 'login_head', array( $self, 'add_ajax_url' ) );

		add_action( 'wp_enqueue_scripts', array( $self, 'register' ) );
		add_action( 'wp_enqueue_scripts', array( $self, 'enqueue' ) );

		add_action( 'login_enqueue_scripts', array( $self, 'register' ) );
		add_action( 'login_enqueue_scripts', array( $self, 'enqueue' ) );
	}

	/**
	 * Register assets.
	 */
	public function register() {
		$this->register_vendors();
		$this->register_core();
	}

	/**
	 * Load assets.
	 */
	public function enqueue() {

		wp_enqueue_style( 'magnific-css' );

		wp_enqueue_style( 'bpajaxr-layout' );
		wp_enqueue_style( 'bpajaxr-style' );

		wp_enqueue_script( 'magnific-js' );
		wp_enqueue_script( 'bpajax-helper' );

		global $pagenow;

		$setting = array(
			'redirectURL'           => 'wp-login.php' === $pagenow ? home_url() : '',
			'selectors'             => array(
				'login'          => bpajaxr_prepare_selectors( bpajaxr_get_option( 'login_link_selector' ) ),
				'registration'   => bpajaxr_prepare_selectors( bpajaxr_get_option( 'registration_link_selector' ) ),
				'forgetPassword' => bpajaxr_prepare_selectors( bpajaxr_get_option( 'forget_password_link_selector' ) ),
			),
			'loginEnabled'          => (bool) bpajaxr_get_option( 'enable_login', 1 ),
			'registrationEnabled'   => (bool) bpajaxr_get_option( 'enable_registration', 1 ),
			'forgetPasswordEnabled' => (bool) bpajaxr_get_option( 'enable_forget_password', 1 ),
		);

		wp_localize_script( 'bpajax-helper', 'BPAjaxRegistration', $setting );
	}

	/**
	 * Register vendor scripts.
	 */
	private function register_vendors() {
		$url = bpajaxr_helper()->url;

		wp_register_script( 'magnific-js', $url . 'assets/js/jquery.magnific-popup.min.js', array( 'jquery' ) );
		wp_register_style( 'magnific-css', $url . 'assets/css/magnific-popup.css' );
	}

	/**
	 * Register core assets.
	 */
	private function register_core() {
		$url = bpajaxr_helper()->url;
		wp_register_style( 'bpajaxr-layout', $url . 'assets/css/bpajaxr-layout.css' );
		wp_register_style( 'bpajaxr-style', bpajaxr_locate_assets( 'assets/bpajaxr-style.css' ) );
		wp_register_script( 'bpajax-helper', $url . 'assets/js/bpajaxr-helper.js', array(
			'jquery',
			'magnific-js',
		) );
	}

	/**
	 * If the ajax loading of form is disabled, we keep the form as hidden in the footer
	 */
	public function load_form() {
		add_filter( 'bp_xprofile_is_richtext_enabled_for_field', '__return_false' );
		echo '<div id="bpajaxr-container-wrapper" style="display: none">';
		bpajaxr_load_template( 'panels.php' );
		echo '</div>';
		remove_filter( 'bp_xprofile_is_richtext_enabled_for_field', '__return_false' );
	}

	/**
	 * Print Ajax url in te head.
	 */
	public function add_ajax_url() { ?>
        <script type="text/javascript">
            ajaxurl = "<?php echo admin_url( 'admin-ajax.php' );?>";
        </script>
		<?php
	}

}
