<?php
/**
 * Bootstrapper. Initializes the plugin.
 *
 * @package    BuddyPress Ajax Registration
 * @subpackage Bootstrap
 * @copyright  Copyright (c) 2018, Brajesh Singh
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     Brajesh Singh
 * @since      1.0.0
 */

// No direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 0 );
}

/**
 * Bootstrapper.
 */
class BPAjaxr_Bootstrapper {

	/**
	 * Setup the bootstrapper.
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Bind hooks
	 */
	private function setup() {
		// called after pp_loaded.
		add_action( 'plugins_loaded', array( $this, 'load' ) );
		add_action( 'plugins_loaded', array( $this, 'admin_load' ), 9996 ); // pt-settings 1.0.4.
		add_action( 'init', array( $this, 'load_translations' ) );
		add_action( 'init', array( $this, 'init' ) );
	}

	/**
	 * Load core functions/template tags.
	 * These are non auto loadable constructs.
	 */
	public function load() {
		if ( ! function_exists( 'buddypress' ) ) {
			return;
		}

		$path = bpajaxr_helper()->path;

		$files = array(
			'src/core/bpajaxr-functions.php',

			// 'src/core/http/class-bpajaxr-message-bag.php',
			// 'src/core/http/class-bpajaxr-request.php',
			'src/core/registration/class-bpajaxr-registration-validator.php',
			'src/core/registration/class-bpajaxr-account-activator.php',

			'src/core/filters/class-bpajaxr-filters.php',
			'src/core/bpajaxr-handler.php',

			'src/core/handlers/bpajaxr-login-handler.php',
			'src/core/handlers/bpajaxr-registration-handler.php',
			'src/core/handlers/bpajaxr-forget-password-handler.php',
			'src/bootstrap/class-bpajaxr-assets-loader.php',

		);

		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			$files[] = 'src/admin/class-bpajaxr-admin-loader.php';
			$files[] = 'src/admin/class-bpajaxr-admin-settings.php';
		}

		foreach ( $files as $file ) {
			require_once $path . $file;
		}
	}
	/**
	 * Load admin.
	 */
	public function admin_load() {

		if ( ! is_admin() || ! function_exists( 'buddypress' ) ) {
			return;
		}


		$files = array();

		if ( ! defined( 'DOING_AJAX' ) ) {
			$files[] = 'src/admin/pt-settings/pt-settings-loader.php';
		}

		$path = bpajaxr_helper()->path;

		foreach ( $files as $file ) {
			require_once $path . $file;
		}
	}

	/**
	 * Init.
	 */
	public function init() {
		// Make sure BuddyPress is active.
		if ( ! function_exists( 'buddypress' ) ) {
			return;
		}

		if ( ! is_user_logged_in() ) {
			$this->set_test_cookie();
			BPAjaxr_Handler::boot();
			BPAjaxr_Assets_Loader::boot();
		}

		// admin.
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			BPAjaxr_Admin_Loader::boot();
		}
	}

	/**
	 * Load translations.
	 */
	public function load_translations() {
		load_plugin_textdomain( 'bp-ajax-registration', false, basename( dirname( bpajaxr_helper()->path ) ) . '/languages' );
	}

	/**
	 * Set test Cookie(Based on wp-login.php).
	 */
	private function set_test_cookie() {
		// Set a cookie now to see if they are supported by the browser.
		$secure = ( 'https' === wp_parse_url( site_url(), PHP_URL_SCHEME ) );
		setcookie( TEST_COOKIE, 'WP Cookie check', 0, COOKIEPATH, COOKIE_DOMAIN, $secure );
		if ( SITECOOKIEPATH != COOKIEPATH ) {
			setcookie( TEST_COOKIE, 'WP Cookie check', 0, SITECOOKIEPATH, COOKIE_DOMAIN, $secure );
		}
	}
}
