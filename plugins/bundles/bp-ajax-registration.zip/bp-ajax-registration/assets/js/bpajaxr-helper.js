jQuery(function ($) {

    if (typeof BPAjaxRegistration === "undefined") {
        console.log("BP Ajax Registration Not initialized.");
        return;
    }

    /**
     * Config Object.
     */
    /*var BPAjaxRegistration = {
        selectors: {
            login: '.bpajaxr-login-link, #wp-admin-bar-bp-login a',
            registration: '.bpajaxr-signup-link, .bp-signup a, .bp-register-nav a, #login-text a, a.bp-ajaxr, #wp-admin-bar-bp-register a, .bp-login-widget-register-link a, a.vbpregister, a.register-btn, a.register',
            forgetPassword: '.bpajaxr-forget-password-link'
           // resetPassword: '.bpajaxr-reset-password-link'
        }
    }*/

    /**
     * Show Login Form.
     */
    $(document).on('click', BPAjaxRegistration.selectors.login, function () {

        if (!BPAjaxRegistration.loginEnabled) {
            return;
        }

        lightbox.showPanel('login');
        return false;
    });

    /**
     * Show registration form.
     */
    $(document).on('click', BPAjaxRegistration.selectors.registration, function () {
        if (!BPAjaxRegistration.registrationEnabled) {
            return;
        }

        lightbox.showPanel( 'registration' );
        return false;
    });

    /**
     * Show Forge Password form.
     */
    $(document).on('click', BPAjaxRegistration.selectors.forgetPassword, function () {
        if (!BPAjaxRegistration.forgetPasswordEnabled) {
            return;
        }
        lightbox.showPanel('forget-password');
        return false;
    });

    /**
     * Handle form submit.
     */
    $(document).on('submit', '.bpajaxr-panel form', function () {
        var $panel = $(this).parents('.bpajaxr-panel');
        var currentPanel = $panel.data('bpajaxr-panel');
        var $loader = $panel.find('.bpajaxr-loader');
        $loader.show();
        $.post(ajaxurl, $(this).serialize(), function (response) {
            var updatePanel = response.data.update_panel ? response.data.update_panel : '';
            var visiblePanel = response.data.visible_panel ? response.data.visible_panel : '';

            if (updatePanel) {
                lightbox.updatePanel(updatePanel, response.data.contents, false);
            }

            if (visiblePanel && ! updatePanel ) {
                lightbox.showPanel(visiblePanel);
            }

            if (response.success && response.data.redirect) {

                if (response.data.redirect_url) {
                    window.location = response.data.redirect_url;
                } else {
                    window.location.reload();
                }
            }

            $loader.hide();

        }, 'json');

        return false;
    });

    // On Multisite, if blog is checked.
    $(document).on('click', '.bpajaxr-panel #signup_with_blog', function () {

        if ($(this).is(':checked')) {
            $('#blog-details').show()
        } else {
            $('#blog-details').hide();
        }
    });

    // get the magnific popup instance.
    var magnificPopup = jQuery.magnificPopup.instance;
    var $panelsContainer = $('#bpajaxr-panels-container');
    var $panels = $panelsContainer.find("#bpajaxr-panels");

    /**
     * Lightbox Handler.
     */
    var lightbox = {

        /**
         * Add a new panel(contents) to the lightbox. Make sure to follow the panel markup.
         *
         * @param {string} $panel panel content.
         */
        addPanel: function ($panel) {
            $panels.append($panel);
            return this;
        },

        /**
         * Update Panel with the given content.
         *
         * @param panelName
         * @param $content
         * @param isTainted
         */
        updatePanel: function (panelName, $content, isTainted) {
            var tainted = isTainted ? 1 : 0;

            $panels.find('.' + this.getPanelClassName(panelName)).replaceWith($content);
            $panels.find('.' + this.getPanelClassName(panelName)).addClass('bpajaxr-panel-visible').data('panel-tainted', tainted);
            this.showUpdatedContent();
        },

        /**
         * Reload a panel.
         */
        reloadPanel: function (panelName) {
            var self = this;
            loadPanel(panelName).done(function () {
                self.updatePanel(panelName, response.data, false);
            });
        },

        /**
         * Load/reload all panels.
         */
        reloadAllPanels: function (currentPanel) {
            var self = this;
            loadAllPanels().done(function () {
                self.showPanel(currentPanel);
            });
        },

        showPanel: function (panelName) {
            $panels.find('.bpajaxr-panel').removeClass('bpajaxr-panel-visible');
            $panels.find('.bpajaxr-feedback').remove();
            var $panel = $panels.find('.' + this.getPanelClassName(panelName));
            if (!$panel.get(0)) {
                this.close();// if a lightbox is open, close it.
                return;
            }

            $panel.addClass('bpajaxr-panel-visible');
            this.showUpdatedContent();
        },

        /**
         * Open Lightbox.
         */
        openLightbox: function () {
            if (!this.isLoaded()) {
                console.log('BP Ajax Reg: Magnific Popup not loaded.')
                return false;
            }

            var self = this;

            jQuery.magnificPopup.open({
                    items: {
                        src: '#bpajaxr-panels-container',
                        type: 'inline'
                    },

                    closeBtnInside: true,
                    closeOnContentClick: false,
                    closeOnBgClick: false,
                    callbacks: {
                        open: function () {
                            // self.enableCaptcha();
                        }
                    }
                },
                0
            );

        },

        /**
         * Show updated content in the lightbox.
         *
         * @returns {boolean}
         */
        showUpdatedContent: function () {
            if (!this.isLoaded()) {
                console.log('BP Ajax Reg: Magnific Popup not loaded.')
                return false;
            }

            if (!magnificPopup.content) {
                this.openLightbox();
                return true;
            }

            // magnificPopup.currItem.src = content;
            //  magnificPopup.items[magnificPopup.index] = magnificPopup.currItem;
            magnificPopup.updateItemHTML();
            this.hideLoader();
        },

        // enable recaptcha support if needed.
        enableCaptcha: function () {

            if (typeof grecaptcha == 'undefined' || typeof _bpajaxr_recaptcha_config == 'undefined') {
                return;
            }
            grecaptcha.render('bp_ajaxr_ajax_form_validator',
                _bpajaxr_recaptcha_config
            );
        },

        /**
         * Show loader.
         */
        showLoader: function () {
            $panelsContainer.find('.bpajaxr-loader').show();
        },

        /**
         * Hide Loader.
         */
        hideLoader: function () {
            $panelsContainer.find('.bpajaxr-loader').hide();
        },

        /**
         * get the panel css class from the name.
         *
         * @param {string} name
         * @returns {string}
         */
        getPanelClassName: function (name) {
            return 'bpajaxr-panel-' + name;
        },

        /**
         * Is Lightbox Loaded?
         *
         * @returns {boolean}
         */
        isLoaded: function () {
            return $.fn.magnificPopup !== undefined;
        },

        close: function () {
            magnificPopup.close();
        }
    }; // end of lightbox object.


    /**
     * Load all panels.
     */
    function loadAllPanels() {
        return $.post(ajaxurl, {
            action: 'bpajaxr_reload_all_panels'
        }, function (response) {
            if (!response.success) {
                return;
            }

            $panelsContainer.replaceWith(response.data);

            // update references.
            $panelsContainer = $('#bpajaxr-panels-container');
            $panels = $panelsContainer.find("#bpajaxr-panels");

        }, 'json')
    }

    /**
     * Load a Panel.
     *
     * @param panelName
     * @returns {*}
     */
    function loadPanel(panelName) {
        return $.post(ajaxurl, {
            action: 'bpajaxr_reload_panel',
            panel: panelName
        }, function (response) {
            if (!response.success) {
                return;
            }

            $panels.find(lightbox.getPanelClassName(panelName)).replaceWith(response.data);

        }, 'json');
    }

    window.BPAjaxr = lightbox;
});
