<?php
/**
 * Plugin Name: BuddyPress Ajax Registration
 * Version: 2.0.8
 * Plugin URI: https://n3rds.work/plugins/bp-ajax-registration/
 * Author: WMS N@W
 * Author URI: https://n3rds.work
 * License: GPL
 * Description: Einfache und angenehme Registrierung für BuddyPress
 */
require 'src/plugin-update-checker/plugin-update-checker.php';
$MyUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://n3rds.work//wp-update-server/?action=get_metadata&slug=bp-ajax-registration',
	__FILE__, 
	'bp-ajax-registration' 
);

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Helper class
 * loads files and assets
 *
 * @property-read string $url Plugin url.
 * @property-read string $path Plugin path.
 * @property-read string $basename Plugin basename.
 */
class BP_Ajax_Register_Helper {

	/**
	 * Singleton.
	 *
	 * @var $this
	 */
	private static $instance;

	/**
	 * Plugin dir url.
	 *
	 * @var string
	 */
	private $url;

	/**
	 * Plugin dir path.
	 *
	 * @var string
	 */
	private $path;

	/**
	 * Plugin Basename.
	 *
	 * @var string
	 */
	private $basename;

	/**
	 * Success/Error Feedback.
	 *
	 * @var WP_Error
	 */
	private $feedback;

	/**
	 * Request.
	 *
	 * @var BPAjaxr_Request
	 */
	public $request = null;

	/**
	 * Protected properties.
	 *
	 * @var array
	 */
	protected $protected = array( 'protected', 'feedback' );

	/**
	 * BP_Ajax_Register_Helper constructor.
	 */
	private function __construct() {
		$this->url      = plugin_dir_url( __FILE__ );
		$this->path     = plugin_dir_path( __FILE__ );
		$this->basename = plugin_basename( __FILE__ );

		$this->bootstrap();

		$this->feedback = new WP_Error();
		$this->request  = new BPAjaxr_Request( array() );
	}

	/**
	 * Load bootstrapper.
	 */
	private function bootstrap() {
		require_once $this->path . 'src/bootstrap/class-bpajaxr-bootstrapper.php';
		require_once $this->path . 'src/core/http/class-bpajaxr-request.php';
		require_once $this->path . 'src/core/http/class-bpajaxr-message-bag.php';
		BPAjaxr_Bootstrapper::boot();

		register_activation_hook( __FILE__, array( $this, 'activate' ) );
	}

	/**
	 * Get the singleton.
	 *
	 * @return BP_Ajax_Register_Helper
	 */
	public static function instance() {

		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Dynamic Property access.
	 *
	 * @param string $name property name.
	 *
	 * @return Mixed|null
	 */
	public function __get( $name ) {
		return isset( $this->{$name} ) && ! in_array( $name, $this->protected, true ) ? $this->$name : null;
	}

	/**
	 * Add a feedback.
	 *
	 * @param string $messages message.
	 * @param string $type feedback type.
	 */
	public function add_feedback( $messages, $type = 'success' ) {

		$type     = 'success' === $type ? 'success' : 'errors';// ensure the consistency for code.
		$messages = (array) $messages;
		foreach ( $messages as $message ) {
			$this->feedback->add( $type, $message );
		}
	}

	/**
	 * Render Feedback.
	 */
	public function render_feedback() {
		// assuming error and success are mutually exclusive.
		$code = $this->feedback->get_error_code();
		if ( empty( $code ) ) {
			return;
		}

		// $code is either 'success' or 'errors'.
		$all_messages = $this->feedback->get_error_messages( $code );
		echo "<div class='bpajaxr-feedback bpajaxr-feedback-{$code}'>";

		foreach ( $all_messages as $message ) {
			echo '<p>' . $message . '</p>';
		}

		echo '</div>';
	}

	/**
	 * On Activation, save the initial settings.
	 */
	public function activate() {

		if ( is_multisite() && $this->is_network_active() ) {
			$get_callback    = 'get_site_option';
			$update_callback = 'update_site_option';
		} else {
			$get_callback    = 'get_option';
			$update_callback = 'update_option';
		}

		if ( ! $get_callback( 'bpajaxr-settings' ) ) {
			require_once $this->path . 'src/core/bpajaxr-functions.php';
			$update_callback( 'bpajaxr-settings', bpajaxr_get_default_options() );
		}
	}

	/**
	 * Check if Member types pro is network active
	 *
	 * @return bool
	 */
	public function is_network_active() {

		if ( ! is_multisite() ) {
			return false;
		}

		// Check the sitewide plugins array.
		$base    = $this->basename;
		$plugins = get_site_option( 'active_sitewide_plugins' );

		if ( ! is_array( $plugins ) || ! isset( $plugins[ $base ] ) ) {
			return false;
		}

		return true;
	}
}

/**
 * Helper.
 *
 * @return BP_Ajax_Register_Helper
 */
function bpajaxr_helper() {
	return BP_Ajax_Register_Helper::instance();
}

// Init.
bpajaxr_helper();
