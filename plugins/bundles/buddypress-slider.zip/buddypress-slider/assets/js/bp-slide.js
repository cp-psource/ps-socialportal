jQuery(document).ready(function ($) {
    $('.bp-slide').each(function() {
        var $this = $(this);

        var sliderSettings = {
            item: 3,
            mode: 'slide',
            auto: true,
            speed: 400,
            pauseOnHover: true,
            loop: true,
            controls: true,
            pager: true
        };

        var itemSliderSettings = {
            item: $this.data('item') - 0,
            mode: $this.data('mode'),
            speed: $this.data('speed') - 0,
            pauseOnHover: Boolean( $this.data('pause-on-hover') ),
            loop: Boolean( $this.data('loop') ),
            controls: Boolean( $this.data('controls') ),
            pager: Boolean( $this.data('pager') )
        };

        $.extend( sliderSettings, itemSliderSettings );

        $this.lightSlider(sliderSettings);
    });
});