<?php
/**
 * Groups template
 *
 * @package bp-slide
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>

<div class="bp-slide-section">
	<?php if ( bp_has_activities( $args['activity'] ) ) : ?>

		<ul class="bp-slide activity"
		    data-item="<?php echo esc_attr( $args['slider']['item'] ); ?>"
		    data-mode="<?php echo esc_attr( $args['slider']['mode'] ); ?>"
		    data-speed="<?php echo esc_attr( $args['slider']['speed'] ); ?>"
		    data-pause-on-hover="<?php echo esc_attr( $args['slider']['pause-on-hover'] ); ?>"
		    data-loop="<?php echo esc_attr( $args['slider']['loop'] ); ?>"
		    data-controls="<?php echo esc_attr( $args['slider']['controls'] ); ?>"
		    data-pager="<?php echo esc_attr( $args['slider']['pager'] ); ?>"
		>
			<?php while ( bp_activities() ) : bp_the_activity(); ?>
				<li>
                    <div class="bp-slide-item-activity">
                        <div class="bp-slide-item-avatar">
                            <a href="<?php bp_activity_user_link(); ?>"><?php bp_activity_avatar( $args['avatar'] ); ?></a>
                        </div>
                        <div class="bp-slide-activity-content">
                            <div class="bp-slide-activity-header">
			                    <?php bp_activity_action(); ?>
                            </div>
		                    <?php if ( bp_activity_has_content() ) : ?>
                                <div class="activity-inner"><?php bp_activity_content_body(); ?></div>
		                    <?php endif; ?>
                        </div>
                    </div>
				</li>
			<?php endwhile; ?>
		</ul>

	<?php else: ?>

		<div class="bp-slide-info">
			<p><?php _e( "Es wurde leider keine Gruppe gefunden.", 'buddypress-slides' ); ?></p>
		</div>

	<?php endif; ?>
</div>

<?php wp_enqueue_style( 'bp_slide_css' ); ?>
<?php wp_enqueue_script( 'bp_slide_js' ); ?>
