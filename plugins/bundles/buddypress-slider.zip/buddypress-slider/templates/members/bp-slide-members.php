<?php
/**
 * Members template
 *
 * @package bp-slide
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

?>

<div class="bp-slide-section">
	<?php if ( bp_has_members( $args['members'] ) ) : ?>

		<ul class="bp-slide members"
		    data-item="<?php echo esc_attr( $args['slider']['item'] ); ?>"
		    data-mode="<?php echo esc_attr( $args['slider']['mode'] ); ?>"
		    data-speed="<?php echo esc_attr( $args['slider']['speed'] ); ?>"
		    data-pause-on-hover="<?php echo esc_attr( $args['slider']['pause-on-hover'] ); ?>"
		    data-loop="<?php echo esc_attr( $args['slider']['loop'] ); ?>"
		    data-controls="<?php echo esc_attr( $args['slider']['controls'] ); ?>"
		    data-pager="<?php echo esc_attr( $args['slider']['pager'] ); ?>"
		>
			<?php while ( bp_members() ) : bp_the_member(); ?>
				<li>
                    <div class="bp-slide-item-avatar">
                        <a href="<?php bp_member_permalink(); ?>"><?php bp_member_avatar( $args['avatar'] ); ?></a>
                    </div>
                    <div class="bp-slide-item-meta">
                        <a href="<?php bp_member_permalink(); ?>"><?php bp_member_name();?></a>
                    </div>
				</li>
			<?php endwhile; ?>
		</ul>

	<?php else: ?>

		<div class="bp-slide-info">
			<p><?php _e( "Es wurden leider keine Mitglieder gefunden.", 'buddypress-slides' ); ?></p>
		</div>

	<?php endif; ?>
</div>

<?php wp_enqueue_style( 'bp_slide_css' ); ?>
<?php wp_enqueue_script( 'bp_slide_js' ); ?>