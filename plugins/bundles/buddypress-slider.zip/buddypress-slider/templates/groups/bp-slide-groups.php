<?php
/**
 * Groups template
 *
 * @package bp-slide
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

?>

<div class="bp-slide-section">
	<?php if ( bp_has_groups( $args['groups'] ) ) : ?>

        <ul class="bp-slide groups"
            data-item="<?php echo esc_attr( $args['slider']['item'] ); ?>"
            data-mode="<?php echo esc_attr( $args['slider']['mode'] ); ?>"
            data-speed="<?php echo esc_attr( $args['slider']['speed'] ); ?>"
            data-pause-on-hover="<?php echo esc_attr( $args['slider']['pause-on-hover'] ); ?>"
            data-loop="<?php echo esc_attr( $args['slider']['loop'] ); ?>"
            data-controls="<?php echo esc_attr( $args['slider']['controls'] ); ?>"
            data-pager="<?php echo esc_attr( $args['slider']['pager'] ); ?>"
        >
			<?php while ( bp_groups() ) : bp_the_group(); ?>
                <li>
                    <div class="bp-slide-item-avatar">
                        <a href="<?php bp_group_permalink(); ?>" title="<?php echo esc_attr( bp_get_group_name());?>"><?php bp_group_avatar( $args['avatar'] ); ?></a>
                    </div>
                    <div class="bp-slide-item-meta">
						<?php bp_group_name();?>
                    </div>
                </li>
			<?php endwhile; ?>
        </ul>

    <?php else: ?>

		<div class="bp-slide-info">
			<p><?php _e( "Es wurde leider keine Gruppe gefunden.", 'buddypress-slides' ); ?></p>
		</div>

	<?php endif; ?>
</div>

<?php wp_enqueue_style( 'bp_slide_css' ); ?>
<?php wp_enqueue_script( 'bp_slide_js' ); ?>