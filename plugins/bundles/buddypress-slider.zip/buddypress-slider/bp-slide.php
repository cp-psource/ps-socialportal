<?php
/**
 * Plugin Name: BuddyPress Slider
 * Version: 1.0.2
 * Plugin URI: https://n3rds.work/piestingtal_source/ps-socialportal-theme/
 * Description: Dies ist ein Add für BuddyPress, mit dem der Seiten-Administrator Benutzer auflisten und Aktivitäten in Sliderform gruppieren kann.
 * Author: WMS N@W
 * Author URI: https://n3rds.work/
 * Requires PHP: 5.3
 * License:      GPL2
 * License URI:  https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:  bp-slide
 * Domain Path:  /languages
 *
 * @package bp-slide
 **/

use BP_Slide\Bootstrap\Autoloader;
use BP_Slide\Bootstrap\Bootstrapper;

// No direct access over web.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BP_Slide
 *
 * @property-read $path     string Absolute path to the plugin directory.
 * @property-read $url      string Absolute url to the plugin directory.
 * @property-read $basename string Plugin base name.
 * @property-read $version  string Plugin version.
 */
class BP_Slide {

	/**
	 * Plugin Version.
	 *
	 * @var string
	 */
	private $version = '1.0.2';

	/**
	 * Class instance
	 *
	 * @var BP_Slide
	 */
	private static $instance = null;

	/**
	 * Plugin absolute directory path
	 *
	 * @var string
	 */
	private $path;

	/**
	 * Plugin absolute directory url
	 *
	 * @var string
	 */
	private $url;

	/**
	 * Plugin Basename.
	 *
	 * @var string
	 */
	private $basename;

	/**
	 * Protected properties. These properties are inaccessible via magic method.
	 *
	 * @var array
	 */
	private $protected_properties = array( 'instance' );

	/**
	 * BP_Slide constructor.
	 */
	private function __construct() {
		$this->bootstrap();
	}

	/**
	 * Get Singleton Instance
	 *
	 * @return BP_Slide
	 */
	public static function get_instance() {

		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Bootstrap the core.
	 */
	private function bootstrap() {
		$this->path     = plugin_dir_path( __FILE__ );
		$this->url      = plugin_dir_url( __FILE__ );
		$this->basename = plugin_basename( __FILE__ );

		// Load autoloader.
		require_once $this->path . 'src/bootstrap/class-autoloader.php';

		$autoloader = new Autoloader( 'BP_Slide\\', __DIR__ . '/src/' );

		spl_autoload_register( $autoloader );

		// Drop tables on uninstall.
		// register_uninstall_hook( __FILE__, array( 'Schema', 'drop' ) );.

		Bootstrapper::boot();
	}

	/**
	 * On activation create table
	 */
	public function on_activation() {
		// Do things on activation.
	}

	/**
	 * On deactivation. Do cleanup if needed.
	 */
	public function on_deactivation() {
		// do cleanup.
		// delete_option( 'bp_slide_settings' );
	}

	/**
	 * Magic method for accessing property as readonly(It's a lie, references can be updated).
	 *
	 * @param string $name property name.
	 *
	 * @return mixed|null
	 */
	public function __get( $name ) {

		if ( ! in_array( $name, $this->protected_properties, true ) && property_exists( $this, $name ) ) {
			return $this->{$name};
		}

		return null;
	}
}

/**
 * Helper to access singleton instance
 *
 * @return BP_Slide
 */
function bp_slide() {
	return BP_Slide::get_instance();
}

bp_slide();
