<?php
/**
 * Assets Loader
 *
 * @package    BP_Slide
 * @subpackage Bootstrap
 * @copyright  Copyright (c) 2018, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd, Ravi Sharma
 * @since      1.0.0
 */

namespace BP_Slide\Bootstrap;

if ( ! defined( 'ABSPATH' ) ) {
	exit( 0 );
}

/**
 * Assets Loader.
 */
class Assets_Loader {

	/**
	 * Data to be send as localized js.
	 *
	 * @var array
	 */
	private $data = array();

	/**
	 * Boot itself
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Setup
	 */
	public function setup() {
		add_action( 'bp_enqueue_scripts', array( $this, 'load_assets' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'load_admin_assets' ) );
	}

	/**
	 * Load plugin assets
	 */
	public function load_assets() {
		$this->register();
		$this->enqueue();
	}

	/**
	 * Load admin assets.
	 */
	public function load_admin_assets() {
		wp_enqueue_style(
			'bp_slide_admin_css',
			bp_slide()->url . 'assets/css/bp-slide-admin.css',
			false,
			'1.0.0'
		);
	}

	/**
	 * Register assets.
	 */
	public function register() {
		$this->register_vendors();
		$this->register_core();
	}

	/**
	 * Load assets.
	 */
	public function enqueue() {
		//wp_enqueue_style( 'bp_slide_css' );
		//wp_enqueue_script( 'bp_slide_js' );

		//wp_localize_script( 'bp_slide_js', 'BP_Slide', $this->data );
	}

	/**
	 * Register vendor scripts.
	 */
	private function register_vendors() {
		$bp_slide = bp_slide();

		wp_register_style(
			'lightslider-css',
			$bp_slide->url . 'assets/vendors/lightslider/css/lightslider.min.css',
			false,
			'1.1.6'
		);

		wp_register_script(
			'lightslider-js',
			$bp_slide->url . 'assets/vendors/lightslider/js/lightslider.min.js',
			array( 'jquery' ),
			'1.1.6',
			true
		);
	}

	/**
	 * Register core assets.
	 */
	private function register_core() {
		$bp_slide = bp_slide();

		wp_register_style(
			'bp_slide_css',
			$bp_slide->url . 'assets/css/bp-slide.css',
			array( 'lightslider-css' ),
			$bp_slide->version
		);

		wp_register_script(
			'bp_slide_js',
			$bp_slide->url . 'assets/js/bp-slide.js',
			array( 'jquery', 'lightslider-js' ),
			$bp_slide->version,
			true
		);

		$this->data = array();
	}
}
