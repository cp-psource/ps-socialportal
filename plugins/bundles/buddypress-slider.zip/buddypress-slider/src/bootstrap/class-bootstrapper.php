<?php
/**
 * Bootstrapper. Initializes the plugin.
 *
 * @package    BP_Slide
 * @subpackage Bootstrap
 * @copyright  Copyright (c) 2018, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Slide\Bootstrap;

use BP_Slide\Modules\Members\Members_Widget;
use BP_Slide\Modules\Members\Members_Shortcode_Helper;
use BP_Slide\Modules\Groups\Groups_Widget;
use BP_Slide\Modules\Groups\Groups_Shortcode_Helper;
use BP_Slide\Modules\Activity\Activity_Widget;
use BP_Slide\Modules\Activity\Activity_Shortcode_Helper;

// No direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 0 );
}

/**
 * Bootstrapper.
 */
class Bootstrapper {

	/**
	 * Setup the bootstrapper.
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Bind hooks
	 */
	private function setup() {
		add_action( 'bp_loaded', array( $this, 'load' ) );
		add_action( 'bp_widgets_init', array( $this, 'register_widgets' ) );

		//add_action( 'plugins_loaded', array( $this, 'load_admin' ), 9996 ); // pt settings 1.0.4.
		add_action( 'bp_init', array( $this, 'load_translations' ) );
	}

	/**
	 * Load core functions/template tags.
	 * These are non auto loadable constructs.
	 */
	public function load() {
		$path = bp_slide()->path;

		$files = array(
			'src/core/bp-slide-functions.php',
		);

		foreach ( $files as $file ) {
			require_once $path . $file;
		}

		Assets_Loader::boot();
		Members_Shortcode_Helper::boot();

		if ( bp_is_active( 'activity' ) ) {
			Activity_Shortcode_Helper::boot();
		}

		if ( bp_is_active( 'groups' ) ) {
			Groups_Shortcode_Helper::boot();
		}
	}

	/**
	 * Register widgets
	 */
	public function register_widgets() {
		register_widget( Members_Widget::class );

		if ( bp_is_active( 'activity' ) ) {
			register_widget( Activity_Widget::class );
		}

		if ( bp_is_active( 'groups' ) ) {
			register_widget( Groups_Widget::class );
		}
	}

	/**
	 * Load pt-settings framework
	 */
	public function load_admin() {

		if ( function_exists( 'buddypress' ) && is_admin() && ! defined( 'DOING_AJAX' ) ) {
			//require_once bp_slide()->path . 'src/admin/pt-settings/pt-settings-loader.php';
			//Admin_Settings::boot();
		}
	}

	/**
	 * Load translations.
	 */
	public function load_translations() {
		load_plugin_textdomain( 'buddypress-slides', false, basename( dirname( bp_slide()->path ) ) . '/languages' );
	}
}
