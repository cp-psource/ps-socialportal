<?php
/**
 * Helper class for groups shortcode
 *
 * @package bp-slide
 */

namespace BP_Slide\Modules\Groups;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Groups_Shortcode_Helper
 */
class Groups_Shortcode_Helper {

	/**
	 * Boot class
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Setup callbacks
	 */
	private function setup() {
		add_shortcode( 'bp-groups-slider', array( $this, 'render_groups_slider' ) );
	}

	/**
	 * Render groups slider
	 *
	 * @param array $atts shortcode attributes by user.
	 *
	 * @return string
	 */
	public function render_groups_slider( $atts ) {
		$default = array(
			'type'               => 'active',
			'order'              => 'DESC',
			'orderby'            => 'last_activity',
			'max'                => 10,
			'group_type'         => '',
			'group_type__in'     => '',
			'group_type__not_in' => '',
			'avatar_size'        => 80,
			'avatar_type'        => 'thumb',
		);

		$default_slider_settings = bp_slide_get_default_slider_settings();

		$default = array_merge( $default, $default_slider_settings );

		$r = shortcode_atts( $default, $atts );

		$avatar_size = $r['avatar_size'];
		$avatar_type = $r['avatar_type'];
		unset( $r['avatar_size'], $r['avatar_type'] );

		$slider_args = array();
		foreach ( array_keys( $default_slider_settings ) as $key ) {
			$slider_args[ $key ] = $r[ $key ];
			unset( $r[ $key ] );
		}

		$avatar = 'type=' . $avatar_type;
		$avatar .= '&width=' . $avatar_size;

		$template_args = array(
			'groups' => $r,
			'slider'  => $slider_args,
			'avatar'  => $avatar,
		);

		ob_start();

		bp_slide_locate_template( 'groups/bp-slide-groups.php', true, $template_args );

		$content = ob_get_clean();

		return $content;
	}
}

