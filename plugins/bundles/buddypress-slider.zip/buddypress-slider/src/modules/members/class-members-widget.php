<?php
/**
 * Members slider widget
 *
 * @package bp-slide
 */

namespace BP_Slide\Modules\Members;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Members_Widget
 */
class Members_Widget extends \WP_Widget {

	/**
	 * Members_Widget constructor.
	 */
	public function __construct() {
		$widget_ops = array( 'description' => __( 'Eine dynamische Liste der Mitglieder in der Slider-Ansicht', 'buddypress-slides' ) );

		parent::__construct( 'bp_slide_member_widget', _x( 'Buddypress Mitglieder Slider', 'widget name', 'buddypress-slides' ), $widget_ops );
	}

	/**
	 * Render widget content
	 *
	 * @param array $args array.
	 * @param array $instance array.
	 */
	public function widget( $args, $instance ) {
		$default = array(
			'type'                => 'active',
			'max'                 => 10,
			'member_type'         => '',
			'avatar_size'         => 80,
			'avatar_type'         => 'thumb',
		);

		$default_slider_settings = bp_slide_get_default_slider_settings();

		$default = array_merge( $default, $default_slider_settings );

		$r = bp_parse_args( $instance, $default );

		$avatar_size = $r['avatar_size'];
		$avatar_type = $r['avatar_type'];
		unset( $r['avatar_size'], $r['avatar_type'] );

		$slider_args = array();
		foreach ( array_keys( $default_slider_settings ) as $key ) {
			$slider_args[ $key ] = $r[ $key ];
			unset( $r[ $key ] );
		}

		$avatar = 'type=' . $avatar_type;
		$avatar .= '&width=' . $avatar_size;

		unset( $r['title'] );

		$template_args = array(
			'members' => $r,
			'slider'  => $slider_args,
			'avatar'  => $avatar,
		);

		echo $args['before_widget'];

		echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];

		bp_slide_locate_template( 'members/bp-slide-members.php', true, $template_args );

		echo $args['after_widget'];
	}

	/**
	 * Update widget settings
	 *
	 * @param array $new_instance New Instance.
	 * @param array $old_instance Old Instance.
	 *
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {

		$instance = $old_instance;

		$instance['title']          = strip_tags( $new_instance['title'] );
		$instance['type']           = strip_tags( $new_instance['type'] );
		$instance['max']            = absint( $new_instance['max'] );
		$instance['member_type']    = $new_instance['member_type'];
		$instance['avatar_size']    = absint( $new_instance['avatar_size'] );
		$instance['avatar_type']    = strip_tags( $new_instance['avatar_type'] );
		$instance['item']           = absint( $new_instance['item'] );
		$instance['mode']           = $new_instance['mode'];
		$instance['pause-on-hover'] = isset( $new_instance['pause-on-hover'] ) ? 1 : 0;
		$instance['loop']           = isset( $new_instance['loop'] ) ? 1 : 0;
		$instance['controls']       = isset( $new_instance['controls'] ) ? 1 : 0;
		$instance['pager']          = isset( $new_instance['pager'] ) ? 1 : 0;

		return $instance;
	}

	/**
	 * Form setting
	 *
	 * @param array $instance Instance.
	 *
	 * @return string
	 */
	public function form( $instance ) {

		$defaults = array(
			'title'          => __( 'Mitglieder Slider', 'buddypress-slides' ),
			'type'           => 'active',
			'max'            => 10,
			'member_type'    => '',
			'avatar_size'    => 80,
			'avatar_type'    => 'thumb',
			'item'           => 3,
			'mode'           => 'slide',
			'pause-on-hover' => 1,
			'loop'           => 1,
			'controls'       => 1,
			'pager'          => 1,
		);

		$instance = bp_parse_args( $instance, $defaults );

		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Titel:','buddypress-slides' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'type' ); ?>"><?php _e( 'Typ:', 'buddypress-slides' ); ?></label>
			<select name="<?php echo $this->get_field_name( 'type' ); ?>" id="<?php echo $this->get_field_id( 'type' ); ?>" class="widefat">
				<?php foreach ( bp_slide_members_get_available_types() as $type => $label ) : ?>
					<option value="<?php echo esc_attr( $type ); ?>" <?php selected( $instance['type'], $type ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			 </select><br>
			 <span class="bp-slide-description"><?php _e( 'Typ des abzurufenden Benutzers', 'buddypress-slides' ); ?></span>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'max' ); ?>"><?php _e( 'Max Limit:', 'buddypress-slides' ); ?></label>
			<input class="widecolumn" id="<?php echo $this->get_field_id( 'max' ); ?>" name="<?php echo $this->get_field_name( 'max' ); ?>" type="number" value="<?php echo esc_attr( $instance['max'] ); ?>"/><br>
			<span class="bp-slide-description"><?php _e( 'Wie viele Mitglieder sollen angezeigt werden?', 'buddypress-slides' ); ?></span>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'member_type' ); ?>">
				<?php _e( 'Member type:', 'buddypress-slides' ); ?>
			</label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'member_type' ); ?>" name="<?php echo $this->get_field_name( 'member_type' ); ?>" type="text" value="<?php echo esc_attr( $instance['member_type'] ); ?>"/>
			<span class="bp-slide-description"><?php _e( 'durch Kommas getrennte Elementtypen. z.B. Schüler, Lehrer', 'buddypress-slides' ); ?></span>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'avatar_size' ); ?>">
				<?php _e( 'Avatar Größe:', 'buddypress-slides' ); ?>
			</label>
			<input id="<?php echo $this->get_field_id( 'avatar_size' ); ?>" name="<?php echo $this->get_field_name( 'avatar_size' ); ?>" type="number" value="<?php echo esc_attr( $instance['avatar_size'] ); ?>"/>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'avatar_type' ); ?>">
				<?php _e( 'Avatar-Typ:', 'buddypress-slides' ); ?>
			</label>
			<select name="<?php echo $this->get_field_name('avatar_type'); ?>">
                <option value="full" <?php selected( $instance['avatar_type'], 'active' ); ?>><?php _e( 'Voll', 'buddypress-slides' ); ?></option>
                <option value="thumb" <?php selected( $instance['avatar_type'], 'random' ); ?>><?php _e( 'Thumb', 'buddypress-slides' ); ?></option>
            </select>
		</p>
		<p><?php _e( '----Slider Optionen----', 'buddypress-slides' ); ?></p>
		<p>
			<label for="<?php echo $this->get_field_id( 'item' ); ?>"><?php _e( 'Artikel:', 'buddypress-slides' ); ?></label>
			<input id="<?php echo $this->get_field_id( 'item' ); ?>" name="<?php echo $this->get_field_name( 'item' ); ?>" type="number" value="<?php echo esc_attr( $instance['item'] ); ?>"/>
			<span class="bp-slide-description"><?php _e( 'Anzahl der Folien, die gleichzeitig angezeigt werden sollen', 'buddypress-slides' ); ?></span>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'mode' ); ?>"><?php _e( 'Modus: ', 'buddypress-slides' ); ?></label>
			<select name="<?php echo $this->get_field_name('mode'); ?>">
				<option value="slide" <?php selected( $instance['mode'], 'slide' ); ?>><?php _e( 'Slide', 'buddypress-slides' ); ?></option>
				<option value="fade" <?php selected( $instance['mode'], 'fade' ); ?>><?php _e( 'Fade', 'buddypress-slides' ); ?></option>
			</select>
		</p>

		<p>
			<input type="checkbox" name="<?php echo $this->get_field_name('pause-on-hover'); ?>" id="<?php echo $this->get_field_id( 'pause-on-hover' ); ?>" value="1" <?php checked( $instance['pause-on-hover'], 1 ); ?>>
			<label for="<?php echo $this->get_field_id( 'pause-on-hover' ); ?>"><?php _e( 'Pause bei Hover:', 'buddypress-slides' ); ?></label><br>
			<span class="bp-slide-description"><?php _e( 'PUnterbreche die automatische Wiedergabe bei Hover.', 'buddypress-slides' ); ?></span>
		</p>

		<p>
			<input type="checkbox" name="<?php echo $this->get_field_name('loop'); ?>" id="<?php echo $this->get_field_id( 'loop' ); ?>" value="1" <?php checked( $instance['loop'], 1 ); ?>>
			<label for="<?php echo $this->get_field_id( 'loop' ); ?>"><?php _e( 'Loop:', 'buddypress-slides' ); ?></label><br>
			<span class="bp-slide-description"><?php _e( 'Nach der letzten Folie automatisch zur ersten Folie wechseln', 'buddypress-slides' ); ?></span>
		</p>

		<p>
			<input type="checkbox" name="<?php echo $this->get_field_name('controls'); ?>" id="<?php echo $this->get_field_id( 'controls' ); ?>" value="1" <?php checked( $instance['controls'], 1 ); ?>>
			<label for="<?php echo $this->get_field_id( 'controls' ); ?>"><?php _e( 'Kontrollen:', 'buddypress-slides' ); ?></label><br>
			<span class="bp-slide-description"><?php _e( 'Wenn aktiviert, zeige die Schaltflächen Zurück/Weiter an.', 'buddypress-slides' ); ?></span>
		</p>

		<p>
			<input type="checkbox" name="<?php echo $this->get_field_name('pager'); ?>" id="<?php echo $this->get_field_id( 'pager' ); ?>" value="1" <?php checked( $instance['pager'], 1 ); ?>>
			<label for="<?php echo $this->get_field_id( 'pager' ); ?>"><?php _e( 'Pager', 'buddypress-slides' ); ?></label><br>
			<span class="bp-slide-description"><?php _e( 'Wenn aktiviert, Punkte unter Schieberegler anzeigen, um durch den Schieberegler zu navigieren.', 'buddypress-slides' ); ?></span>
		</p>
		<?php
	}
}