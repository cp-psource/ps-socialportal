<?php
/**
 * Helper class for members shortcode
 *
 * @package BP_Slide
 * @subpackage Modules
 */

namespace BP_Slide\Modules\Members;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Members_Shortcode_Helper
 */
class Members_Shortcode_Helper {

	/**
	 * Boot class
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Add shortcode for members
	 */
	public function setup() {
		add_shortcode( 'bp-members-slider', array( $this, 'render_members_slider' ) );
	}

	/**
	 * Render members sliders
	 *
	 * @param array $atts shortcode attributes.
	 *
	 * @return string
	 */
	public function render_members_slider( $atts ) {
		$default = array(
			'type'                => 'active',
			'max'                 => 10,
			'include'             => false,
			'exclude'             => false,
			'member_type'         => '',
			'member_type__in'     => '',
			'member_type__not_in' => '',
			'avatar_size'         => 80,
			'avatar_type'         => 'thumb',
		);

		$default_slider_settings = bp_slide_get_default_slider_settings();

		$default = array_merge( $default, $default_slider_settings );

		$r = shortcode_atts( $default, $atts );

		$avatar_size = $r['avatar_size'];
		$avatar_type = $r['avatar_type'];
		unset( $r['avatar_size'], $r['avatar_type'] );

		$slider_args = array();
		foreach ( array_keys( $default_slider_settings ) as $key ) {
			$slider_args[ $key ] = $r[ $key ];
			unset( $r[ $key ] );
		}

		$avatar = 'type=' . $avatar_type;
		$avatar .= '&width=' . $avatar_size;

		$template_args = array(
			'members' => $r,
			'slider'  => $slider_args,
			'avatar'  => $avatar,
		);

		ob_start();

		bp_slide_locate_template( 'members/bp-slide-members.php', true, $template_args );

		$content = ob_get_clean();

		return $content;
	}
}