<?php
/**
 * Plugin shortcode helper class
 *
 * @package bp-activity-slider
 */

namespace BP_Slide\Modules\Activity;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Activity_Shortcode_Helper
 */
class Activity_Shortcode_Helper {

	/**
	 * Boot class
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Callbacks
	 */
	private function setup() {
		add_shortcode( 'bp-activity-slider', array( $this, 'render_content' ) );
	}

	/**
	 * Render content
	 *
	 * @param array $atts supplied parameters.
	 *
	 * @return string
	 */
	public function render_content( $atts ) {
		$default_atts = array(
			'scope'       => 'all',
			'object'      => 'all',
			'max'         => 5,
			'avatar_type' => 'thumb',
		);

		$default_slider_settings = bp_slide_get_default_slider_settings();

		$default_atts = array_merge( $default_atts, $default_slider_settings );

		$r = shortcode_atts(
			$default_atts,
			$atts,
			'bp-activity-slider'
		);

		$avatar_type = $r['avatar_type'];
		unset( $r['avatar_type'] );

		if ( 'all' == $r['object'] ) {
			unset( $r['object'] );
		}

		if ( 'all' == $r['scope'] ) {
			unset( $r['scope'] );
		}

		$slider_args = array();
		foreach ( array_keys( $default_slider_settings ) as $key ) {
			$slider_args[ $key ] = $r[ $key ];
			unset( $r[ $key ] );
		}

		$avatar = 'type=' . $avatar_type;

		$template_args = array(
			'activity' => $r,
			'slider'  => $slider_args,
			'avatar'  => $avatar,
		);

		ob_start();

		bp_slide_locate_template( 'activity/bp-slide-activity.php', true, $template_args );

		return ob_get_clean();
	}
}