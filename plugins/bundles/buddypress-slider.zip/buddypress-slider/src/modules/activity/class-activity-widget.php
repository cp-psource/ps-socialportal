<?php
/**
 * Activity slider widget
 *
 * @package bp-activity-slider
 */

namespace BP_Slide\Modules\Activity;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Activity_Widget
 */
class Activity_Widget extends \WP_Widget {

	/**
	 * BP_Activity_Slider_Widget constructor.
	 */
	public function __construct() {
		$widget_ops = array( 'description' => __( 'Slider-Ansicht der Aktivitäten', 'bp-activity-slider' ) );

		parent::__construct( 'bp_slide_activity_widget', _x( 'BuddyPress-Aktivitätsslider', 'Widget Name', 'bp-activity-slider' ), $widget_ops );

	}

	/**
	 * Render widget
	 *
	 * @param array $args array.
	 * @param array $instance Instance.
	 */
	public function widget( $args, $instance ) {
		$default = array(
			'scope'       => 'all',
			'object'      => 'all',
			'max'         => 5,
			'avatar_type' => 'thumb',
		);

		$default_slider_settings = bp_slide_get_default_slider_settings();

		$default = array_merge( $default, $default_slider_settings );

		$r = bp_parse_args( $instance, $default );

		$avatar_type = $r['avatar_type'];
		unset( $r['avatar_type'] );

		$slider_args = array();
		foreach ( array_keys( $default_slider_settings ) as $key ) {
			$slider_args[ $key ] = $r[ $key ];
			unset( $r[ $key ] );
		}

		$avatar = 'type=' . $avatar_type;

        if ( $r['object'] == 'all' ) {
            unset( $r['object'] );
        }

        if ( $r['scope'] == 'all' ) {
	        unset( $r['scope'] );
        }

		unset( $r['title'] );

		$template_args = array(
			'activity' => $r,
			'slider'   => $slider_args,
			'avatar'   => $avatar,
		);

		echo $args['before_widget'];

		echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];

		bp_slide_locate_template( 'activity/bp-slide-activity.php', true, $template_args );

		echo $args['after_widget'];
	}

	/**
	 * Update widget settings
	 *
	 * @param array $new_instance New instance.
	 * @param array $old_instance Old instance.
	 *
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['title']          = strip_tags( $new_instance['title'] );
		$instance['scope']          = strip_tags( $new_instance['scope'] );
		$instance['object']         = strip_tags( $new_instance['object'] );
		$instance['max']            = strip_tags( $new_instance['max'] );
		$instance['avatar_type']    = strip_tags( $new_instance['avatar_type'] );
		$instance['item']           = absint( $new_instance['item'] );
		$instance['mode']           = $new_instance['mode'];
		$instance['pause-on-hover'] = isset( $new_instance['pause-on-hover'] ) ? 1 : 0;
		$instance['loop']           = isset( $new_instance['loop'] ) ? 1 : 0;
		$instance['controls']       = isset( $new_instance['controls'] ) ? 1 : 0;
		$instance['pager']          = isset( $new_instance['pager'] ) ? 1 : 0;

		return $instance;
	}

	/**
	 * Render widget form
	 *
	 * @param array $instance Instance.
	 */
	public function form( $instance ) {
	    $defaults = array(
			'title'          => __( 'Aktivitätsslider', 'bp-activity-slider' ),
			'scope'          => 'all',
			'object'         => 'all',
			'max'            => 10,
			'avatar_type'    => 'thumb',
			'item'           => 3,
			'mode'           => 'slide',
			'pause-on-hover' => 1,
			'loop'           => 1,
			'controls'       => true,
			'pager'          => 1,
		);

		$instance = bp_parse_args( $instance, $defaults );

		?>
        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Titel:', 'bp-activity-slider' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>"
                   name="<?php echo $this->get_field_name( 'title' ); ?>" type="text"
                   value="<?php echo esc_attr( $instance['title'] ); ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'object' ); ?>"><?php _e( 'Aktivitäten anzeigen von:', 'bp-activity-slider' ); ?></label>
            <select name="<?php echo $this->get_field_name( 'object' ) ?>"
                    id="<?php echo $this->get_field_id( 'object' ); ?>">
                <option value="all" <?php selected( 'all', $instance['object'], true ) ?>>
		            <?php _e( 'Alle', 'bp-activity-slider' ) ?>
                </option>
                <option value="members" <?php selected( 'members', $instance['object'], true ) ?>>
					<?php _e( 'Mitglieder', 'bp-activity-slider' ) ?>
                </option>
                <option value="groups" <?php selected( 'groups', $instance['object'], true ) ?>>
					<?php _e( 'Gruppen', 'bp-activity-slider' ) ?>
                </option>
            </select>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'scope' ); ?>"><?php _e( 'Umfang:', 'bp-activity-slider' ); ?></label>
            <select name="<?php echo $this->get_field_name( 'scope' ) ?>"
                    id="<?php echo $this->get_field_id( 'object' ); ?>">
	            <?php foreach ( bp_slide_activity_get_available_scopes() as $scope => $label ) : ?>
                    <option value="<?php echo esc_attr( $scope ); ?>" <?php selected( $instance['scope'], $scope ); ?>><?php echo esc_html( $label ); ?></option>
                <?php endforeach; ?>
            </select>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'max' ); ?>"><?php _e( 'Max Limit:', 'buddypress-slides' ); ?></label>
            <input id="<?php echo $this->get_field_id( 'max' ); ?>"
                   name="<?php echo $this->get_field_name( 'max' ); ?>" type="text"
                   value="<?php echo esc_attr( $instance['max'] ); ?>"/><br>
            <span class="bp-slide-description"><?php _e( 'Wie viele Aktivitäten müssen abgerufen werden?.', 'buddypress-slides' ); ?></span>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'avatar_type' ); ?>"><?php _e( 'Avatar-Typ:', 'bp-activity-slider' ); ?></label>
            <select name="<?php echo $this->get_field_name( 'avatar_type' ); ?>">
                <option value="full" <?php selected( $instance['avatar_type'], 'full' ); ?>><?php _e( 'Voll', 'bp-activity-slider' ); ?></option>
                <option value="thumb" <?php selected( $instance['avatar_type'], 'thumb' ); ?>><?php _e( 'Thumb', 'bp-activity-slider' ); ?></option>
            </select>
        </p>

        <p><?php _e( '----Slider Options----', 'buddypress-slides' ); ?></p>

        <p>
            <label for="<?php echo $this->get_field_id( 'item' ); ?>"><?php _e( 'Artikel:', 'buddypress-slides' ); ?></label>
            <input id="<?php echo $this->get_field_id( 'item' ); ?>" name="<?php echo $this->get_field_name( 'item' ); ?>" type="number" value="<?php echo esc_attr( $instance['item'] ); ?>"/>
            <span class="bp-slide-description"><?php _e( 'Anzahl der Folien, die gleichzeitig angezeigt werden sollen', 'buddypress-slides' ); ?></span>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'mode' ); ?>">
				<?php _e( 'Modus:', 'buddypress-slides' ); ?>
            </label>
            <select name="<?php echo $this->get_field_name('mode'); ?>">
                <option value="slide" <?php selected( $instance['mode'], 'slide' ); ?>><?php _e( 'Slide', 'buddypress-slides' ); ?></option>
                <option value="fade" <?php selected( $instance['mode'], 'fade' ); ?>><?php _e( 'Fade', 'buddypress-slides' ); ?></option>
            </select>
        </p>

        <p>
            <input type="checkbox" name="<?php echo $this->get_field_name('pause-on-hover'); ?>" id="<?php echo $this->get_field_id( 'pause-on-hover' ); ?>" value="1" <?php checked( $instance['pause-on-hover'], 1 ); ?>>
            <label for="<?php echo $this->get_field_id( 'pause-on-hover' ); ?>"><?php _e( 'Pause bei Hover:', 'buddypress-slides' ); ?></label><br>
            <span class="bp-slide-description"><?php _e( 'Unterbreche die automatische Wiedergabe beim Hover.', 'buddypress-slides' ); ?></span>
        </p>

        <p>
            <input type="checkbox" name="<?php echo $this->get_field_name('loop'); ?>" id="<?php echo $this->get_field_id( 'loop' ); ?>" value="1" <?php checked( $instance['loop'], 1 ); ?>>
            <label for="<?php echo $this->get_field_id( 'loop' ); ?>"><?php _e( 'Loop:', 'buddypress-slides' ); ?></label><br>
            <span class="bp-slide-description"><?php _e( 'Nach der letzten Folie automatisch zur ersten Folie wechseln', 'buddypress-slides' ); ?></span>
        </p>

        <p>
            <input type="checkbox" name="<?php echo $this->get_field_name('controls'); ?>" id="<?php echo $this->get_field_id( 'controls' ); ?>" value="1" <?php checked( $instance['controls'], 1 ); ?>>
            <label for="<?php echo $this->get_field_id( 'controls' ); ?>"><?php _e( 'Kontrollen:', 'buddypress-slides' ); ?></label><br>
            <span class="bp-slide-description"><?php _e( 'Wenn aktiviert, zeige die Schaltflächen Zurück / Weiter an.', 'buddypress-slides' ); ?></span>
        </p>

        <p>
            <input type="checkbox" name="<?php echo $this->get_field_name('pager'); ?>" id="<?php echo $this->get_field_id( 'pager' ); ?>" value="1" <?php checked( $instance['pager'], 1 ); ?>>
            <label for="<?php echo $this->get_field_id( 'pager' ); ?>"><?php _e( 'Pager:', 'buddypress-slides' ); ?></label><br>
            <span class="bp-slide-description"><?php _e( 'Wenn aktiviert, Punkte unter Schieberegler anzeigen, um durch den Schieberegler zu navigieren.', 'buddypress-slides' ); ?></span>
        </p>
		<?php
	}
}