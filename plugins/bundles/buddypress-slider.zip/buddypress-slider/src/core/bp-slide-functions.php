<?php
/**
 * Core functions file
 *
 * @package BP_Slide
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get default slider settings
 *
 * @return array
 */
function bp_slide_get_default_slider_settings() {
	return array(
		'item'           => 3,
		'mode'           => 'slide',
		'speed'          => 400,
		'pause-on-hover' => true,
		'loop'           => true,
		'controls'       => true,
		'pager'          => true,
	);
}

/**
 * Locate or load a file from theme or fallback to plugin.
 *
 * @param string $template template name.
 * @param bool  $load load template?.
 * @param array $args Template args.
 *
 * @return string
 */
function bp_slide_locate_template( $template, $load = false, $args = array() ) {
	$located = locate_template( 'bp-slide/' . $template, false, false );

	if ( ! is_readable( $located ) ) {
		$located = bp_slide()->path . 'templates/' . $template;
	}

	if ( ! $load ) {
		return $located;
	}

	require $located;
}

/**
 * Get member available types
 *
 * @see bp_has_members()
 *
 * @return array
 */
function bp_slide_members_get_available_types() {
	$types = array(
		'active'       => __( 'Aktive', 'buddypress-slides' ),
		'random'       => __( 'Zufällig', 'buddypress-slides' ),
		'newest'       => __( 'Neueste', 'buddypress-slides' ),
		'popular'      => __( 'Populär', 'buddypress-slides' ),
		'online'       => __( 'Online', 'buddypress-slides' ),
		'alphabetical' => __( 'Alphabetisch', 'buddypress-slides' ),
	);

	return $types;
}

/**
 * Get group available types
 *
 * @see bp_has_groups()
 *
 * @return array
 */
function bp_slide_groups_get_available_types() {
	$types = array(
		'active'       => __( 'Aktive', 'buddypress-slides' ),
		'popular'      => __( 'Populär', 'buddypress-slides' ),
		'alphabetical' => __( 'Alphabetisch', 'buddypress-slides' ),
		'newest'       => __( 'Neueste', 'buddypress-slides' ),
		'random'       => __( 'Zufällig', 'buddypress-slides' ),
	);

	return $types;
}

/**
 * Get group available types
 *
 * @see bp_has_groups()
 *
 * @return array
 */
function bp_slide_groups_get_available_orderby_options() {
	$types = array(
		'date_created'       => __( 'Datum erstellt', 'buddypress-slides' ),
		'last_activity'      => __( 'Letzte Aktivität', 'buddypress-slides' ),
		'total_member_count' => __( 'Mitgliederanzahl', 'buddypress-slides' ),
		'name'               => __( 'Name', 'buddypress-slides' ),
		'random'             => __( 'Zufällig', 'buddypress-slides' ),
	);

	return $types;
}

/**
 * Get group available types
 *
 * @see bp_has_activities()
 *
 * @return array
 */
function bp_slide_activity_get_available_scopes() {
	$scopes = array(
		'all'       => __( 'Alle', 'buddypress-slides' ),
		'just-me'   => __( 'Nur mich', 'buddypress-slides' ),
		'friends'   => __( 'Freunde', 'buddypress-slides' ),
		'groups'    => __( 'Gruppen', 'buddypress-slides' ),
		'favorites' => __( 'Favoriten', 'buddypress-slides' ),
		'mentions'  => __( 'Erwähnungen', 'buddypress-slides' ),
	);

	return $scopes;
}

