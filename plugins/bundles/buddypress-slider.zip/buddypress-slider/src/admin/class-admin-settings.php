<?php
/**
 * Admin Settings Pages Helper.
 *
 * @package    BP_Slide
 * @subpackage Admin
 * @copyright  Copyright (c) 2018, WMS N@W
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Slide\Admin;

use \Press_Themes\PT_Settings\Page;

// Exit if file accessed directly over web.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Admin_Settings
 */
class Admin_Settings {

	/**
	 * Admin Menu slug
	 *
	 * @var string
	 */
	private $menu_slug;

	/**
	 * Used to keep a reference of the Page, It will be used in rendering the view.
	 *
	 * @var \Press_Themes\PT_Settings\Page
	 */
	private $page;

	/**
	 * Boot settings
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Setup settings
	 */
	public function setup() {

		$this->menu_slug = 'bp_slide';

		add_action( 'admin_init', array( $this, 'init' ) );
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
	}

	/**
	 * Show/render the setting page
	 */
	public function render() {
		$this->page->render();
	}

	/**
	 * Is it the setting page?
	 *
	 * @return bool
	 */
	private function needs_loading() {

		global $pagenow;

		// We need to load on options.php otherwise settings won't be reistered.
		if ( 'options.php' === $pagenow ) {
			return true;
		}

		if ( isset( $_GET['page'] ) && $_GET['page'] === $this->menu_slug ) {
			return true;
		}

		return false;
	}

	/**
	 * Initialize the admin settings panel and fields
	 */
	public function init() {

		if ( ! $this->needs_loading() ) {
			return;
		}

		$page = new Page( 'bp_slide_settings', __( 'BP_Slide', 'buddypress-slides' ) );

		// General settings tab.
		$general = $page->add_panel( 'general', _x( 'Allgemeines', 'Titel des Admin-Einstellungsfelds', 'buddypress-slides' ) );

		$section_general = $general->add_section( 'settings', _x( 'Allgemeine Einstellungen', 'Titel des Abschnitts Admin-Einstellungen', 'buddypress-slides' ) );

		$defaults = bp_slide_get_default_options();

		$fields = array(
			array(
				'name'    => 'slug',
				'label'   => _x( 'Slug', 'Admin-Einstellungen', 'buddypress-slides' ),
				'type'    => 'text',
				'default' => $defaults['slug'],
			),
		);

		$section_general->add_fields( $fields );

		do_action( 'bp_slide_admin_settings_page', $page );

		$this->page = $page;

		// allow enabling options.
		$page->init();
	}

	/**
	 * Add Menu
	 */
	public function add_menu() {

		add_options_page(
			_x( 'BP_Slide', 'Seitentitel der Admin-Einstellungen', 'buddypress-slides' ),
			_x( 'BP_Slide', 'Menübezeichnung für die Admin-Einstellungen', 'buddypress-slides' ),
			'manage_options',
			$this->menu_slug,
			array( $this, 'render' )
		);
	}

	/**
	 * Get roles
	 *
	 * @return array
	 */
	private function get_roles() {
		$roles = get_editable_roles();

		$user_roles = array(
			'all' => __( 'Alle Mitglieder', 'buddypress-slides' ),
		);

		foreach ( $roles as $role => $detail ) {
			$user_roles[ $role ] = $detail['name'];
		}

		return $user_roles;
	}
}
