@package pt-settings
@version 1.0.3

PT Settings is the internal settings framework developed by WMS N@W/PressThemes team.