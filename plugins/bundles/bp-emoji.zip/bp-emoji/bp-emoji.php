<?php
/**
 * Plugin Name: BuddyPress Emoji
 * Version: 1.0.2
 * Plugin URI: https://n3rds.work/piestingtal_source/ps-socialportal-theme/
 * Description: Buddy Emoji ist ein Addon für BuddyPress. Es ermöglicht Seiten-Benutzern, Emoji in BuddyPress-Aktivitäten und Aktivitätskommentaren zu veröffentlichen.
 * Author: WMS N@W
 * Author URI: https://n3rds.work/
 * Requires PHP: 5.3
 * License:      GPL2
 * License URI:  https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:  bp-emoji
 * Domain Path:  /languages
 *
 * @package bp-emoji
 **/

use BP_Emoji\Bootstrap\Autoloader;
use BP_Emoji\Bootstrap\Bootstrapper;

// No direct access over web.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BP_Emoji
 *
 * @property-read $path     string Absolute path to the plugin directory.
 * @property-read $url      string Absolute url to the plugin directory.
 * @property-read $basename string Plugin base name.
 * @property-read $version  string Plugin version.
 */
class BP_Emoji {

	/**
	 * Plugin Version.
	 *
	 * @var string
	 */
	private $version = '1.0.1';

	/**
	 * Class instance
	 *
	 * @var BP_Emoji
	 */
	private static $instance = null;

	/**
	 * Plugin absolute directory path
	 *
	 * @var string
	 */
	private $path;

	/**
	 * Plugin absolute directory url
	 *
	 * @var string
	 */
	private $url;

	/**
	 * Plugin Basename.
	 *
	 * @var string
	 */
	private $basename;

	/**
	 * Protected properties. These properties are inaccessible via magic method.
	 *
	 * @var array
	 */
	private $secure_properties = array( 'instance' );

	/**
	 * BP_Emoji constructor.
	 */
	private function __construct() {
		$this->bootstrap();
	}

	/**
	 * Get Singleton Instance
	 *
	 * @return BP_Emoji
	 */
	public static function get_instance() {

		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Bootstrap the core.
	 */
	private function bootstrap() {
		$this->path     = plugin_dir_path( __FILE__ );
		$this->url      = plugin_dir_url( __FILE__ );
		$this->basename = plugin_basename( __FILE__ );

		// Load autoloader.
		require_once $this->path . 'src/bootstrap/class-autoloader.php';

		$autoloader = new Autoloader( 'BP_Emoji\\', __DIR__ . '/src/' );

		spl_autoload_register( $autoloader );

		register_activation_hook( __FILE__, array( $this, 'on_activation' ) );
		register_deactivation_hook( __FILE__, array( $this, 'on_deactivation' ) );

		// Drop tables on uninstall.
		// register_uninstall_hook( __FILE__, array( 'Schema', 'drop' ) );.

		Bootstrapper::boot();
	}

	/**
	 * On activation create table
	 */
	public function on_activation() {

		if ( ! get_option( 'bp-empji-settings' ) ) {
			require_once $this->path . 'src/core/bp-emoji-functions.php';
			update_option( 'bp-empji-settings', bp_skeleton_get_default_options() );
		}
	}


	/**
	 * On deactivation. Do cleanup if needed.
	 */
	public function on_deactivation() {
		// do cleanup.
		// delete_option( 'bp_emoji_settings' );
	}

	/**
	 * Magic method for accessing property as readonly(It's a lie, references can be updated).
	 *
	 * @param string $name property name.
	 *
	 * @return mixed|null
	 */
	public function __get( $name ) {

		if ( ! in_array( $name, $this->secure_properties, true ) && property_exists( $this, $name ) ) {
			return $this->{$name};
		}

		return null;
	}
}

/**
 * Helper to access singleton instance
 *
 * @return BP_Emoji
 */
function bp_emoji() {
	return BP_Emoji::get_instance();
}

bp_emoji();
