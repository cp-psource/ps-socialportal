(function ($) {
    // Change images.
    var emojione = window.emojione;
    emojione.imagePathPNG = typeof _wpemojiSettings !== 'undefined' ? _wpemojiSettings.baseUrl : 'https://s.w.org/images/core/emoji/12.0.0-1/72x72/';
    emojione.imagePathSVG = typeof _wpemojiSettings !== 'undefined' ? _wpemojiSettings.svgUrl : 'https://s.w.org/images/core/emoji/12.0.0-1/svg/';

    var placeCaretAtEnd = createCaretPlacer(false);

    $(document).ready(function () {

        // for activity post.
        $('#whats-new').emojioneArea({
            standalone: true,
            hideSource: false,
            container: '#bp-activity-post-options .bp-emoji-action',
            autocomplete: false,
            pickerPosition: 'bottom',
            useInternalCDN: false,
            events: {
                'picker.show': function (picker) {
                    placeCaretAtEnd($('#whats-new'));
                }
            }
        });

        // hide on blur.
        $(document).on('focusout', '#whats-new', function (e) {
            var picker = $(this)[0].emojioneArea.hidePicker();
            if ('undefined' !== picker) {
                picker.hidePicker();
            }
        });

        // Activity comments
        $(document).on('activity:reply:form:visible', function (evt, $ac, activity_id) {
            var $input =$('#ac-input-' + activity_id);
            if ('undefined' !== typeof $input.data('emojioneArea')) {
                return;
            }
            $input.emojioneArea({
                standalone: true,
                hideSource: false,
                container: '#bp-ac-comment-options-emoji-action-' + activity_id,
                autocomplete: false,
                pickerPosition: 'bottom',
                hidePickerOnBlur: true,
                useInternalCDN: false,
                events: {
                    'picker.show': function (picker) {
                        placeCaretAtEnd( $ac.find('.ac-input'));
                    }
                }
            });
        });

        // comment focus out.
        $(document).on('focusout', '.ac-input', function (e) {
            var picker = $(this)[0].emojioneArea.hidePicker();
            if ('undefined' !== picker) {
                picker.hidePicker();
            }
        });
    });

    // Utils.
    // Credit: http://stackoverflow.com/a/4238971/96100
    function createCaretPlacer(atStart) {
        return function ($el) {
            if ($el.is(':focus')) {
                return;// already focused, do not change.
            } else {
                $el.focus();
            }

            var el = $el[0];
            if (typeof window.getSelection !== 'undefined' && typeof document.createRange !== 'undefined') {
                var range = document.createRange();
                range.selectNodeContents(el);
                range.collapse(atStart);
                var sel = window.getSelection();
                sel.removeAllRanges();
                sel.addRange(range);
            } else if (typeof document.body.createTextRange !== 'undefined') {
                var textRange = document.body.createTextRange();
                textRange.moveToElementText(el);
                textRange.collapse(atStart);
                textRange.select();
            }
        };
    }
})(jQuery);