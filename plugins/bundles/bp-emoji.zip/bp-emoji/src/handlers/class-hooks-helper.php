<?php
/**
 * Hooks helper class
 *
 * @package BP_Emoji
 * @subpackage Handlers
 */

namespace BP_Emoji\Handlers;

// Exit if file accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 0 );
}

/**
 * Class Hooks_Helper
 */
class Hooks_Helper {

	/**
	 * Boot itself
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Setup hooks
	 */
	private function setup() {
		//add_filter( 'bp_get_activity_content_body', 'wp_encode_emoji' );
		add_filter( 'bp_get_activity_content_body', 'wp_staticize_emoji' );
		add_filter( 'bp_activity_comment_content', array( $this, 'staticize_emoji_for_activity_comments' ), 10, 2 );

		add_action( 'bp_activity_post_options', array( $this, 'add_activity_icon' ), 20 );
		add_action( 'bp_activity_reply_options', array( $this, 'add_activity_comment_icon' ), 20 );

	}

	/**
	 * Insert images in place of emoji code.
	 *
	 * @param string $content content.
	 * @param string $context context.
	 *
	 * @return string
	 */
	public function staticize_emoji_for_activity_comments( $content, $context ) {
		if ( 'new' == $context ) {
			return $content;
		}

		return wp_staticize_emoji( $content );
	}

	/**
	 * Add icon for activity.
	 */
	public function add_activity_icon() {
		echo "<div class='bp-post-action bp-post-activity-action bp-emoji-action bp-post-activity-emoji-action'></div>";
	}

	/**
	 * Add icon for comments.
	 */
	public function add_activity_comment_icon() {
		echo "<div  id='bp-ac-comment-options-emoji-action-".bp_get_activity_id() ."' class='bp-post-action bp-ac-comment-action bp-emoji-action bp-ac-comment-emoji-action' data-id='" .bp_get_activity_id() ."'></div>";
	}

}

