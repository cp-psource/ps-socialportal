<?php
/**
 * Ajax request handler
 *
 * @package BP_Emoji
 * @subpackage Handler
 */

namespace BP_Emoji\Handlers;

// Exit if file accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ajax_Request_Handler
 */
class Ajax_Request_Handler {

	/**
	 * Boot itself
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Setup
	 */
	private function setup() {
		add_action( 'wp_ajax_bp_skeleton_ajax_callback', array( $this, 'callback' ) );
	}

	/**
	 * Add circle
	 */
	public function callback() {
		check_ajax_referer( 'bp_skeleton_action', 'nonce', true );
	}
}