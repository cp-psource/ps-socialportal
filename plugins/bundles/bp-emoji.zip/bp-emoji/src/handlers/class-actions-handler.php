<?php
/**
 * Action handler class
 *
 * @package BP_Emoji
 * @subpackage Handlers
 */

namespace BP_Emoji\Handlers;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Actions_Handler
 */
class Actions_Handler {

	/**
	 * Class self boot
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Setup
	 */
	private function setup() {
		// Add actions callbacks here.
	}
}

