<?php
/**
 * Core functions file
 *
 * @package BP_Emoji
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get setting
 *
 * @param string $setting Setting name.
 *
 * @return mixed
 */
function bp_skeleton_get_option( $setting = '' ) {

	$settings = get_option( 'bp_emoji_settings', bp_skeleton_get_default_options() );

	if ( isset( $settings[ $setting ] ) ) {
		return $settings[ $setting ];
	}

	return null;
}

/**
 * Get default options.
 *
 * @return array
 */
function bp_skeleton_get_default_options() {
	return array(
		'slug' => '',
	);
}

/**
 * Locate or load a file from theme or fallback to plugin.
 *
 * @param array $templates templates.
 * @param bool  $load load template?.
 *
 * @return string
 */
function bp_skeleton_locate_template( $templates, $load = false ) {
	$template_base = 'bp-skeleton/default';

	foreach ( $templates as $key => $template ) {
		$templates[ $key ] = $template_base . '/' . $template; // prefix the base.
	}

	$located = locate_template( $templates, false, false );

	if ( ! $located ) {
		$path = bp_emoji()->path . 'templates/';

		foreach ( $templates as $template ) {

			if ( ! is_readable( $path . $template ) ) {
				continue;
			}

			$located = $path . $template;
			break;
		}
	}

	if ( ! $load ) {
		return $located;
	}

	require $located;
}
