<?php
/**
 * Bootstrapper. Initializes the plugin.
 *
 * @package    BP_Emoji
 * @subpackage Bootstrap
 * @copyright  Copyright (c) 2018, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Emoji\Bootstrap;

use BP_Emoji\Admin\Admin_Settings;
use BP_Emoji\Handlers\Ajax_Request_Handler;
use BP_Emoji\Handlers\Hooks_Helper;
use BP_Emoji\Handlers\Actions_Handler;

// No direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 0 );
}

/**
 * Bootstrapper.
 */
class Bootstrapper {

	/**
	 * Setup the bootstrapper.
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Bind hooks
	 */
	private function setup() {
		add_action( 'bp_loaded', array( $this, 'load' ), 1 );
		// add_action( 'plugins_loaded', array( $this, 'load_admin' ), 9996 ); // pt settings 1.0.4.
		add_action( 'bp_init', array( $this, 'load_translations' ) );
	}

	/**
	 * Load core functions/template tags.
	 * These are non auto loadable constructs.
	 */
	public function load() {
		$path = bp_emoji()->path;

		$files = array(
			'src/core/bp-emoji-functions.php',
		);

		foreach ( $files as $file ) {
			require_once $path . $file;
		}

		Hooks_Helper::boot();
		Ajax_Request_Handler::boot();
		Actions_Handler::boot();
		Assets_Loader::boot();
	}

	/**
	 * Load pt-settings framework
	 */
	public function load_admin() {

		if ( function_exists( 'buddypress' ) && is_admin() && ! defined( 'DOING_AJAX' ) ) {
			require_once bp_emoji()->path . 'src/admin/pt-settings/pt-settings-loader.php';
			Admin_Settings::boot();
		}
	}

	/**
	 * Load translations.
	 */
	public function load_translations() {
		load_plugin_textdomain( 'bp-emoji', false, basename( dirname( bp_emoji()->path ) ) . '/languages' );
	}
}
