<?php
/**
 * Assets Loader
 *
 * @package    BP_Emoji
 * @subpackage Bootstrap
 * @copyright  Copyright (c) 2018, DerN3rd
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     DerN3rd
 * @since      1.0.0
 */

namespace BP_Emoji\Bootstrap;

if ( ! defined( 'ABSPATH' ) ) {
	exit( 0 );
}

/**
 * Assets Loader.
 */
class Assets_Loader {

	/**
	 * Data to be send as localized js.
	 *
	 * @var array
	 */
	private $data = array();

	/**
	 * Boot itself
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Setup
	 */
	public function setup() {
		add_action( 'bp_enqueue_scripts', array( $this, 'load_assets' ) );
	}

	/**
	 * Load plugin assets
	 */
	public function load_assets() {
		$this->register();
		$this->enqueue();
	}

	/**
	 * Register assets.
	 */
	public function register() {
		$this->register_vendors();
		$this->register_core();
	}

	/**
	 * Load assets.
	 */
	public function enqueue() {
		wp_enqueue_style( 'bp-emoji' );
		wp_enqueue_style( 'emojionearea' );
		wp_enqueue_script( 'bp-emoji' );

		wp_localize_script( 'bp-emoji', 'BP_Emoji', $this->data );
	}

	/**
	 * Register vendor scripts.
	 */
	private function register_vendors() {
		$bp_emoji = bp_emoji();
		$url      = $bp_emoji->url;
		$version  = $bp_emoji->version;
		wp_register_script( 'emojione', $url . 'assets/vendors/emojione/lib/js/emojione.js', array( 'jquery' ), $version );
		wp_register_script( 'emojionearea', $url . 'assets/vendors/emojionearea/emojionearea.js', array( 'jquery', 'emojione' ), $version );
		wp_register_style( 'emojionearea', $url . 'assets/vendors/emojionearea/emojionearea.css', array(), $version );
		wp_register_script( 'emojionearea-adapter', $url . 'assets/vendors/twemoji-emojionearea-adaptet/twemoji-emojionearea-adapter.js', array( 'emojionearea' ), $version );
	}

	/**
	 * Register core assets.
	 */
	private function register_core() {
		$bp_emoji = bp_emoji();
		$url         = $bp_emoji->url;
		$version     = $bp_emoji->version;

		wp_register_style( 'bp-emoji', $url . 'assets/css/bp-emoji.css', false, $version );
		wp_register_script( 'bp-emoji', $url . 'assets/js/bp-emoji.js', array( 'jquery', 'emojionearea-adapter' ), $version );

		$this->data = array();
	}
}
