<?php
//welcome to the world of PsourceMediathek
//This file is here to prevent people from directly accessing/listing the files of this folder via web
//
//please see psourcemediathek.php for the main plugin file
