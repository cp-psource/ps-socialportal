Included version: 
0.5.0 (2014-05-27)
------------
