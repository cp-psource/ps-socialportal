<?php
/**
 * PsourceMediathek JSON API(not the REST)
 *
 * @todo provide json api for crud/embed
 *
 * @package psourcemediathek
 */
