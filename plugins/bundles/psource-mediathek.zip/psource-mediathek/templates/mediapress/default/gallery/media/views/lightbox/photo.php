<a href="<?php psmt_media_permalink(); ?>" title="<?php echo esc_attr( psmt_get_media_title() ); ?>" class="psmt-lightbox-single-photo">

    <img src="<?php psmt_media_src( psmt_get_selected_lightbox_media_size() ); ?>"
	     alt="<?php echo esc_attr( psmt_get_media_title() ); ?>" />
</a>