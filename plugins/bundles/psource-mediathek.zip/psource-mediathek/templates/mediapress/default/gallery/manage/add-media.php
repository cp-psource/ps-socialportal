<?php
// Exit if the file is accessed directly over web
if ( ! defined( 'ABSPATH' ) ) {
	exit( 0 );
}
/**
 * Load Add Media form/New Upload form
 */
psmt_get_template( 'gallery/manage/upload-form.php' );
